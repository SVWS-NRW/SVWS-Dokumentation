import { $ as withCtx, B as createTextVNode, C as createVNode, D as defineComponent, P as openBlock, Z as watch, a8 as ref, aa as shallowRef, af as unref, b as SvwsUiButton_default, h as SimpleOperationResponse, i as BenutzerKennwort, r as Fragment, u as computed, v as createBaseVNode, w as createBlock, x as createCommentVNode, y as createElementBlock } from "./index.js";
import "./SvwsUiTooltip.js";
import { b as SvwsUiInputWrapper_default } from "./SvwsUiInputWrapper.js";
import { b as SvwsUiSpacing_default } from "./SvwsUiSpacing.js";
import { b as SvwsUiSpinner_default } from "./SvwsUiSpinner.js";
import "./ValidatorFehlerart.js";
import { b as SvwsUiTextInput_default } from "./SvwsUiTextInput.js";
import { b as SvwsUiTable_default } from "./SvwsUiTable.js";
import { b as SvwsUiCheckbox_default } from "./SvwsUiCheckbox.js";
import { b as validatorSchemaName, c as SvwsUiSelect_default, d as LogBox_default } from "./helfer.js";
import { b as UiCard_default } from "./UiCard.js";
const _hoisted_1$3 = { class: "space-y-2 mt-1" };
const _hoisted_2$3 = { class: "flex flex-col items-start gap-3" };
const _hoisted_3$2 = {
	key: 0,
	class: "flex flex-col gap-2"
};
const _hoisted_4$1 = { class: "flex flex-col gap-0.5 pl-3" };
const _hoisted_5$1 = { class: "flex flex-col gap-12 mt-5 w-full" };
const _hoisted_6$1 = {
	key: 0,
	class: "text-button -mb-1 mt-2"
};
const _hoisted_7$1 = {
	key: 1,
	class: "flex flex-col gap-2 -mt-5"
};
const _hoisted_8$1 = ["disabled"];
const _hoisted_9$1 = {
	key: 1,
	class: "icon i-ri-play-line"
};
var SSchemaUebersichtMigrate_vue_vue_type_script_setup_true_lang_default = /* @__PURE__ */ defineComponent({
	__name: "SSchemaUebersichtMigrate",
	props: {
		migrateSchema: { type: Function },
		targetSchema: {},
		migrationQuellinformationen: { type: Function },
		setStatus: { type: Function },
		loading: { type: Boolean },
		isOpen: { type: Boolean }
	},
	emits: ["opened"],
	setup(__props, { emit: __emit }) {
		const props = __props;
		const emit = __emit;
		const items = /* @__PURE__ */ new Map();
		items.set("mysql", "MySQL");
		items.set("mariadb", "MariaDB");
		items.set("mssql", "MSSQL");
		items.set("mdb", "Access (MDB)");
		const zielSchema = shallowRef("");
		const zielUsername = shallowRef("");
		const zielUserPassword = shallowRef("");
		async function actionFunction() {
			props.setStatus(true);
			const formData = new FormData();
			if (file.value !== null) {
				formData.append("database", file.value);
				formData.append("databasePassword", props.migrationQuellinformationen().password);
			}
			formData.append("schema", props.targetSchema ?? zielSchema.value);
			formData.append("db", props.migrationQuellinformationen().dbms);
			formData.append("srcUsername", props.migrationQuellinformationen().user);
			formData.append("srcPassword", props.migrationQuellinformationen().password);
			formData.append("srcSchema", props.migrationQuellinformationen().schema);
			formData.append("srcLocation", props.migrationQuellinformationen().location);
			formData.append("schulnummer", props.migrationQuellinformationen().schulnummer);
			formData.append("schemaUsername", zielUsername.value);
			formData.append("schemaUserPassword", zielUserPassword.value);
			try {
				const result = await props.migrateSchema(formData);
				props.setStatus(false, result.success, result.log);
				if (result.success) {
					zielSchema.value = "";
					zielUserPassword.value = "";
					zielUsername.value = "";
				}
			} catch (e) {
				console.log(e);
				props.setStatus(false);
			}
		}
		const file = shallowRef(null);
		function onFileChanged(event) {
			const target = event.target;
			if (target.files) file.value = target.files[0];
		}
		return (_ctx, _cache) => {
			const _component_svws_ui_select = SvwsUiSelect_default;
			const _component_svws_ui_checkbox = SvwsUiCheckbox_default;
			const _component_svws_ui_text_input = SvwsUiTextInput_default;
			const _component_svws_ui_input_wrapper = SvwsUiInputWrapper_default;
			const _component_svws_ui_spinner = SvwsUiSpinner_default;
			const _component_svws_ui_button = SvwsUiButton_default;
			const _component_ui_card = UiCard_default;
			return openBlock(), createBlock(_component_ui_card, {
				icon: "i-ri-database-2-line",
				title: "Schild2-Schema migrieren",
				subtitle: "Daten werden über die Auswahl einer existierenden Schild 2-Datenbank importiert",
				"is-open": _ctx.isOpen,
				"onUpdate:isOpen": _cache[10] || (_cache[10] = (open) => emit("opened", open))
			}, {
				buttonFooterLeft: withCtx(() => [createVNode(_component_svws_ui_button, {
					disabled: _ctx.migrationQuellinformationen().dbms === "mdb" && !file.value || zielUsername.value === "root" || _ctx.loading,
					title: "Migrieren",
					onClick: actionFunction,
					"is-loading": _ctx.loading,
					class: "w-fit"
				}, {
					default: withCtx(() => [_ctx.loading ? (openBlock(), createBlock(_component_svws_ui_spinner, {
						key: 0,
						spinning: ""
					})) : (openBlock(), createElementBlock("span", _hoisted_9$1)), _cache[16] || (_cache[16] = createTextVNode(" Migrieren ", -1))]),
					_: 1
				}, 8, ["disabled", "is-loading"])]),
				default: withCtx(() => [createBaseVNode("div", _hoisted_1$3, [createVNode(_component_svws_ui_select, {
					modelValue: _ctx.migrationQuellinformationen().dbms,
					"onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => _ctx.migrationQuellinformationen().dbms = $event),
					items: unref(items).keys(),
					"item-text": (i) => unref(items).get(i) || "",
					title: "Datenbank",
					class: "mb-8"
				}, null, 8, [
					"modelValue",
					"items",
					"item-text"
				]), createBaseVNode("div", _hoisted_2$3, [
					_ctx.migrationQuellinformationen().dbms !== "mdb" ? (openBlock(), createElementBlock("div", _hoisted_3$2, [createBaseVNode("div", _hoisted_4$1, [_cache[12] || (_cache[12] = createBaseVNode("span", { class: "opacity-50" }, "Bei Migration aus einer Schild-Zentral-Instanz:", -1)), createVNode(_component_svws_ui_checkbox, {
						class: "text-left",
						type: "toggle",
						modelValue: _ctx.migrationQuellinformationen().schildzentral,
						"onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => _ctx.migrationQuellinformationen().schildzentral = $event)
					}, {
						default: withCtx(() => [..._cache[11] || (_cache[11] = [createTextVNode("Schulnummer angeben", -1)])]),
						_: 1
					}, 8, ["modelValue"])])])) : createCommentVNode("", true),
					_ctx.migrationQuellinformationen().dbms !== "mdb" && _ctx.migrationQuellinformationen().schildzentral ? (openBlock(), createBlock(_component_svws_ui_text_input, {
						key: 1,
						modelValue: _ctx.migrationQuellinformationen().schulnummer,
						"onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => _ctx.migrationQuellinformationen().schulnummer = $event),
						placeholder: "Schulnummer"
					}, null, 8, ["modelValue"])) : createCommentVNode("", true),
					createBaseVNode("div", _hoisted_5$1, [_ctx.migrationQuellinformationen().dbms !== "mdb" ? (openBlock(), createBlock(_component_svws_ui_input_wrapper, { key: 0 }, {
						default: withCtx(() => [
							_ctx.targetSchema === void 0 ? (openBlock(), createElementBlock("div", _hoisted_6$1, "Quell-Datenbank")) : createCommentVNode("", true),
							createVNode(_component_svws_ui_text_input, {
								modelValue: _ctx.migrationQuellinformationen().location,
								"onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => _ctx.migrationQuellinformationen().location = $event),
								modelModifiers: { trim: true },
								placeholder: "Datenbank-Host (hostname:port) oder (ip:port)"
							}, null, 8, ["modelValue"]),
							createVNode(_component_svws_ui_text_input, {
								modelValue: _ctx.migrationQuellinformationen().schema,
								"onUpdate:modelValue": _cache[4] || (_cache[4] = ($event) => _ctx.migrationQuellinformationen().schema = $event),
								modelModifiers: { trim: true },
								placeholder: "Datenbank-Schema (z.B. schild_nrw)"
							}, null, 8, ["modelValue"]),
							createVNode(_component_svws_ui_text_input, {
								modelValue: _ctx.migrationQuellinformationen().user,
								"onUpdate:modelValue": _cache[5] || (_cache[5] = ($event) => _ctx.migrationQuellinformationen().user = $event),
								modelModifiers: { trim: true },
								placeholder: "Name des Datenbankbenutzers"
							}, null, 8, ["modelValue"]),
							createVNode(_component_svws_ui_text_input, {
								modelValue: _ctx.migrationQuellinformationen().password,
								"onUpdate:modelValue": _cache[6] || (_cache[6] = ($event) => _ctx.migrationQuellinformationen().password = $event),
								modelModifiers: { trim: true },
								placeholder: "Passwort des Datenbankbenutzers",
								type: "password"
							}, null, 8, ["modelValue"])
						]),
						_: 1
					})) : (openBlock(), createElementBlock("div", _hoisted_7$1, [_cache[13] || (_cache[13] = createBaseVNode("div", { class: "font-bold text-button" }, "Quell-Datenbank: Access-Datei (.mdb) hochladen", -1)), createBaseVNode("input", {
						type: "file",
						onChange: onFileChanged,
						disabled: _ctx.loading,
						accept: ".mdb"
					}, null, 40, _hoisted_8$1)])), _ctx.targetSchema === void 0 ? (openBlock(), createBlock(_component_svws_ui_input_wrapper, { key: 2 }, {
						default: withCtx(() => [
							_cache[14] || (_cache[14] = createBaseVNode("div", { class: "text-button -mb-1 mt-2" }, "Ziel-Datenbank (wird erstellt)", -1)),
							_cache[15] || (_cache[15] = createTextVNode(" Der Name des Schemas darf nur Buchstaben (ohne Umlaute), Zahlen sowie die Zeichen \"$\" und \"_\" enthalten: ", -1)),
							createVNode(_component_svws_ui_text_input, {
								modelValue: zielSchema.value,
								"onUpdate:modelValue": _cache[7] || (_cache[7] = ($event) => zielSchema.value = $event),
								modelModifiers: { trim: true },
								placeholder: "Schema (wird erstellt, z.B. svwsdb)",
								valid: unref(validatorSchemaName)
							}, null, 8, ["modelValue", "valid"]),
							createVNode(_component_svws_ui_text_input, {
								modelValue: zielUsername.value,
								"onUpdate:modelValue": _cache[8] || (_cache[8] = ($event) => zielUsername.value = $event),
								modelModifiers: { trim: true },
								placeholder: "Name des Datenbankbenutzers",
								valid: (value) => value !== "root"
							}, null, 8, ["modelValue", "valid"]),
							createVNode(_component_svws_ui_text_input, {
								modelValue: zielUserPassword.value,
								"onUpdate:modelValue": _cache[9] || (_cache[9] = ($event) => zielUserPassword.value = $event),
								modelModifiers: { trim: true },
								placeholder: "Passwort des Datenbankbenutzers",
								type: "password"
							}, null, 8, ["modelValue"])
						]),
						_: 1
					})) : createCommentVNode("", true)])
				])])]),
				_: 1
			}, 8, ["is-open"]);
		};
	}
});
var SSchemaUebersichtMigrate_default = SSchemaUebersichtMigrate_vue_vue_type_script_setup_true_lang_default;
const _hoisted_1$2 = { class: "space-y-4" };
const _hoisted_2$2 = ["disabled"];
const _hoisted_3$1 = {
	key: 1,
	class: "icon i-ri-play-line"
};
var SSchemaUebersichtRestore_vue_vue_type_script_setup_true_lang_default = /* @__PURE__ */ defineComponent({
	__name: "SSchemaUebersichtRestore",
	props: {
		restoreSchema: { type: Function },
		setStatus: { type: Function },
		loading: { type: Boolean },
		isOpen: { type: Boolean }
	},
	emits: ["opened"],
	setup(__props, { emit: __emit }) {
		const props = __props;
		const emit = __emit;
		const file = ref(null);
		function onFileChanged(event) {
			const target = event.target;
			if (target.files) file.value = target.files[0];
			props.setStatus(false);
		}
		async function actionFunction() {
			if (file.value === null) return;
			props.setStatus(true);
			const formData = new FormData();
			formData.append("database", file.value);
			const result = await props.restoreSchema(formData);
			file.value = null;
			props.setStatus(false, result.success, result.log);
		}
		return (_ctx, _cache) => {
			const _component_svws_ui_spinner = SvwsUiSpinner_default;
			const _component_svws_ui_button = SvwsUiButton_default;
			const _component_ui_card = UiCard_default;
			return openBlock(), createBlock(_component_ui_card, {
				icon: "i-ri-device-recover-line",
				title: "Backup wiederherstellen",
				subtitle: "Daten werden aus einem Backup wiederhergestellt",
				"is-open": _ctx.isOpen,
				"onUpdate:isOpen": _cache[0] || (_cache[0] = (open) => emit("opened", open))
			}, {
				buttonFooterLeft: withCtx(() => [createVNode(_component_svws_ui_button, {
					disabled: !file.value || _ctx.loading,
					"is-loading": _ctx.loading,
					title: "Wiederherstellen",
					onClick: actionFunction,
					class: "mt-4 w-fit"
				}, {
					default: withCtx(() => [_ctx.loading ? (openBlock(), createBlock(_component_svws_ui_spinner, {
						key: 0,
						spinning: ""
					})) : (openBlock(), createElementBlock("span", _hoisted_3$1)), _cache[2] || (_cache[2] = createTextVNode(" Wiederherstellen ", -1))]),
					_: 1
				}, 8, ["disabled", "is-loading"])]),
				default: withCtx(() => [createBaseVNode("div", _hoisted_1$2, [_cache[1] || (_cache[1] = createBaseVNode("div", { class: "font-bold text-button" }, "Quell-Datenbank: SQLite-Datenbank (.sqlite) hochladen", -1)), createBaseVNode("input", {
					type: "file",
					onChange: onFileChanged,
					disabled: _ctx.loading,
					accept: ".sqlite"
				}, null, 40, _hoisted_2$2)])]),
				_: 1
			}, 8, ["is-open"]);
		};
	}
});
var SSchemaUebersichtRestore_default = SSchemaUebersichtRestore_vue_vue_type_script_setup_true_lang_default;
const _hoisted_1$1 = { class: "input-wrapper mt-2" };
const _hoisted_2$1 = {
	key: 1,
	class: "icon i-ri-play-line"
};
var SSchemaUebersichtAddExisting_vue_vue_type_script_setup_true_lang_default = /* @__PURE__ */ defineComponent({
	__name: "SSchemaUebersichtAddExisting",
	props: {
		addExistingSchemaToConfig: { type: Function },
		schema: {},
		setStatus: { type: Function },
		loading: { type: Boolean },
		isOpen: { type: Boolean }
	},
	emits: ["opened"],
	setup(__props, { emit: __emit }) {
		const props = __props;
		const emit = __emit;
		const user = ref("");
		const password = ref("");
		async function actionFunction() {
			props.setStatus(true);
			const data = new BenutzerKennwort();
			data.user = user.value;
			data.password = password.value;
			const result = new SimpleOperationResponse();
			result.success = true;
			await props.addExistingSchemaToConfig(data, props.schema);
			user.value = "";
			password.value = "";
			props.setStatus(false);
		}
		return (_ctx, _cache) => {
			const _component_svws_ui_text_input = SvwsUiTextInput_default;
			const _component_svws_ui_spacing = SvwsUiSpacing_default;
			const _component_svws_ui_spinner = SvwsUiSpinner_default;
			const _component_svws_ui_button = SvwsUiButton_default;
			const _component_ui_card = UiCard_default;
			return openBlock(), createBlock(_component_ui_card, {
				icon: "i-ri-share-forward-2-line",
				title: "In Konfiguration aufnehmen",
				subtitle: "Das Schema wird mit dem angegebenen Benutzer und Kennwort in die Konfiguration der SVWS-Servers aufgenommen.",
				"is-open": _ctx.isOpen,
				"onUpdate:isOpen": _cache[2] || (_cache[2] = (isOpen) => emit("opened", isOpen))
			}, {
				buttonFooterLeft: withCtx(() => [createVNode(_component_svws_ui_button, {
					disabled: props.schema === void 0 || user.value.length === 0 || user.value === "root" || _ctx.loading,
					"is-loading": _ctx.loading,
					title: "Hinzufügen",
					onClick: actionFunction
				}, {
					default: withCtx(() => [_ctx.loading ? (openBlock(), createBlock(_component_svws_ui_spinner, {
						key: 0,
						spinning: ""
					})) : (openBlock(), createElementBlock("span", _hoisted_2$1)), _cache[3] || (_cache[3] = createTextVNode(" Hinzufügen ", -1))]),
					_: 1
				}, 8, ["disabled", "is-loading"])]),
				default: withCtx(() => [createBaseVNode("div", _hoisted_1$1, [
					createVNode(_component_svws_ui_text_input, {
						modelValue: user.value,
						"onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => user.value = $event),
						modelModifiers: { trim: true },
						required: "",
						placeholder: "Benutzername",
						disabled: _ctx.loading,
						valid: (value) => value !== "root"
					}, null, 8, [
						"modelValue",
						"disabled",
						"valid"
					]),
					createVNode(_component_svws_ui_text_input, {
						modelValue: password.value,
						"onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => password.value = $event),
						modelModifiers: { trim: true },
						required: "",
						placeholder: "Passwort",
						disabled: _ctx.loading,
						type: "password"
					}, null, 8, ["modelValue", "disabled"]),
					createVNode(_component_svws_ui_spacing)
				])]),
				_: 1
			}, 8, ["is-open"]);
		};
	}
});
var SSchemaUebersichtAddExisting_default = SSchemaUebersichtAddExisting_vue_vue_type_script_setup_true_lang_default;
const _hoisted_1 = { class: "page page-flex-row" };
const _hoisted_2 = { class: "h-full min-w-128 flex flex-col gap-y-8 overflow-y-auto px-6" };
const _hoisted_3 = {
	key: 0,
	class: "flex flex-col gap-4"
};
const _hoisted_4 = {
	key: 1,
	class: "flex flex-col gap-4"
};
const _hoisted_5 = { class: "space-y-2" };
const _hoisted_6 = {
	key: 1,
	class: "icon i-ri-play-line"
};
const _hoisted_7 = { class: "flex flex-col gap-2" };
const _hoisted_8 = {
	key: 0,
	class: "text-ui-danger flex items-center"
};
const _hoisted_9 = {
	key: 1,
	class: "icon i-ri-play-line"
};
const _hoisted_10 = {
	key: 2,
	class: "flex flex-col gap-4"
};
const _hoisted_11 = { class: "space-y-2" };
const _hoisted_12 = {
	key: 1,
	class: "icon i-ri-play-line"
};
const _hoisted_13 = { class: "w-full" };
const _hoisted_14 = {
	key: 1,
	class: "icon i-ri-play-line"
};
const _hoisted_15 = { class: "min-w-96 flex flex-col gap-y-8 overflow-y-auto px-6" };
const _hoisted_16 = { class: "flex flex-col gap-4" };
const _hoisted_17 = { class: "grow min-w-fit" };
var SSchemaUebersicht_vue_vue_type_script_setup_true_lang_default = /* @__PURE__ */ defineComponent({
	__name: "SSchemaUebersicht",
	props: {
		data: { type: Function },
		admins: { type: Function },
		backupSchema: { type: Function },
		restoreSchema: { type: Function },
		migrateSchema: { type: Function },
		upgradeSchema: { type: Function },
		initSchema: { type: Function },
		createEmptySchema: { type: Function },
		addExistingSchemaToConfig: { type: Function },
		revision: {},
		schuleInfo: { type: Function },
		schulen: { type: Function },
		migrationQuellinformationen: { type: Function },
		apiStatus: {}
	},
	setup(__props) {
		const props = __props;
		const eintrag = computed(() => props.data());
		watch(eintrag, async (newEintrag, oldEintrag) => {
			if (newEintrag === void 0 && oldEintrag === void 0) return;
			if (newEintrag !== void 0 && oldEintrag !== void 0 && newEintrag.name === oldEintrag.name) return;
			clear();
		});
		const schule = ref();
		const loading = ref(false);
		const logs = shallowRef(void 0);
		const status = shallowRef(void 0);
		const currentAction = ref("");
		const oldAction = ref({
			name: void 0,
			open: false
		});
		function setStatus(loadingV, statusV, logsV) {
			logs.value = logsV;
			loading.value = loadingV;
			status.value = statusV;
		}
		function clear() {
			loading.value = false;
			logs.value = void 0;
			status.value = void 0;
		}
		const revisionNotUpToDate = computed(() => {
			const revServer = props.revision;
			if (eintrag.value === void 0 || revServer === null || eintrag.value.revision < 0) return false;
			return revServer !== eintrag.value.revision;
		});
		const zeigeNeuesSchemaAnlegen = computed(() => eintrag.value !== void 0 && eintrag.value.isInConfig && !eintrag.value.isSVWS);
		const zeigeInitialisierungMitSchulkatalog = computed(() => eintrag.value !== void 0 && eintrag.value.isInConfig && eintrag.value.isSVWS && props.schuleInfo() === void 0 && !revisionNotUpToDate.value);
		const cols = [{
			key: "anzeigename",
			label: "Name",
			span: 2
		}, {
			key: "name",
			label: "Benutzername",
			span: 1,
			sortable: true
		}];
		function setCurrentAction(newAction, open) {
			if (newAction === oldAction.value.name && !open) return;
			oldAction.value.name = currentAction.value;
			oldAction.value.open = currentAction.value === "" ? false : true;
			if (open === true) currentAction.value = newAction;
			else currentAction.value = "";
		}
		async function getBackupSchema() {
			loading.value = true;
			const { data, name } = await props.backupSchema();
			loading.value = false;
			const link = document.createElement("a");
			link.href = URL.createObjectURL(data);
			link.download = name;
			link.target = "_blank";
			link.click();
			URL.revokeObjectURL(link.href);
		}
		async function init() {
			if (schule.value === void 0) return;
			loading.value = true;
			await props.initSchema(Number(schule.value.SchulNr));
			loading.value = false;
		}
		const schulen_filter = (items, search) => {
			const nrmatch = /\d+/.exec(search);
			const nr = nrmatch ? nrmatch[0] : void 0;
			const ort = search.replace(/\d+\s*/, "").trim();
			if (nr === void 0 && ort.length === 0) return items;
			if (nr === void 0) return items.filter((item) => {
				if (item.Ort !== null) return item.Ort.toLocaleLowerCase("de-DE").startsWith(ort.toLocaleLowerCase("de-DE"));
				return false;
			});
			else if (ort.length === 0) return items.filter((item) => {
				if (item.SchulNr.length > 0) return item.SchulNr.includes(nr);
				return false;
			});
			else return items.filter((item) => {
				if (item.SchulNr.length > 0 && item.Ort !== null) return item.SchulNr.includes(nr) && item.Ort.toLocaleLowerCase("de-DE").startsWith(ort.toLocaleLowerCase("de-DE"));
				return false;
			});
		};
		return (_ctx, _cache) => {
			const _component_s_schema_uebersicht_add_existing = SSchemaUebersichtAddExisting_default;
			const _component_svws_ui_spinner = SvwsUiSpinner_default;
			const _component_svws_ui_button = SvwsUiButton_default;
			const _component_ui_card = UiCard_default;
			const _component_svws_ui_select = SvwsUiSelect_default;
			const _component_svws_ui_input_wrapper = SvwsUiInputWrapper_default;
			const _component_s_schema_uebersicht_restore = SSchemaUebersichtRestore_default;
			const _component_s_schema_uebersicht_migrate = SSchemaUebersichtMigrate_default;
			const _component_svws_ui_table = SvwsUiTable_default;
			const _component_log_box = LogBox_default;
			return openBlock(), createElementBlock("div", _hoisted_1, [
				createBaseVNode("div", _hoisted_2, [eintrag.value !== void 0 ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [
					eintrag.value !== void 0 && !eintrag.value.isInConfig ? (openBlock(), createElementBlock("div", _hoisted_3, [createVNode(_component_s_schema_uebersicht_add_existing, {
						schema: eintrag.value.name,
						"add-existing-schema-to-config": _ctx.addExistingSchemaToConfig,
						loading: loading.value,
						"set-status": setStatus,
						"is-open": currentAction.value === "config",
						onOpened: _cache[0] || (_cache[0] = (isOpen) => setCurrentAction("config", isOpen))
					}, null, 8, [
						"schema",
						"add-existing-schema-to-config",
						"loading",
						"is-open"
					])])) : createCommentVNode("", true),
					eintrag.value.isSVWS || revisionNotUpToDate.value ? (openBlock(), createElementBlock("div", _hoisted_4, [_cache[11] || (_cache[11] = createBaseVNode("div", { class: "text-headline-md" }, "Sicherung", -1)), createBaseVNode("div", _hoisted_5, [eintrag.value.isSVWS ? (openBlock(), createBlock(_component_ui_card, {
						key: 0,
						icon: "i-ri-save-3-line",
						title: "Backup",
						subtitle: "Daten aus dem Schema werden in ein SQLite-Backup übertragen",
						"is-open": currentAction.value === "backup",
						"onUpdate:isOpen": _cache[1] || (_cache[1] = (isOpen) => setCurrentAction("backup", isOpen))
					}, {
						default: withCtx(() => [createVNode(_component_svws_ui_button, {
							disabled: loading.value,
							title: "Backup starten",
							onClick: getBackupSchema,
							"is-loading": loading.value
						}, {
							default: withCtx(() => [loading.value ? (openBlock(), createBlock(_component_svws_ui_spinner, {
								key: 0,
								spinning: ""
							})) : (openBlock(), createElementBlock("span", _hoisted_6)), _cache[8] || (_cache[8] = createTextVNode(" Backup starten ", -1))]),
							_: 1
						}, 8, ["disabled", "is-loading"])]),
						_: 1
					}, 8, ["is-open"])) : createCommentVNode("", true), revisionNotUpToDate.value ? (openBlock(), createBlock(_component_ui_card, {
						key: 1,
						icon: "i-ri-speed-line",
						title: "Aktualisieren",
						subtitle: `Setzt das Schema auf die aktuelle Revision ${_ctx.revision} hoch`,
						"is-open": currentAction.value === "upgrade",
						"onUpdate:isOpen": _cache[2] || (_cache[2] = (isOpen) => setCurrentAction("upgrade", isOpen))
					}, {
						buttonFooterLeft: withCtx(() => [createVNode(_component_svws_ui_button, {
							disabled: loading.value,
							title: "Aktualisierung starten",
							onClick: _ctx.upgradeSchema,
							"is-loading": loading.value,
							class: "w-fit mt-4"
						}, {
							default: withCtx(() => [loading.value ? (openBlock(), createBlock(_component_svws_ui_spinner, {
								key: 0,
								spinning: ""
							})) : (openBlock(), createElementBlock("span", _hoisted_9)), _cache[10] || (_cache[10] = createTextVNode(" Aktualisierung starten ", -1))]),
							_: 1
						}, 8, [
							"disabled",
							"onClick",
							"is-loading"
						])]),
						default: withCtx(() => [createBaseVNode("div", _hoisted_7, [eintrag.value.isTainted ? (openBlock(), createElementBlock("div", _hoisted_8, [..._cache[9] || (_cache[9] = [createBaseVNode("span", { class: "icon icon-ui-danger i-ri-error-warning-line inline relative mt-0.5 mr-1" }, null, -1), createTextVNode(" Achtung, auch nach dem Hochsetzen bleibt das Schema „Tainted“. ", -1)])])) : createCommentVNode("", true)])]),
						_: 1
					}, 8, ["subtitle", "is-open"])) : createCommentVNode("", true)])])) : createCommentVNode("", true),
					zeigeInitialisierungMitSchulkatalog.value || zeigeNeuesSchemaAnlegen.value || eintrag.value !== void 0 && eintrag.value.isInConfig ? (openBlock(), createElementBlock("div", _hoisted_10, [_cache[14] || (_cache[14] = createBaseVNode("div", { class: "text-headline-md" }, "Initialisieren / Wiederherstellen", -1)), createBaseVNode("div", _hoisted_11, [
						zeigeNeuesSchemaAnlegen.value ? (openBlock(), createBlock(_component_ui_card, {
							key: 0,
							icon: "i-ri-archive-line",
							title: "Neues Schema",
							subtitle: "Erstellt ein neues leeres Schema, welches im Anschluss initialisiert werden kann",
							"is-open": currentAction.value === "empty",
							"onUpdate:isOpen": _cache[3] || (_cache[3] = (isOpen) => setCurrentAction("empty", isOpen))
						}, {
							default: withCtx(() => [createVNode(_component_svws_ui_button, {
								disabled: loading.value,
								title: "Schema Anlegen",
								onClick: _ctx.createEmptySchema,
								"is-loading": loading.value
							}, {
								default: withCtx(() => [loading.value ? (openBlock(), createBlock(_component_svws_ui_spinner, {
									key: 0,
									spinning: ""
								})) : (openBlock(), createElementBlock("span", _hoisted_12)), _cache[12] || (_cache[12] = createTextVNode(" Schema Anlegen ", -1))]),
								_: 1
							}, 8, [
								"disabled",
								"onClick",
								"is-loading"
							])]),
							_: 1
						}, 8, ["is-open"])) : createCommentVNode("", true),
						zeigeInitialisierungMitSchulkatalog.value ? (openBlock(), createBlock(_component_ui_card, {
							key: 1,
							icon: "i-ri-archive-line",
							title: "Initialisieren aus Schulkatalog",
							subtitle: "Daten werden über die Auswahl der Schulnummer initialisiert",
							"is-open": currentAction.value === "init",
							"onUpdate:isOpen": _cache[5] || (_cache[5] = (isOpen) => setCurrentAction("init", isOpen))
						}, {
							buttonFooterLeft: withCtx(() => [createVNode(_component_svws_ui_button, {
								disabled: schule.value === void 0 || loading.value,
								title: "Initialisieren",
								onClick: init,
								"is-loading": loading.value
							}, {
								default: withCtx(() => [loading.value ? (openBlock(), createBlock(_component_svws_ui_spinner, {
									key: 0,
									spinning: ""
								})) : (openBlock(), createElementBlock("span", _hoisted_14)), _cache[13] || (_cache[13] = createTextVNode(" Initialisieren ", -1))]),
								_: 1
							}, 8, ["disabled", "is-loading"])]),
							default: withCtx(() => [createBaseVNode("div", _hoisted_13, [createVNode(_component_svws_ui_input_wrapper, { class: "mt-2" }, {
								default: withCtx(() => [createVNode(_component_svws_ui_select, {
									title: "Schulen nach Schulnummer und Ort suchen",
									modelValue: schule.value,
									"onUpdate:modelValue": _cache[4] || (_cache[4] = ($event) => schule.value = $event),
									items: _ctx.schulen(),
									"item-text": (i) => `${i.SchulNr}: ${i.ABez1 ?? ""} ${i.ABez2 ?? ""} ${i.ABez3 ?? ""}`,
									autocomplete: "",
									"item-filter": schulen_filter
								}, null, 8, [
									"modelValue",
									"items",
									"item-text"
								])]),
								_: 1
							})])]),
							_: 1
						}, 8, ["is-open"])) : createCommentVNode("", true),
						eintrag.value !== void 0 && eintrag.value.isInConfig ? (openBlock(), createBlock(_component_s_schema_uebersicht_restore, {
							key: 2,
							"restore-schema": _ctx.restoreSchema,
							loading: loading.value,
							"set-status": setStatus,
							"is-open": currentAction.value === "restore",
							onOpened: _cache[6] || (_cache[6] = (isOpen) => setCurrentAction("restore", isOpen))
						}, null, 8, [
							"restore-schema",
							"loading",
							"is-open"
						])) : createCommentVNode("", true),
						eintrag.value !== void 0 && eintrag.value.isInConfig ? (openBlock(), createBlock(_component_s_schema_uebersicht_migrate, {
							key: 3,
							"migrate-schema": _ctx.migrateSchema,
							"target-schema": eintrag.value.name,
							"migration-quellinformationen": _ctx.migrationQuellinformationen,
							loading: loading.value,
							"set-status": setStatus,
							"is-open": currentAction.value === "migrate",
							onOpened: _cache[7] || (_cache[7] = (isOpen) => setCurrentAction("migrate", isOpen))
						}, null, 8, [
							"migrate-schema",
							"target-schema",
							"migration-quellinformationen",
							"loading",
							"is-open"
						])) : createCommentVNode("", true)
					])])) : createCommentVNode("", true)
				], 64)) : createCommentVNode("", true)]),
				createBaseVNode("div", _hoisted_15, [createBaseVNode("div", _hoisted_16, [_cache[15] || (_cache[15] = createBaseVNode("div", { class: "text-headline-md" }, "Admin-Benutzer", -1)), createVNode(_component_svws_ui_table, {
					columns: cols,
					items: _ctx.admins(),
					scroll: ""
				}, null, 8, ["items"])])]),
				createBaseVNode("div", _hoisted_17, [createVNode(_component_log_box, {
					logs: logs.value,
					status: status.value
				}, {
					button: withCtx(() => [status.value !== void 0 ? (openBlock(), createBlock(_component_svws_ui_button, {
						key: 0,
						type: "transparent",
						onClick: clear,
						title: "Log verwerfen"
					}, {
						default: withCtx(() => [..._cache[16] || (_cache[16] = [createTextVNode("Log verwerfen ", -1)])]),
						_: 1
					})) : createCommentVNode("", true)]),
					_: 1
				}, 8, ["logs", "status"])])
			]);
		};
	}
});
var SSchemaUebersicht_default = SSchemaUebersicht_vue_vue_type_script_setup_true_lang_default;
export { SSchemaUebersicht_default as default };

//# sourceMappingURL=SSchemaUebersicht.js.map