import { D as defineComponent, P as openBlock, S as renderSlot, ag as normalizeClass, y as createElementBlock } from "./index.js";
var SvwsUiSpacing_vue_vue_type_script_setup_true_lang_default = /* @__PURE__ */ defineComponent({
	__name: "SvwsUiSpacing",
	props: { size: { default: 1 } },
	setup(__props) {
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", { class: normalizeClass(["svws-ui-spacing", { "svws-ui-spacing--2": _ctx.size === 2 }]) }, [renderSlot(_ctx.$slots, "default")], 2);
		};
	}
});
var SvwsUiSpacing_default = SvwsUiSpacing_vue_vue_type_script_setup_true_lang_default;
export { SvwsUiSpacing_default as b };

//# sourceMappingURL=SvwsUiSpacing.js.map