import { $ as withCtx, B as createTextVNode, C as createVNode, D as defineComponent, I as mergeProps, K as onBeforeMount, L as onBeforeUnmount, M as onMounted, P as openBlock, R as renderList, X as useId, Z as watch, a1 as withDirectives, a8 as ref, af as unref, ag as normalizeClass, ai as toDisplayString, p as withKeys, q as withModifiers, r as Fragment, u as computed, v as createBaseVNode, x as createCommentVNode, y as createElementBlock } from "./index.js";
import { b as SvwsUiTooltip_default } from "./SvwsUiTooltip.js";
import { b as ValidatorFehlerart } from "./ValidatorFehlerart.js";
const _hoisted_1 = {
	key: 0,
	class: "pointer-events-none absolute left-0 pl-3 opacity-60 top-[0.32rem]"
};
const _hoisted_2 = {
	key: 1,
	class: "icon i-ri-search-line text-input--search-icon"
};
const _hoisted_3 = [
	"type",
	"min",
	"max",
	"value",
	"disabled",
	"required",
	"readonly",
	"aria-labelledby",
	"placeholder"
];
const _hoisted_4 = ["id"];
const _hoisted_5 = {
	key: 0,
	class: "cursor-pointer"
};
const _hoisted_6 = {
	key: 2,
	class: "icon-xs i-ri-asterisk text-input--placeholder--required text-input--state-icon",
	"aria-hidden": ""
};
const _hoisted_7 = {
	key: 3,
	class: "sr-only"
};
const _hoisted_8 = {
	key: 4,
	class: "icon-sm i-ri-alert-line text-input--muss-icon"
};
const _hoisted_9 = {
	key: 5,
	class: "cursor-pointer inline-block -my-1"
};
const _hoisted_10 = { class: "inline-flex items-center -mb-2 mt-0.5 pointer-events-auto" };
const _hoisted_11 = {
	key: 0,
	class: "icon i-ri-alert-fill text-input--state-icon"
};
const _hoisted_12 = {
	key: 0,
	class: "icon i-ri-alert-fill text-input--state-icon"
};
const _hoisted_13 = {
	key: 1,
	class: "icon i-ri-error-warning-fill text-input--state-icon"
};
const _hoisted_14 = {
	key: 2,
	class: "icon i-ri-question-fill text-input--state-icon"
};
const _hoisted_15 = { class: "pl-2" };
const _hoisted_16 = {
	key: 1,
	class: "text-headline-sm text-center"
};
const _hoisted_17 = {
	key: 6,
	class: "icon-xs i-ri-lock-line"
};
const _hoisted_18 = {
	key: 6,
	class: "svws-icon icon i-ri-calendar-2-line"
};
const _hoisted_19 = {
	key: 7,
	class: "svws-icon icon i-ri-at-line"
};
const _hoisted_20 = {
	key: 8,
	class: "svws-icon icon i-ri-phone-line"
};
var SvwsUiTextInput_vue_vue_type_script_setup_true_lang_default = /* @__PURE__ */ defineComponent({
	inheritAttrs: false,
	__name: "SvwsUiTextInput",
	props: {
		type: { default: "text" },
		minDate: { default: void 0 },
		maxDate: { default: void 0 },
		modelValue: { default: null },
		modelModifiers: { default: () => ({ trim: false }) },
		placeholder: { default: "" },
		statistics: {
			type: Boolean,
			default: false
		},
		valid: {
			type: Function,
			default: (value) => true
		},
		validator: {
			type: Function,
			default: void 0
		},
		doValidate: {
			type: Function,
			default: (validator, value) => validator.run()
		},
		disabled: {
			type: Boolean,
			default: false
		},
		required: {
			type: Boolean,
			default: false
		},
		readonly: {
			type: Boolean,
			default: false
		},
		headless: {
			type: Boolean,
			default: false
		},
		isSelectInput: {
			type: Boolean,
			default: false
		},
		focus: {
			type: Boolean,
			default: false
		},
		rounded: {
			type: Boolean,
			default: false
		},
		url: {
			type: Boolean,
			default: false
		},
		maxLen: { default: void 0 },
		minLen: { default: void 0 },
		span: { default: void 0 },
		removable: {
			type: Boolean,
			default: false
		},
		fehlerart: { default: () => ValidatorFehlerart.UNGENUTZT }
	},
	emits: [
		"update:modelValue",
		"change",
		"blur",
		"methods"
	],
	setup(__props, { expose: __expose, emit: __emit }) {
		function firefox() {
			return window.navigator.userAgent.includes("Firefox/");
		}
		const input = ref(null);
		const props = __props;
		const emit = __emit;
		const vFocus = { mounted: (el) => {
			if (props.focus) el.focus();
		} };
		const data = ref(null);
		onBeforeMount(() => data.value = props.modelValue);
		const methods = { focus: () => doFocus() };
		onMounted(() => emit("methods", methods));
		onBeforeUnmount(() => emit("methods", void 0));
		watch(() => props.modelValue, (value) => updateData(value), { immediate: false });
		const validatorEmail = (value) => value === null || value === "" ? true : /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))[^@]?$/.test(value) || /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(value);
		const isValid = computed(() => {
			let tmpIsValid = true;
			if (props.required && (data.value === null || data.value === "")) tmpIsValid = false;
			if (props.validator !== void 0) return props.doValidate(props.validator(), data.value);
			if (tmpIsValid && (!minLenValid.value || !maxLenValid.value)) tmpIsValid = false;
			if (tmpIsValid && props.type === "email") tmpIsValid = validatorEmail(data.value ?? "");
			if (tmpIsValid) tmpIsValid = props.valid(data.value);
			return tmpIsValid;
		});
		function updateData(value) {
			if (data.value !== value) {
				data.value = value;
				emit("update:modelValue", data.value);
			}
		}
		const minLenValid = computed(() => {
			if (props.minLen === void 0 || data.value === null && props.minLen <= 0) return true;
			return data.value !== null && data.value.toLocaleString().length >= props.minLen;
		});
		const maxLenValid = computed(() => {
			if (props.maxLen === void 0 || data.value === null) return true;
			return data.value.toLocaleString().length <= props.maxLen;
		});
		function onInput(event) {
			const value = event.target.value;
			if (value !== data.value) updateData(value);
		}
		function onBlur(event) {
			if (props.modelValue !== data.value) emit("change", data.value);
			emit("blur", data.value);
		}
		function onKeyEnter(event) {
			if (props.modelValue !== data.value) emit("change", data.value);
		}
		function reset() {
			data.value = props.modelValue;
		}
		function doFocus() {
			input.value?.focus();
		}
		const labelId = useId();
		const content = computed(() => data.value);
		__expose({
			content,
			input,
			reset,
			doFocus
		});
		return (_ctx, _cache) => {
			const _component_svws_ui_tooltip = SvwsUiTooltip_default;
			return openBlock(), createElementBlock("label", { class: normalizeClass(["text-input-component", {
				"text-input--filled": `${data.value}`.length > 0 && data.value !== null || _ctx.type === "date",
				"text-input--invalid": isValid.value === false,
				"text-input--statistic-muss": _ctx.validator !== void 0 && !_ctx.validator().getFehler().isEmpty() && _ctx.validator().getFehlerart() === unref(ValidatorFehlerart).MUSS || isValid.value === false && _ctx.fehlerart === unref(ValidatorFehlerart).MUSS,
				"text-input--statistic-kann": _ctx.validator !== void 0 && !_ctx.validator().getFehler().isEmpty() && _ctx.validator().getFehlerart() === unref(ValidatorFehlerart).KANN || isValid.value === false && _ctx.fehlerart === unref(ValidatorFehlerart).KANN,
				"text-input--statistic-hinweis": _ctx.validator !== void 0 && !_ctx.validator().getFehler().isEmpty() && _ctx.validator().getFehlerart() === unref(ValidatorFehlerart).HINWEIS || isValid.value === false && _ctx.fehlerart === unref(ValidatorFehlerart).HINWEIS,
				"text-input--disabled": _ctx.disabled,
				"text-input--readonly": _ctx.readonly,
				"text-input--select": _ctx.isSelectInput,
				"text-input--statistics": _ctx.statistics,
				"text-input--search": _ctx.type === "search",
				"text-input--date": _ctx.type === "date",
				"text-input-component--headless": _ctx.headless,
				"col-span-full": _ctx.span === "full",
				"col-span-2": _ctx.span === "2"
			}]) }, [
				_ctx.url ? (openBlock(), createElementBlock("span", _hoisted_1, "https://")) : createCommentVNode("", true),
				_ctx.type === "search" ? (openBlock(), createElementBlock("span", _hoisted_2)) : createCommentVNode("", true),
				_ctx.readonly && !_ctx.isSelectInput ? (openBlock(), createElementBlock("div", {
					key: 2,
					class: normalizeClass({
						"text-input--control": !_ctx.headless,
						"text-input--headless": _ctx.headless,
						"text-input--rounded": _ctx.rounded,
						"text-input--prefix": _ctx.url
					})
				}, toDisplayString(data.value), 3)) : withDirectives((openBlock(), createElementBlock("input", mergeProps({
					key: 3,
					ref_key: "input",
					ref: input,
					class: {
						"text-input--control": !_ctx.headless,
						"text-input--headless": _ctx.headless,
						"text-input--rounded": _ctx.rounded,
						"text-input--prefix": _ctx.url
					}
				}, { ..._ctx.$attrs }, {
					type: _ctx.type,
					min: _ctx.minDate,
					max: _ctx.maxDate,
					value: data.value,
					disabled: _ctx.disabled,
					required: _ctx.required,
					readonly: _ctx.readonly,
					"aria-labelledby": unref(labelId),
					placeholder: _ctx.headless || _ctx.type === "search" ? _ctx.placeholder : "",
					onInput,
					onKeyup: withKeys(onKeyEnter, ["enter"]),
					onBlur
				}), null, 16, _hoisted_3)), [[vFocus]]),
				_ctx.placeholder && !_ctx.headless && _ctx.type !== "search" ? (openBlock(), createElementBlock("span", {
					key: 4,
					id: unref(labelId),
					class: normalizeClass(["text-input--placeholder gap-1", { "text-input--placeholder--prefix": _ctx.url }])
				}, [
					_ctx.statistics ? (openBlock(), createElementBlock("span", _hoisted_5, [createVNode(_component_svws_ui_tooltip, { position: "right" }, {
						content: withCtx(() => [..._cache[2] || (_cache[2] = [createTextVNode(" Relevant für die Statistik ", -1)])]),
						default: withCtx(() => [_cache[3] || (_cache[3] = createBaseVNode("span", { class: "inline-flex items-center" }, [createBaseVNode("span", { class: "icon i-ri-bar-chart-2-line text-input--statistic-icon" })], -1))]),
						_: 1
					})])) : createCommentVNode("", true),
					createBaseVNode("span", null, toDisplayString(_ctx.placeholder), 1),
					_ctx.maxLen !== void 0 || _ctx.minLen !== void 0 ? (openBlock(), createElementBlock("span", {
						key: 1,
						class: normalizeClass(["inline-flex gap-1", {
							"text-ui-danger": !maxLenValid.value || !minLenValid.value,
							"opacity-50": maxLenValid.value && minLenValid.value
						}])
					}, toDisplayString(_ctx.maxLen !== void 0 && _ctx.minLen === void 0 ? ` (max. ${_ctx.maxLen} Zeichen)` : "") + " " + toDisplayString(_ctx.minLen !== void 0 && _ctx.maxLen === void 0 ? ` (mind. ${_ctx.minLen} Zeichen)` : "") + " " + toDisplayString(_ctx.minLen !== void 0 && _ctx.maxLen !== void 0 && _ctx.minLen !== _ctx.maxLen ? ` (zwischen ${_ctx.minLen} und ${_ctx.maxLen} Zeichen)` : "") + " " + toDisplayString(_ctx.minLen !== void 0 && _ctx.maxLen !== void 0 && _ctx.minLen === _ctx.maxLen ? ` (genau ${_ctx.maxLen} Zeichen)` : ""), 3)) : createCommentVNode("", true),
					_ctx.required ? (openBlock(), createElementBlock("span", _hoisted_6)) : createCommentVNode("", true),
					_ctx.required ? (openBlock(), createElementBlock("span", _hoisted_7, "erforderlich")) : createCommentVNode("", true),
					isValid.value === false && !_ctx.required ? (openBlock(), createElementBlock("span", _hoisted_8)) : createCommentVNode("", true),
					_ctx.statistics ? (openBlock(), createElementBlock("span", _hoisted_9, [createVNode(_component_svws_ui_tooltip, { position: "right" }, {
						content: withCtx(() => [_ctx.validator !== void 0 && !_ctx.validator().getFehler().isEmpty() && _ctx.validator().getFehlerart() !== unref(ValidatorFehlerart).UNGENUTZT ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [_cache[4] || (_cache[4] = createBaseVNode("div", { class: "text-headline-sm text-center pt-1" }, " Relevant für die Statistik ", -1)), (openBlock(true), createElementBlock(Fragment, null, renderList(_ctx.validator().getFehler(), (fehler) => {
							return openBlock(), createElementBlock("div", {
								key: fehler.getFehlermeldung() ?? "--",
								class: "pt-2 pb-2"
							}, [createBaseVNode("div", { class: normalizeClass(["rounded-sm pl-2", {
								"bg-ui-danger": _ctx.validator().getFehlerart() === unref(ValidatorFehlerart).MUSS,
								"bg-ui-caution": _ctx.validator().getFehlerart() === unref(ValidatorFehlerart).KANN,
								"bg-ui-warning": _ctx.validator().getFehlerart() === unref(ValidatorFehlerart).HINWEIS
							}]) }, toDisplayString(fehler.getFehlerart()), 3), createBaseVNode("div", _hoisted_15, toDisplayString(fehler.getFehlermeldung()), 1)]);
						}), 128))], 64)) : (openBlock(), createElementBlock("div", _hoisted_16, " Relevant für die Statistik "))]),
						default: withCtx(() => [createBaseVNode("span", _hoisted_10, [_ctx.validator === void 0 || _ctx.validator().getFehlerart() === unref(ValidatorFehlerart).UNGENUTZT ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [_ctx.required && (data.value === "" || data.value === null || data.value === void 0) ? (openBlock(), createElementBlock("span", _hoisted_11)) : createCommentVNode("", true)], 64)) : !_ctx.validator().getFehler().isEmpty() ? (openBlock(), createElementBlock(Fragment, { key: 1 }, [
							_ctx.validator().getFehlerart() === unref(ValidatorFehlerart).MUSS ? (openBlock(), createElementBlock("span", _hoisted_12)) : createCommentVNode("", true),
							_ctx.validator().getFehlerart() === unref(ValidatorFehlerart).KANN ? (openBlock(), createElementBlock("span", _hoisted_13)) : createCommentVNode("", true),
							_ctx.validator().getFehlerart() === unref(ValidatorFehlerart).HINWEIS ? (openBlock(), createElementBlock("span", _hoisted_14)) : createCommentVNode("", true)
						], 64)) : createCommentVNode("", true)])]),
						_: 1
					})])) : createCommentVNode("", true),
					_ctx.readonly && !_ctx.isSelectInput ? (openBlock(), createElementBlock("span", _hoisted_17)) : createCommentVNode("", true)
				], 10, _hoisted_4)) : createCommentVNode("", true),
				_ctx.removable && _ctx.type === "date" && !_ctx.readonly ? (openBlock(), createElementBlock("span", {
					key: 5,
					onKeydown: _cache[0] || (_cache[0] = withKeys(($event) => updateData(""), ["enter"])),
					onClick: _cache[1] || (_cache[1] = withModifiers(($event) => updateData(""), ["stop"])),
					class: "svws-icon--remove icon i-ri-close-line",
					tabindex: "0"
				}, null, 32)) : createCommentVNode("", true),
				_ctx.type === "date" && !firefox() ? (openBlock(), createElementBlock("span", _hoisted_18)) : createCommentVNode("", true),
				_ctx.type === "email" ? (openBlock(), createElementBlock("span", _hoisted_19)) : createCommentVNode("", true),
				_ctx.type === "tel" ? (openBlock(), createElementBlock("span", _hoisted_20)) : createCommentVNode("", true)
			], 2);
		};
	}
});
var SvwsUiTextInput_default = SvwsUiTextInput_vue_vue_type_script_setup_true_lang_default;
export { SvwsUiTextInput_default as b };

//# sourceMappingURL=SvwsUiTextInput.js.map