import { $ as withCtx, C as createVNode, D as defineComponent, M as onMounted, N as onUnmounted, O as onUpdated, P as openBlock, R as renderList, S as renderSlot, a8 as ref, ag as normalizeClass, ai as toDisplayString, b as SvwsUiButton_default, r as Fragment, v as createBaseVNode, x as createCommentVNode, y as createElementBlock } from "./index.js";
const _hoisted_1 = {
	key: 0,
	class: "region-enumeration"
};
const _hoisted_2 = {
	key: 1,
	class: "region-enumeration"
};
const _hoisted_3 = ["onClick"];
const _hoisted_4 = { class: "svws-ui-tab-content" };
var SvwsUiTabBar_vue_vue_type_script_setup_true_lang_default = /* @__PURE__ */ defineComponent({
	__name: "SvwsUiTabBar",
	props: {
		tabManager: {},
		secondary: {
			type: Boolean,
			default: false
		},
		focusSwitchingEnabled: {
			type: Boolean,
			default: false
		},
		focusHelpVisible: {
			type: Boolean,
			default: false
		}
	},
	setup(__props) {
		const props = __props;
		let processingKeyboardEvent = false;
		const tabsListElement = ref();
		const state = ref({
			scrolled: false,
			scrolledMax: false,
			scrollFactor: 4,
			maxScrollLeft: 0,
			scrollOffset: 12
		});
		onMounted(() => {
			state.value.maxScrollLeft = (tabsListElement.value?.scrollWidth ?? 0) - (tabsListElement.value?.clientWidth ?? 0);
			state.value.scrolledMax = (tabsListElement.value?.scrollLeft ?? 0) >= state.value.maxScrollLeft;
			tabsListElement.value?.addEventListener("scroll", handleScroll);
			window.addEventListener("resize", handleScroll);
			window.addEventListener("keydown", switchTab);
		});
		onUnmounted(() => {
			tabsListElement.value?.removeEventListener("scroll", handleScroll);
			window.removeEventListener("resize", handleScroll);
			window.removeEventListener("keydown", switchTab);
		});
		onUpdated(() => {
			handleScroll();
		});
		function handleScroll() {
			state.value.scrolled = (tabsListElement.value?.scrollLeft ?? 0) > state.value.scrollOffset;
			state.value.maxScrollLeft = (tabsListElement.value?.scrollWidth ?? 0) - (tabsListElement.value?.clientWidth ?? 0);
			state.value.scrolledMax = (tabsListElement.value?.scrollLeft ?? 0) >= state.value.maxScrollLeft - state.value.scrollOffset;
		}
		function scroll(direction) {
			const dir = direction === "left" ? -1 : 1;
			tabsListElement.value?.scrollBy({
				top: 0,
				left: dir * tabsListElement.value.scrollWidth / state.value.scrollFactor,
				behavior: "smooth"
			});
		}
		function switchTab(event) {
			if (event.altKey && event.ctrlKey && !processingKeyboardEvent && !event.repeat && (event.key === "ArrowLeft" || event.key === "ArrowRight")) {
				processingKeyboardEvent = true;
				const backwards = event.key === "ArrowLeft";
				const newTab = backwards ? props.tabManager().prevTab : props.tabManager().nextTab;
				props.tabManager().setTab(newTab);
				processingKeyboardEvent = false;
			}
		}
		return (_ctx, _cache) => {
			const _component_svws_ui_button = SvwsUiButton_default;
			return openBlock(), createElementBlock("div", { class: normalizeClass({
				"svws-ui-page": !_ctx.secondary,
				"svws-single-tab": _ctx.tabManager().tabs.length === 1
			}) }, [
				createBaseVNode("div", { class: normalizeClass(["svws-ui-tabs", { "svws-ui-tabs--secondary": _ctx.secondary }]) }, [createBaseVNode("div", { class: normalizeClass(["svws-ui-tabs--wrapper", {
					"focus-region": _ctx.focusSwitchingEnabled,
					"highlighted": _ctx.tabManager().tabs.length > 1 && _ctx.focusHelpVisible
				}]) }, [
					_ctx.tabManager().tabs.length > 1 && _ctx.focusHelpVisible && _ctx.secondary ? (openBlock(), createElementBlock("p", _hoisted_1, "6")) : _ctx.tabManager().tabs.length > 1 && _ctx.focusHelpVisible ? (openBlock(), createElementBlock("p", _hoisted_2, "5")) : createCommentVNode("", true),
					state.value.scrolled ? (openBlock(), createElementBlock("div", {
						key: 2,
						class: "svws-ui-tabs--scroll-button -left-1 pl-1 bg-gradient-to-l",
						onClick: _cache[0] || (_cache[0] = ($event) => scroll("left"))
					}, [createVNode(_component_svws_ui_button, { type: "icon" }, {
						default: withCtx(() => [..._cache[2] || (_cache[2] = [createBaseVNode("span", { class: "icon i-ri-arrow-left-s-line" }, null, -1)])]),
						_: 1
					})])) : createCommentVNode("", true),
					createBaseVNode("div", {
						ref_key: "tabsListElement",
						ref: tabsListElement,
						class: "svws-ui-tabs--list"
					}, [(openBlock(true), createElementBlock(Fragment, null, renderList(props.tabManager().tabs, (tab, index) => {
						return openBlock(), createElementBlock(Fragment, { key: index }, [!(tab.hide === true) && tab.text !== "" ? (openBlock(), createElementBlock("button", {
							key: 0,
							onClick: ($event) => _ctx.tabManager().setTab(tab),
							class: normalizeClass(["svws-ui-tab-button flex flex-row", {
								"svws-active": tab.name === _ctx.tabManager().tab.name,
								"tabsFirstLevelFocusField": tab.name === _ctx.tabManager().tab.name && !_ctx.secondary,
								"tabsSecondLevelFocusField": tab.name === _ctx.tabManager().tab.name && _ctx.secondary
							}])
						}, [createBaseVNode("span", null, toDisplayString(tab.text), 1), renderSlot(_ctx.$slots, "badge", { tab })], 10, _hoisted_3)) : createCommentVNode("", true)], 64);
					}), 128))], 512),
					!state.value.scrolledMax ? (openBlock(), createElementBlock("div", {
						key: 3,
						class: "svws-ui-tabs--scroll-button -right-1 pr-1 bg-gradient-to-r justify-end",
						onClick: _cache[1] || (_cache[1] = ($event) => scroll("right"))
					}, [createVNode(_component_svws_ui_button, { type: "icon" }, {
						default: withCtx(() => [..._cache[3] || (_cache[3] = [createBaseVNode("span", { class: "icon i-ri-arrow-right-s-line" }, null, -1)])]),
						_: 1
					})])) : createCommentVNode("", true)
				], 2)], 2),
				_cache[4] || (_cache[4] = createBaseVNode("div", { class: "svws-sub-nav-target" }, null, -1)),
				createBaseVNode("div", _hoisted_4, [renderSlot(_ctx.$slots, "default")])
			], 2);
		};
	}
});
var SvwsUiTabBar_default = SvwsUiTabBar_vue_vue_type_script_setup_true_lang_default;
export { SvwsUiTabBar_default as b };

//# sourceMappingURL=SvwsUiTabBar.js.map