import { $ as withCtx, A as createStaticVNode, B as createTextVNode, C as createVNode, D as defineComponent, P as openBlock, S as renderSlot, X as useId, a1 as withDirectives, a4 as isRef, af as unref, ag as normalizeClass, ai as toDisplayString, b as SvwsUiButton_default, c as SvwsUiNotification_default, n as vModelRadio, r as Fragment, u as computed, v as createBaseVNode, w as createBlock, x as createCommentVNode, y as createElementBlock } from "./index.js";
import { b as SvwsUiTooltip_default, c as useColorMode } from "./SvwsUiTooltip.js";
import { b as SvwsUiSpacing_default } from "./SvwsUiSpacing.js";
import { b as SvwsUiContentCard_default } from "./SvwsUiContentCard.js";
var SvwsUiRadioGroup_vue_vue_type_script_setup_true_lang_default = /* @__PURE__ */ defineComponent({
	__name: "SvwsUiRadioGroup",
	props: { row: {
		type: Boolean,
		default: false
	} },
	setup(__props) {
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", { class: normalizeClass(["flex flex-col items-start gap-1", { "flex-row flex-wrap gap-0.5": _ctx.row }]) }, [renderSlot(_ctx.$slots, "default")], 2);
		};
	}
});
var SvwsUiRadioGroup_default = SvwsUiRadioGroup_vue_vue_type_script_setup_true_lang_default;
const _hoisted_1$2 = ["id"];
const _hoisted_2$2 = [
	"id",
	"name",
	"value",
	"disabled"
];
const _hoisted_3$1 = ["id"];
const _hoisted_4$1 = {
	key: 0,
	class: "icon i-ri-eye-line radio--indicator-icon--checked -my-0.5"
};
const _hoisted_5 = ["id"];
const _hoisted_6 = {
	key: 0,
	class: "cursor-pointer"
};
var SvwsUiRadioOption_vue_vue_type_script_setup_true_lang_default = /* @__PURE__ */ defineComponent({
	__name: "SvwsUiRadioOption",
	props: {
		name: { default: "" },
		label: { default: "" },
		value: {
			type: [
				Object,
				Number,
				String,
				Boolean
			],
			default: ""
		},
		disabled: {
			type: Boolean,
			default: false
		},
		statistics: {
			type: Boolean,
			default: false
		},
		icon: {
			type: Boolean,
			default: true
		},
		iconType: { default: "default" },
		modelValue: {
			type: [
				Object,
				Number,
				String,
				Boolean
			],
			default: ""
		},
		forceChecked: {
			type: Boolean,
			default: false
		}
	},
	emits: ["update:modelValue"],
	setup(__props, { emit: __emit }) {
		const props = __props;
		const emit = __emit;
		const checked = computed({
			get: () => props.modelValue,
			set: (value) => emit("update:modelValue", value)
		});
		const idComponent = useId();
		const idInputField = useId();
		const idIcon = useId();
		const idLabel = useId();
		return (_ctx, _cache) => {
			const _component_svws_ui_tooltip = SvwsUiTooltip_default;
			return openBlock(), createElementBlock("label", {
				id: unref(idComponent),
				class: normalizeClass(["radio--label", {
					"radio--label--disabled": _ctx.disabled,
					"radio--statistics": _ctx.statistics,
					"radio--label--no-icon": !_ctx.icon,
					"radio--label--no-text": !_ctx.label,
					"radio--icon-type-view": _ctx.iconType === "view"
				}])
			}, [
				withDirectives(createBaseVNode("input", {
					id: unref(idInputField),
					"onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => checked.value = $event),
					type: "radio",
					name: _ctx.name,
					value: _ctx.value,
					disabled: _ctx.disabled,
					class: "radio--indicator"
				}, null, 8, _hoisted_2$2), [[vModelRadio, checked.value]]),
				_ctx.icon ? (openBlock(), createElementBlock("span", {
					key: 0,
					id: unref(idIcon),
					class: "radio--indicator-icon"
				}, [_ctx.iconType === "view" ? (openBlock(), createElementBlock("span", _hoisted_4$1)) : renderSlot(_ctx.$slots, "default", { key: 1 }, () => [_cache[1] || (_cache[1] = createBaseVNode("span", { class: "icon i-ri-checkbox-blank-circle-line radio--indicator-icon--blank -my-0.5" }, null, -1)), _cache[2] || (_cache[2] = createBaseVNode("span", { class: "icon i-ri-checkbox-circle-line radio--indicator-icon--checked -my-0.5" }, null, -1))])], 8, _hoisted_3$1)) : createCommentVNode("", true),
				createBaseVNode("span", {
					id: unref(idLabel),
					class: "radio--label--text"
				}, [_ctx.statistics ? (openBlock(), createElementBlock("span", _hoisted_6, [createVNode(_component_svws_ui_tooltip, { position: "right" }, {
					content: withCtx(() => [..._cache[3] || (_cache[3] = [createTextVNode(" Relevant für die Statistik ", -1)])]),
					default: withCtx(() => [_cache[4] || (_cache[4] = createBaseVNode("span", { class: "inline-flex items-center" }, [createBaseVNode("span", { class: "icon i-ri-bar-chart-2-line radio--statistic-icon" })], -1))]),
					_: 1
				})])) : createCommentVNode("", true), createBaseVNode("span", null, toDisplayString(_ctx.label), 1)], 8, _hoisted_5)
			], 10, _hoisted_1$2);
		};
	}
});
var SvwsUiRadioOption_default = SvwsUiRadioOption_vue_vue_type_script_setup_true_lang_default;
const _hoisted_1$1 = {
	key: 0,
	class: "flex flex-col gap-2 text-left"
};
const _hoisted_2$1 = { key: 1 };
const _hoisted_3 = {
	key: 0,
	class: "icon i-ri-moon-line"
};
const _hoisted_4 = {
	key: 1,
	class: "icon i-ri-sun-line"
};
var UiColorMode_vue_vue_type_script_setup_true_lang_default = /* @__PURE__ */ defineComponent({
	__name: "UiColorMode",
	props: {
		mode: { default: "icons" },
		auto: {
			type: Boolean,
			default: false
		},
		warningDark: {
			type: Boolean,
			default: false
		},
		headless: {
			type: Boolean,
			default: false
		}
	},
	setup(__props) {
		const colormode = useColorMode();
		function next() {
			switch (colormode.value) {
				case "dark":
					colormode.value = "light";
					break;
				case "light":
					colormode.value = "dark";
					break;
				default: break;
			}
		}
		return (_ctx, _cache) => {
			const _component_svws_ui_radio_option = SvwsUiRadioOption_default;
			const _component_svws_ui_radio_group = SvwsUiRadioGroup_default;
			const _component_svws_ui_notification = SvwsUiNotification_default;
			const _component_svws_ui_button = SvwsUiButton_default;
			return !_ctx.headless ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [_ctx.mode === "radio" ? (openBlock(), createElementBlock("div", _hoisted_1$1, [
				_cache[4] || (_cache[4] = createBaseVNode("span", { class: "font-bold" }, "Theme", -1)),
				createVNode(_component_svws_ui_radio_group, { row: true }, {
					default: withCtx(() => [
						createVNode(_component_svws_ui_radio_option, {
							value: "light",
							modelValue: unref(colormode),
							"onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => isRef(colormode) ? colormode.value = $event : null),
							name: "colormode",
							label: "Light"
						}, null, 8, ["modelValue"]),
						createVNode(_component_svws_ui_radio_option, {
							value: "dark",
							modelValue: unref(colormode),
							"onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => isRef(colormode) ? colormode.value = $event : null),
							name: "colormode",
							label: "Dark"
						}, null, 8, ["modelValue"]),
						createVNode(_component_svws_ui_radio_option, {
							value: "auto",
							modelValue: unref(colormode),
							"onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => isRef(colormode) ? colormode.value = $event : null),
							name: "colormode",
							label: "System/Browsereinstellungen"
						}, null, 8, ["modelValue"])
					]),
					_: 1
				}),
				unref(colormode) === "dark" && _ctx.warningDark ? (openBlock(), createBlock(_component_svws_ui_notification, {
					key: 0,
					type: "warning"
				}, {
					default: withCtx(() => [..._cache[3] || (_cache[3] = [
						createTextVNode(" Achtung! Das Dark-Theme befindet sich gerade noch in der Entwicklung und ist noch nicht vollständig umgesetzt. ", -1),
						createBaseVNode("br", null, null, -1),
						createTextVNode("Es kann an einigen Stellen zu Darstellungsproblemen führen. ", -1)
					])]),
					_: 1
				})) : createCommentVNode("", true)
			])) : (openBlock(), createElementBlock("div", _hoisted_2$1, [createVNode(_component_svws_ui_button, {
				type: "icon",
				onClick: next,
				title: "Umschalten zwischen Dark-Mode und Light-Mode"
			}, {
				default: withCtx(() => [unref(colormode) === "dark" ? (openBlock(), createElementBlock("span", _hoisted_3)) : createCommentVNode("", true), unref(colormode) === "light" ? (openBlock(), createElementBlock("span", _hoisted_4)) : createCommentVNode("", true)]),
				_: 1
			})]))], 64)) : createCommentVNode("", true);
		};
	}
});
var UiColorMode_default = UiColorMode_vue_vue_type_script_setup_true_lang_default;
const _hoisted_1 = { class: "flex flex-col w-full h-full overflow-hidden" };
const _hoisted_2 = { class: "page page-grid-cards" };
var SConfigApp_vue_vue_type_script_setup_true_lang_default = /* @__PURE__ */ defineComponent({
	__name: "SConfigApp",
	props: { getCert: { type: Function } },
	setup(__props) {
		const props = __props;
		async function downloadZertifikat() {
			const { data, name } = await props.getCert();
			const link = document.createElement("a");
			link.href = URL.createObjectURL(data);
			link.download = name;
			link.target = "_blank";
			link.click();
			URL.revokeObjectURL(link.href);
		}
		return (_ctx, _cache) => {
			const _component_svws_ui_spacing = SvwsUiSpacing_default;
			const _component_svws_ui_button = SvwsUiButton_default;
			const _component_ui_color_mode = UiColorMode_default;
			const _component_svws_ui_content_card = SvwsUiContentCard_default;
			return openBlock(), createElementBlock("div", _hoisted_1, [_cache[2] || (_cache[2] = createStaticVNode("<header class=\"svws-ui-header max-w-[140rem]\"><div class=\"svws-ui-header--title gap-x-8 lg:gap-x-16 w-full\"><div class=\"svws-headline-wrapper flex-[2]\"><h2 class=\"svws-headline\"><span>Konfiguration des SVWS-Servers</span></h2><span class=\"svws-subline\"><span> Version: TODO </span></span></div></div><div class=\"svws-ui-header--actions\"></div></header>", 1)), createBaseVNode("div", _hoisted_2, [createVNode(_component_svws_ui_content_card, { title: "Im Aufbau" }, {
				default: withCtx(() => [
					_cache[1] || (_cache[1] = createTextVNode(" Diese Seite befindet sich im Aufbau und wird Anpassungen an einigen Konfigurationseinstellungen des SVWS-Servers ermöglichen. ", -1)),
					createVNode(_component_svws_ui_spacing, { size: 2 }),
					createVNode(_component_svws_ui_button, {
						type: "primary",
						onClick: downloadZertifikat
					}, {
						default: withCtx(() => [..._cache[0] || (_cache[0] = [createBaseVNode("span", { class: "icon-sm i-ri-upload-2-line" }, null, -1), createTextVNode("Zertifikat exportieren", -1)])]),
						_: 1
					}),
					createVNode(_component_svws_ui_spacing, { size: 2 }),
					createVNode(_component_ui_color_mode, {
						warning: "",
						mode: "radio",
						auto: ""
					})
				]),
				_: 1
			})])]);
		};
	}
});
var SConfigApp_default = SConfigApp_vue_vue_type_script_setup_true_lang_default;
export { SConfigApp_default as default };

//# sourceMappingURL=SConfigApp.js.map