import { $ as withCtx, B as createTextVNode, C as createVNode, D as defineComponent, M as onMounted, P as openBlock, S as renderSlot, a1 as withDirectives, a8 as ref, ag as normalizeClass, m as vModelCheckbox, u as computed, v as createBaseVNode, x as createCommentVNode, y as createElementBlock } from "./index.js";
import { b as SvwsUiTooltip_default } from "./SvwsUiTooltip.js";
const _hoisted_1 = { class: "inline-flex" };
const _hoisted_2 = ["title", "color"];
const _hoisted_3 = [
	"disabled",
	"indeterminate",
	"color"
];
const _hoisted_4 = {
	key: 2,
	class: "svws-ui-toggle--icon"
};
const _hoisted_5 = {
	key: 3,
	class: "svws-ui-checkbox--label"
};
const _hoisted_6 = {
	key: 0,
	class: "-mb-1 inline-block align-top"
};
const _hoisted_7 = {
	key: 0,
	class: "cursor-pointer"
};
var SvwsUiCheckbox_vue_vue_type_script_setup_true_lang_default = /* @__PURE__ */ defineComponent({
	__name: "SvwsUiCheckbox",
	props: {
		modelValue: { type: Boolean },
		statistics: {
			type: Boolean,
			default: false
		},
		disabled: {
			type: Boolean,
			default: false
		},
		bw: {
			type: Boolean,
			default: false
		},
		title: { default: void 0 },
		type: { default: "checkbox" },
		headless: {
			type: Boolean,
			default: false
		},
		indeterminate: {
			type: Boolean,
			default: false
		},
		readonly: {
			type: Boolean,
			default: false
		},
		color: { default: void 0 },
		autofocus: {
			type: Boolean,
			default: false
		},
		focusClassContent: {
			type: Boolean,
			default: false
		}
	},
	emits: ["update:modelValue"],
	setup(__props, { expose: __expose, emit: __emit }) {
		const props = __props;
		onMounted(() => doFocus());
		function doFocus() {
			if (props.autofocus) input.value?.focus();
		}
		const emit = __emit;
		const checked = computed({
			get: () => props.modelValue,
			set: (value) => {
				if (props.readonly === false) emit("update:modelValue", value);
			}
		});
		const input = ref(null);
		const content = computed(() => checked.value);
		__expose({
			content,
			input
		});
		return (_ctx, _cache) => {
			const _component_svws_ui_tooltip = SvwsUiTooltip_default;
			return openBlock(), createElementBlock("div", _hoisted_1, [createBaseVNode("label", {
				class: normalizeClass(["svws-ui-checkbox", {
					"svws-statistik": _ctx.statistics,
					"svws-headless": _ctx.headless && _ctx.type !== "toggle",
					"svws-bw": _ctx.bw,
					"svws-ui-toggle": _ctx.type === "toggle"
				}]),
				title: _ctx.title,
				color: _ctx.color
			}, [
				!_ctx.readonly ? withDirectives((openBlock(), createElementBlock("input", {
					key: 0,
					type: "checkbox",
					"onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => checked.value = $event),
					class: normalizeClass({
						"svws-headless": _ctx.headless && _ctx.type !== "toggle",
						"contentFocusField": _ctx.focusClassContent
					}),
					disabled: _ctx.disabled,
					indeterminate: _ctx.indeterminate,
					color: _ctx.color,
					ref_key: "input",
					ref: input
				}, null, 10, _hoisted_3)), [[vModelCheckbox, checked.value]]) : (openBlock(), createElementBlock("span", {
					key: 1,
					class: normalizeClass(checked.value ? "icon i-ri-checkbox-line" : "icon i-ri-checkbox-blank-line")
				}, null, 2)),
				_ctx.type === "toggle" ? (openBlock(), createElementBlock("span", _hoisted_4)) : createCommentVNode("", true),
				_ctx.$slots.default ? (openBlock(), createElementBlock("span", _hoisted_5, [_ctx.statistics ? (openBlock(), createElementBlock("span", _hoisted_6, [createVNode(_component_svws_ui_tooltip, { position: "right" }, {
					content: withCtx(() => [..._cache[3] || (_cache[3] = [createTextVNode("Relevant für die Statistik", -1)])]),
					default: withCtx(() => [_ctx.statistics ? (openBlock(), createElementBlock("span", _hoisted_7, [createVNode(_component_svws_ui_tooltip, { position: "right" }, {
						content: withCtx(() => [..._cache[1] || (_cache[1] = [createTextVNode(" Relevant für die Statistik ", -1)])]),
						default: withCtx(() => [_cache[2] || (_cache[2] = createBaseVNode("span", { class: "inline-flex items-center" }, [createBaseVNode("span", { class: "icon i-ri-bar-chart-2-line svws-ui-checkbox--statistic-icon" })], -1))]),
						_: 1
					})])) : createCommentVNode("", true)]),
					_: 1
				})])) : createCommentVNode("", true), renderSlot(_ctx.$slots, "default")])) : createCommentVNode("", true)
			], 10, _hoisted_2)]);
		};
	}
});
var SvwsUiCheckbox_default = SvwsUiCheckbox_vue_vue_type_script_setup_true_lang_default;
export { SvwsUiCheckbox_default as b };

//# sourceMappingURL=SvwsUiCheckbox.js.map