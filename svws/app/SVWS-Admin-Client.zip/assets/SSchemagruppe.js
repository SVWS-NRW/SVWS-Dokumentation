import { $ as withCtx, B as createTextVNode, C as createVNode, D as defineComponent, P as openBlock, R as renderList, a8 as ref, ai as toDisplayString, b as SvwsUiButton_default, j as ArrayList, r as Fragment, u as computed, v as createBaseVNode, w as createBlock, y as createElementBlock } from "./index.js";
import "./SvwsUiTooltip.js";
import { b as SvwsUiSpinner_default } from "./SvwsUiSpinner.js";
import "./ValidatorFehlerart.js";
import { b as UiCard_default } from "./UiCard.js";
const _hoisted_1 = { class: "page page-flex-col overflow-x-auto" };
const _hoisted_2 = {
	key: 0,
	class: "flex flex-col gap-y-4"
};
const _hoisted_3 = { class: "min-w-128 max-w-192" };
const _hoisted_4 = {
	key: 1,
	class: "icon i-ri-play-line"
};
const _hoisted_5 = {
	key: 1,
	class: "flex"
};
var SSchemagruppe_vue_vue_type_script_setup_true_lang_default = /* @__PURE__ */ defineComponent({
	__name: "SSchemagruppe",
	props: {
		apiStatus: {},
		apiUsername: {},
		auswahlGruppe: {},
		removeSchemata: { type: Function }
	},
	setup(__props) {
		const props = __props;
		const currentAction = ref("");
		const oldAction = ref({
			name: void 0,
			open: false
		});
		function setCurrentAction(newAction, open) {
			if (newAction === oldAction.value.name && !open) return;
			oldAction.value.name = currentAction.value;
			oldAction.value.open = currentAction.value === "" ? false : true;
			if (open === true) currentAction.value = newAction;
			else currentAction.value = "";
		}
		const checkDeletable = computed(() => {
			const log = new ArrayList();
			let result = true;
			if (currentAction.value === "delete") {
				for (const schema of props.auswahlGruppe) if (schema.username === props.apiUsername) {
					result = false;
					log.add("Schema " + schema.name + " kann nicht gelöscht werden, da es dem aktuell angemeldeten Benutzer " + schema.username + " zugeordnet ist.");
				}
			} else result = false;
			return [result, log];
		});
		return (_ctx, _cache) => {
			const _component_svws_ui_spinner = SvwsUiSpinner_default;
			const _component_svws_ui_button = SvwsUiButton_default;
			const _component_ui_card = UiCard_default;
			return openBlock(), createElementBlock("div", _hoisted_1, [_ctx.auswahlGruppe.length > 0 ? (openBlock(), createElementBlock("div", _hoisted_2, [createBaseVNode("div", _hoisted_3, [createVNode(_component_ui_card, {
				icon: "i-ri-delete-bin-line",
				title: "Löschen",
				subtitle: "Ausgewählte Schemata löschen.",
				"is-open": currentAction.value === "delete",
				"onUpdate:isOpen": _cache[0] || (_cache[0] = (isOpen) => setCurrentAction("delete", isOpen))
			}, {
				default: withCtx(() => [createBaseVNode("div", null, [checkDeletable.value[0] ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [
					_cache[1] || (_cache[1] = createBaseVNode("span", null, "Die folgenden Schemata werden gelöscht:", -1)),
					_cache[2] || (_cache[2] = createBaseVNode("br", null, null, -1)),
					createBaseVNode("ul", null, [(openBlock(true), createElementBlock(Fragment, null, renderList(_ctx.auswahlGruppe, (schema) => {
						return openBlock(), createElementBlock("li", { key: schema.name }, toDisplayString(schema.name), 1);
					}), 128))])
				], 64)) : (openBlock(true), createElementBlock(Fragment, { key: 1 }, renderList(checkDeletable.value[1], (message) => {
					return openBlock(), createElementBlock("span", {
						key: message,
						class: "text-ui-danger"
					}, [createTextVNode(toDisplayString(message) + " ", 1), _cache[3] || (_cache[3] = createBaseVNode("br", null, null, -1))]);
				}), 128)), createVNode(_component_svws_ui_button, {
					disabled: !checkDeletable.value[0] || _ctx.apiStatus.pending,
					title: "Löschen",
					onClick: _ctx.removeSchemata,
					"is-loading": _ctx.apiStatus.pending,
					class: "mt-4"
				}, {
					default: withCtx(() => [_ctx.apiStatus.pending ? (openBlock(), createBlock(_component_svws_ui_spinner, {
						key: 0,
						spinning: ""
					})) : (openBlock(), createElementBlock("span", _hoisted_4)), _cache[4] || (_cache[4] = createTextVNode(" Löschen ", -1))]),
					_: 1
				}, 8, [
					"disabled",
					"onClick",
					"is-loading"
				])])]),
				_: 1
			}, 8, ["is-open"])])])) : (openBlock(), createElementBlock("div", _hoisted_5, [createVNode(_component_svws_ui_spinner, { spinning: "" }), _cache[5] || (_cache[5] = createBaseVNode("span", null, "\xA0Laden des zuletzt ausgewählten Schemas …", -1))]))]);
		};
	}
});
var SSchemagruppe_default = SSchemagruppe_vue_vue_type_script_setup_true_lang_default;
export { SSchemagruppe_default as default };

//# sourceMappingURL=SSchemagruppe.js.map