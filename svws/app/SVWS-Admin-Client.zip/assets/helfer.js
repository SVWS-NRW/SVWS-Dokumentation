import { $ as withCtx, B as createTextVNode, C as createVNode, D as defineComponent, I as mergeProps, J as nextTick, M as onMounted, P as openBlock, R as renderList, S as renderSlot, X as useId, Z as watch, a8 as ref, aa as shallowRef, ab as toRaw, af as unref, ag as normalizeClass, ah as normalizeStyle, ai as toDisplayString, b as SvwsUiButton_default, p as withKeys, q as withModifiers, r as Fragment, s as Teleport, u as computed, v as createBaseVNode, w as createBlock, x as createCommentVNode, y as createElementBlock } from "./index.js";
import { d as useFloating, e as autoUpdate, f as flip, g as offset, h as shift, i as size } from "./SvwsUiTooltip.js";
import { b as SvwsUiTextInput_default } from "./SvwsUiTextInput.js";
const _hoisted_1$2 = {
	key: 0,
	class: "w-full h-full overflow-x-auto overflow-y-hidden mt-4"
};
const _hoisted_2$2 = { class: "flex mb-2 text-headline-md gap-1 items-center" };
const _hoisted_3$2 = {
	key: 0,
	class: "icon i-ri-checkbox-circle-fill mr-3 icon-ui-success"
};
const _hoisted_4$1 = {
	key: 1,
	class: "icon i-ri-alert-fill mr-3 icon-ui-danger"
};
const _hoisted_5$1 = { class: "bg-ui-0 text-ui-0 rounded-xl" };
const _hoisted_6 = { class: "max-h-96 w-full overflow-auto" };
const _hoisted_7 = {
	key: 0,
	class: "py-2 px-3 w-px"
};
var LogBox_vue_vue_type_script_setup_true_lang_default = /* @__PURE__ */ defineComponent({
	__name: "LogBox",
	props: {
		logs: { default: void 0 },
		status: {
			type: Boolean,
			default: void 0
		},
		hfull: {
			type: Boolean,
			default: false
		}
	},
	setup(__props) {
		const props = __props;
		const copied = ref(null);
		const log = computed(() => {
			if (props.logs === void 0) return;
			let result = "";
			for (const s of props.logs) if (s !== null) result += s + "\n";
			return result;
		});
		async function copyToClipboard() {
			if (log.value === void 0) return;
			try {
				await navigator.clipboard.writeText("```\n" + log.value + "\n```");
			} catch (e) {
				copied.value = false;
			}
			copied.value = true;
		}
		return (_ctx, _cache) => {
			const _component_svws_ui_button = SvwsUiButton_default;
			return _ctx.logs !== null ? (openBlock(), createElementBlock("div", _hoisted_1$2, [createBaseVNode("div", null, [createBaseVNode("span", _hoisted_2$2, [
				_ctx.status === true ? (openBlock(), createElementBlock("span", _hoisted_3$2)) : _ctx.status === false ? (openBlock(), createElementBlock("span", _hoisted_4$1)) : createCommentVNode("", true),
				log.value !== void 0 ? (openBlock(), createBlock(_component_svws_ui_button, {
					key: 2,
					type: "transparent",
					onClick: copyToClipboard
				}, {
					default: withCtx(() => [copied.value === null ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [_cache[0] || (_cache[0] = createBaseVNode("span", { class: "icon i-ri-file-copy-line" }, null, -1)), _cache[1] || (_cache[1] = createBaseVNode("span", null, "Log kopieren", -1))], 64)) : copied.value === false ? (openBlock(), createElementBlock(Fragment, { key: 1 }, [_cache[2] || (_cache[2] = createBaseVNode("span", null, "Kopieren fehlgeschlagen", -1)), _cache[3] || (_cache[3] = createBaseVNode("span", { class: "icon i-ri-error-warning-fill" }, null, -1))], 64)) : (openBlock(), createElementBlock(Fragment, { key: 2 }, [_cache[4] || (_cache[4] = createBaseVNode("span", null, "Log kopiert", -1)), _cache[5] || (_cache[5] = createBaseVNode("span", { class: "icon i-ri-check-line icon-ui-success" }, null, -1))], 64))]),
					_: 1
				})) : createCommentVNode("", true),
				renderSlot(_ctx.$slots, "button")
			])]), createBaseVNode("div", _hoisted_5$1, [createBaseVNode("div", _hoisted_6, [_ctx.status !== void 0 ? (openBlock(), createElementBlock("pre", _hoisted_7, toDisplayString(log.value), 1)) : createCommentVNode("", true)])])])) : createCommentVNode("", true);
		};
	}
});
var LogBox_default = LogBox_vue_vue_type_script_setup_true_lang_default;
const _hoisted_1$1 = ["id"];
const _hoisted_2$1 = {
	key: 0,
	class: "px-2 py-1.5 text-base text-ui-disabled inline-block"
};
const _hoisted_3$1 = [
	"id",
	"aria-selected",
	"onClick"
];
const _hoisted_4 = {
	key: 0,
	class: "opacity-25"
};
const _hoisted_5 = {
	key: 2,
	class: "icon i-ri-check-line w-5 shrink-0 -mr-1 -my-1 relative top-1.5"
};
var SvwsUiDropdownList_vue_vue_type_script_setup_true_lang_default = /* @__PURE__ */ defineComponent({
	__name: "SvwsUiDropdownList",
	props: {
		statistics: {
			type: Boolean,
			default: false
		},
		selectedItemList: { default: () => /* @__PURE__ */ new Set() },
		filteredList: {},
		itemText: {
			type: Function,
			default: (item) => ""
		},
		selectItem: {
			type: Function,
			default: (item) => void 0
		},
		strategy: { default: void 0 },
		floatingLeft: { default: "" },
		floatingTop: { default: "" },
		searchText: { default: "" },
		noItemsText: { default: "Keine Einträge gefunden" },
		highlightItem: { default: void 0 }
	},
	setup(__props, { expose: __expose }) {
		const props = __props;
		const floating = ref(null);
		const listIdPrefix = useId();
		const itemRefs = shallowRef([]);
		const activeItemIndex = ref(-1);
		const listEmpty = computed(() => {
			for (const _ of props.filteredList) return false;
			return true;
		});
		__expose({
			activeItemIndex,
			floating,
			itemRefs
		});
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", {
				class: normalizeClass(["svws-ui-dropdown-list", { "svws-statistik": _ctx.statistics }]),
				id: "svws-ui-dropdown-list-id",
				style: normalizeStyle({
					position: _ctx.strategy,
					top: _ctx.floatingTop,
					left: _ctx.floatingLeft
				}),
				ref_key: "floating",
				ref: floating
			}, [createBaseVNode("ul", {
				id: unref(listIdPrefix),
				class: "svws-ui-dropdown-list--items",
				role: "listbox",
				onMouseenter: _cache[1] || (_cache[1] = ($event) => activeItemIndex.value = -1)
			}, [listEmpty.value ? (openBlock(), createElementBlock("li", _hoisted_2$1, [!_ctx.searchText ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [createTextVNode(toDisplayString(_ctx.noItemsText), 1)], 64)) : (openBlock(), createElementBlock(Fragment, { key: 1 }, [createTextVNode(" Keine Ergebnisse für \"" + toDisplayString(_ctx.searchText) + "\" ", 1)], 64))])) : createCommentVNode("", true), (openBlock(true), createElementBlock(Fragment, null, renderList(_ctx.filteredList, (item, index) => {
				return renderSlot(_ctx.$slots, "item", {
					key: index,
					item,
					index
				}, () => [createBaseVNode("li", {
					id: `${unref(listIdPrefix)}-${index}`,
					ref_for: true,
					ref_key: "itemRefs",
					ref: itemRefs,
					role: "option",
					class: normalizeClass(["svws-ui-dropdown-list--item", {
						"svws-active": activeItemIndex.value === index,
						"svws-selected": _ctx.selectedItemList.has(item)
					}]),
					"aria-selected": _ctx.selectedItemList.has(item) ? "true" : "false",
					onMousedown: _cache[0] || (_cache[0] = withModifiers(() => {}, ["prevent"])),
					onClick: ($event) => _ctx.selectItem(item)
				}, [_ctx.itemText(item).length === 0 ? (openBlock(), createElementBlock("span", _hoisted_4, "—")) : (openBlock(), createElementBlock("span", {
					key: 1,
					class: normalizeClass({ "font-bold": _ctx.highlightItem === item })
				}, toDisplayString(_ctx.itemText(item)), 3)), _ctx.selectedItemList.has(item) ? (openBlock(), createElementBlock("span", _hoisted_5)) : createCommentVNode("", true)], 42, _hoisted_3$1)]);
			}), 128))], 40, _hoisted_1$1)], 6);
		};
	}
});
var SvwsUiDropdownList_default = SvwsUiDropdownList_vue_vue_type_script_setup_true_lang_default;
const _hoisted_1 = {
	key: 1,
	role: "button",
	class: "svws-dropdown-icon",
	tabindex: "-1"
};
const _hoisted_2 = {
	key: 0,
	class: "icon i-ri-expand-up-down-line svws-ui-select--icon"
};
const _hoisted_3 = {
	key: 1,
	class: "icon i-ri-expand-up-down-fill svws-ui-select--icon"
};
var SvwsUiSelect_vue_vue_type_script_setup_true_lang_default = /* @__PURE__ */ defineComponent({
	__name: "SvwsUiSelect",
	props: {
		label: { default: "" },
		title: { default: "" },
		autocomplete: {
			type: Boolean,
			default: false
		},
		disabled: {
			type: Boolean,
			default: false
		},
		readonly: {
			type: Boolean,
			default: false
		},
		statistics: {
			type: Boolean,
			default: false
		},
		danger: {
			type: Boolean,
			default: false
		},
		items: {},
		itemText: {},
		emptyText: {
			type: Function,
			default: () => ""
		},
		itemSort: {
			type: Function,
			default: (a, b) => 0
		},
		itemFilter: {
			type: Function,
			default: (items) => items
		},
		modelValue: {},
		useNull: {
			type: Boolean,
			default: false
		},
		headless: {
			type: Boolean,
			default: false
		},
		removable: {
			type: Boolean,
			default: false
		},
		required: { type: Boolean },
		indeterminate: {
			type: Boolean,
			default: false
		},
		highlightItem: { default: void 0 },
		autofocus: {
			type: Boolean,
			default: false
		},
		focusClassContent: {
			type: Boolean,
			default: false
		},
		focusClassSubNav: {
			type: Boolean,
			default: false
		},
		noItemsText: { default: void 0 }
	},
	emits: ["update:modelValue"],
	setup(__props, { expose: __expose, emit: __emit }) {
		const props = __props;
		const emit = __emit;
		const refList = ref(null);
		const showList = ref(false);
		const inputEl = ref();
		const hasFocus = ref(false);
		const searchText = ref("");
		const listIdPrefix = useId();
		const isMounted = ref(false);
		onMounted(() => isMounted.value = true);
		function onInputFocus() {
			hasFocus.value = true;
		}
		function onInputBlur() {
			hasFocus.value = false;
			closeListbox();
		}
		const dynModelValue = computed(() => {
			return showList.value && props.autocomplete ? searchText.value : generateInputText();
		});
		function generateInputText() {
			if (selectedItem.value === null || selectedItem.value === void 0) return props.emptyText();
			return props.itemText(selectedItem.value);
		}
		function onInput(value) {
			if (props.autocomplete && (refList.value === void 0 || refList.value === null) && document.hasFocus() && inputEl.value !== null && document.activeElement === inputEl.value) openListbox();
			const activeItem = refList.value === void 0 || refList.value === null ? void 0 : filteredList.value.at(refList.value.activeItemIndex);
			searchText.value = value ?? "";
			if (props.autocomplete) nextTick(() => {
				if (refList.value !== void 0 && refList.value !== null) {
					let index = 0;
					if (activeItem !== void 0) {
						const tmpIndex = filteredList.value.findIndex((item) => item === activeItem);
						if (tmpIndex >= 0) index = tmpIndex;
					} else if (selectedItem.value !== null && selectedItem.value !== void 0) {
						const tmpIndex = filteredList.value.findIndex((item) => item === selectedItem.value);
						if (tmpIndex >= 0) index = tmpIndex;
					}
					refList.value.activeItemIndex = index;
				}
			});
		}
		const data = shallowRef(props.modelValue);
		watch(() => props.modelValue, (value) => updateData(toRaw(value), true), { immediate: false });
		function updateData(value, fromModelValue) {
			if ((value === null || value === void 0) && (data.value === null || data.value === void 0)) return;
			if (data.value === value) return;
			data.value = value;
			if (!fromModelValue) emit("update:modelValue", data.value);
			if (props.indeterminate === true) data.value = void 0;
		}
		const selectedItem = computed({
			get: () => data.value,
			set: (item) => updateData(item, false)
		});
		const selectedItemList = computed(() => {
			const set = /* @__PURE__ */ new Set();
			if (data.value !== null && data.value !== void 0) set.add(toRaw(data.value));
			return set;
		});
		const hasSelected = computed(() => selectedItem.value !== null && selectedItem.value !== void 0);
		function selectItem(item) {
			selectedItem.value = item;
			if (props.autocomplete) searchText.value = "";
			closeListbox();
			doFocus();
		}
		function removeItem() {
			selectedItem.value = props.useNull ? null : void 0;
			doFocus();
		}
		function reset(originalValue) {
			if (originalValue === true) selectedItem.value = props.modelValue;
			else selectedItem.value = props.useNull ? null : void 0;
			const el = inputEl.value;
			el?.input.blur();
		}
		const sortedList = computed(() => {
			let arr;
			if (Array.isArray(props.items)) arr = props.items;
			else if (props.items instanceof Map) arr = [...props.items.values()];
			else arr = [...props.items];
			return arr.sort(props.itemSort);
		});
		watch(sortedList, (items) => {
			for (const item of items) if (item === data.value) return;
			data.value = void 0;
		});
		const filteredList = computed(() => {
			if (props.autocomplete) {
				const isCurrent = selectedItem.value !== null && selectedItem.value !== void 0 && props.itemText(selectedItem.value) === searchText.value;
				if (isCurrent) return sortedList.value;
				return props.itemFilter(sortedList.value, searchText.value);
			}
			return sortedList.value;
		});
		function doFocus() {
			const el = inputEl.value;
			el?.input.focus();
		}
		function toggleListBox() {
			if (showList.value) closeListbox();
			else openListbox();
		}
		function openListbox() {
			doFocus();
			showList.value = true;
			nextTick(() => {
				if (refList.value === void 0 || refList.value === null) return;
				if (selectedItem.value !== null && selectedItem.value !== void 0) refList.value.activeItemIndex = filteredList.value.findIndex((item) => item === selectedItem.value);
				else refList.value.activeItemIndex = 0;
				if (refList.value.itemRefs[refList.value.activeItemIndex] !== void 0) refList.value.itemRefs[refList.value.activeItemIndex].scrollIntoView();
			});
		}
		function closeListbox() {
			if (refList.value !== void 0 && refList.value !== null) refList.value.activeItemIndex = -1;
			showList.value = false;
		}
		function selectCurrentActiveItem() {
			if (refList.value === void 0 || refList.value === null || refList.value.activeItemIndex < 0) return;
			selectItem(filteredList.value[refList.value.activeItemIndex]);
		}
		function onArrowDown() {
			if (!showList.value || refList.value === void 0 || refList.value === null) return openListbox();
			const listLength = filteredList.value.length;
			if (refList.value.activeItemIndex < listLength - 1) refList.value.activeItemIndex++;
			else refList.value.activeItemIndex = 0;
			refList.value.itemRefs[refList.value.activeItemIndex].scrollIntoView();
		}
		function onArrowUp() {
			if (!showList.value || refList.value === void 0 || refList.value === null) return openListbox();
			const listLength = filteredList.value.length;
			if (refList.value.activeItemIndex === 0) refList.value.activeItemIndex = listLength - 1;
			else if (refList.value.activeItemIndex >= 1) refList.value.activeItemIndex--;
			refList.value.itemRefs[refList.value.activeItemIndex].scrollIntoView();
		}
		function onBackspace() {
			if (showList.value === false) openListbox();
		}
		function onSpace(e) {
			if (!props.autocomplete) {
				if (!showList.value) openListbox();
				else selectCurrentActiveItem();
				e.preventDefault();
			}
		}
		function onTab() {
			if (props.autocomplete && refList.value !== void 0 && refList.value !== null) {
				refList.value.activeItemIndex = 0;
				selectCurrentActiveItem();
			}
		}
		const { x, y, strategy } = useFloating(inputEl, refList, {
			placement: "bottom",
			middleware: [
				flip(),
				shift(),
				offset(2),
				size({ apply({ rects, elements }) {
					Object.assign(elements.floating.style, { width: `${rects.reference.width}px` });
				} })
			],
			whileElementsMounted: autoUpdate
		});
		const floatingTop = computed(() => `${y.value}px`);
		const floatingLeft = computed(() => `${x.value}px`);
		const content = computed(() => data.value);
		__expose({
			content,
			reset
		});
		return (_ctx, _cache) => {
			const _component_svws_ui_text_input = SvwsUiTextInput_default;
			return openBlock(), createElementBlock(Fragment, null, [createBaseVNode("div", mergeProps({ class: ["svws-ui-select", {
				"svws-open": showList.value,
				"svws-has-value": hasSelected.value,
				"svws-headless": _ctx.headless,
				"svws-statistik": _ctx.statistics,
				"svws-danger": _ctx.danger,
				"svws-disabled": _ctx.disabled,
				"svws-removable": _ctx.removable,
				"svws-readonly": _ctx.readonly
			}] }, _ctx.$attrs), [
				createVNode(_component_svws_ui_text_input, {
					ref_key: "inputEl",
					ref: inputEl,
					"model-value": dynModelValue.value,
					readonly: !_ctx.autocomplete || _ctx.readonly,
					"is-select-input": !_ctx.readonly,
					placeholder: _ctx.label || _ctx.title,
					statistics: _ctx.statistics,
					headless: _ctx.headless,
					disabled: _ctx.disabled,
					required: _ctx.required,
					role: "combobox",
					"aria-label": _ctx.label || _ctx.title,
					"aria-expanded": showList.value,
					"aria-haspopup": "listbox",
					"aria-autocomplete": "list",
					"aria-controls": showList.value ? unref(listIdPrefix) : null,
					"aria-activedescendant": refList.value && refList.value.activeItemIndex > -1 ? `${unref(listIdPrefix)}-${refList.value.activeItemIndex}` : null,
					"onUpdate:modelValue": onInput,
					onClick: withModifiers(toggleListBox, ["stop"]),
					onFocus: onInputFocus,
					onBlur: onInputBlur,
					onKeyup: [_cache[0] || (_cache[0] = withKeys(withModifiers(() => {}, ["prevent"]), ["down"])), _cache[1] || (_cache[1] = withKeys(withModifiers(() => {}, ["prevent"]), ["up"]))],
					onKeydown: [
						withKeys(withModifiers(onArrowDown, ["prevent"]), ["down"]),
						withKeys(withModifiers(onArrowUp, ["prevent"]), ["up"]),
						withKeys(withModifiers(selectCurrentActiveItem, ["prevent"]), ["enter"]),
						withKeys(onBackspace, ["backspace"]),
						withKeys(withModifiers(toggleListBox, ["prevent"]), ["esc"]),
						withKeys(onSpace, ["space"]),
						withKeys(onTab, ["tab"])
					],
					focus: _ctx.autofocus,
					class: normalizeClass({
						"contentFocusField": _ctx.focusClassContent,
						"subNavigationFocusField": _ctx.focusClassSubNav
					})
				}, null, 8, [
					"model-value",
					"readonly",
					"is-select-input",
					"placeholder",
					"statistics",
					"headless",
					"disabled",
					"required",
					"aria-label",
					"aria-expanded",
					"aria-controls",
					"aria-activedescendant",
					"onKeydown",
					"focus",
					"class"
				]),
				_ctx.removable && hasSelected.value && !_ctx.readonly ? (openBlock(), createElementBlock("button", {
					key: 0,
					role: "button",
					onClick: withModifiers(removeItem, ["stop"]),
					class: "svws-remove"
				}, [..._cache[2] || (_cache[2] = [createBaseVNode("span", { class: "icon i-ri-close-line svws-ui-select--icon" }, null, -1)])])) : createCommentVNode("", true),
				!_ctx.readonly ? (openBlock(), createElementBlock("button", _hoisted_1, [_ctx.headless ? (openBlock(), createElementBlock("span", _hoisted_2)) : (openBlock(), createElementBlock("span", _hoisted_3))])) : createCommentVNode("", true)
			], 16), isMounted.value ? (openBlock(), createBlock(Teleport, {
				key: 0,
				to: "body"
			}, [showList.value ? (openBlock(), createBlock(SvwsUiDropdownList_default, {
				key: 0,
				statistics: _ctx.statistics,
				"filtered-list": filteredList.value,
				"item-text": _ctx.itemText,
				strategy: unref(strategy),
				"floating-left": floatingLeft.value,
				"floating-top": floatingTop.value,
				"selected-item-list": selectedItemList.value,
				"select-item": selectItem,
				ref_key: "refList",
				ref: refList,
				"search-text": searchText.value,
				"highlight-item": _ctx.highlightItem,
				"no-items-text": _ctx.noItemsText
			}, null, 8, [
				"statistics",
				"filtered-list",
				"item-text",
				"strategy",
				"floating-left",
				"floating-top",
				"selected-item-list",
				"search-text",
				"highlight-item",
				"no-items-text"
			])) : createCommentVNode("", true)])) : createCommentVNode("", true)], 64);
		};
	}
});
var SvwsUiSelect_default = SvwsUiSelect_vue_vue_type_script_setup_true_lang_default;
function validatorSchemaName(str) {
	return str !== null && !/[^0-9,a-z,A-Z$_]/.test(str);
}
export { validatorSchemaName as b, SvwsUiSelect_default as c, LogBox_default as d };

//# sourceMappingURL=helfer.js.map