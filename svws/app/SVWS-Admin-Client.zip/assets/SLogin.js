import { $ as withCtx, B as createTextVNode, C as createVNode, D as defineComponent, P as openBlock, S as renderSlot, Z as watch, a8 as ref, aa as shallowRef, af as unref, ag as normalizeClass, ai as toDisplayString, b as SvwsUiButton_default, e as githash, f as version, l as Transition, p as withKeys, u as computed, v as createBaseVNode, w as createBlock, x as createCommentVNode, y as createElementBlock } from "./index.js";
import { c as __plugin_vue_export_helper_default } from "./SvwsUiModal.js";
import "./SvwsUiTooltip.js";
import { b as DatenschutzModal_default } from "./DatenschutzModal.js";
import { b as SvwsUiInputWrapper_default } from "./SvwsUiInputWrapper.js";
import { b as SvwsUiSpacing_default } from "./SvwsUiSpacing.js";
import { b as SvwsUiSpinner_default } from "./SvwsUiSpinner.js";
import "./ValidatorFehlerart.js";
import { b as SvwsUiTextInput_default } from "./SvwsUiTextInput.js";
const _hoisted_1$1 = { class: "h-screen w-screen overflow-hidden bg-ui" };
const _hoisted_2$1 = { class: "h-full w-full overflow-hidden flex flex-col justify-center items-center bg-top bg-cover bg-[url(@images/bglogin.jpg)]" };
const _hoisted_3$1 = {
	key: 0,
	class: "h-[1rem] w-full",
	style: { "background": "repeating-linear-gradient( -45deg, #000, #000 10px, #ffff00 10px, #ffff00 20px )" }
};
const _hoisted_4$1 = { class: "p-4 w-full h-full overflow-hidden text-center flex flex-col gap-4" };
const _hoisted_5$1 = {
	key: 0,
	class: "w-full flex flex-col gap-2"
};
const _hoisted_6$1 = {
	key: 0,
	class: "text-headline-sm leading-none w-full"
};
const _hoisted_7 = {
	key: 1,
	class: "text-sm font-medium px-1"
};
const _hoisted_8 = { class: "flex gap-2 items-center opacity-50" };
const _hoisted_9 = { class: "text-left flex flex-col leading-5" };
const _hoisted_10 = { class: "flex gap-2 place-items-center" };
const _hoisted_11 = { class: "font-bold" };
const _hoisted_12 = { key: 0 };
const _hoisted_13 = ["href"];
const _hoisted_14 = {
	key: 0,
	class: "icon-sm i-ri-file-copy-line"
};
const _hoisted_15 = {
	key: 1,
	class: "icon-sm i-ri-error-warning-fill"
};
const _hoisted_16 = {
	key: 2,
	class: "icon-sm i-ri-check-line icon-ui-brand"
};
const _hoisted_17 = { class: "flex items-center gap-2" };
const _hoisted_18 = ["onClick"];
const _hoisted_19 = {
	key: 2,
	class: "opacity-50 text-sm text-left px-1"
};
var UiLoginLayout_vue_vue_type_script_setup_true_lang_default = /* @__PURE__ */ defineComponent({
	__name: "UiLoginLayout",
	props: {
		version: { default: void 0 },
		githash: { default: void 0 },
		size: { default: "sm" },
		application: { default: void 0 },
		hideHeader: {
			type: Boolean,
			default: false
		},
		hideHinweis: {
			type: Boolean,
			default: false
		},
		underConstruction: {
			type: Boolean,
			default: false
		}
	},
	setup(__props) {
		const props = __props;
		const copied = ref(null);
		async function copyToClipboard() {
			try {
				await navigator.clipboard.writeText(`${props.version} ${props.githash}`);
			} catch (e) {
				copied.value = false;
			}
			copied.value = true;
		}
		const classSize = computed(() => {
			switch (props.size) {
				case "sm": return "modal--sm";
				case "md": return "modal--md";
				case "lg": return "modal--lg";
				default: return "";
			}
		});
		return (_ctx, _cache) => {
			const _component_datenschutz_modal = DatenschutzModal_default;
			return openBlock(), createElementBlock("div", _hoisted_1$1, [createBaseVNode("div", _hoisted_2$1, [createBaseVNode("div", { class: normalizeClass(["h-fit max-h-full w-full overflow-hidden m-auto flex flex-col items-center bg-ui text-ui border border-ui rounded-xl", classSize.value]) }, [_ctx.underConstruction ? (openBlock(), createElementBlock("span", _hoisted_3$1)) : createCommentVNode("", true), createBaseVNode("div", _hoisted_4$1, [
				!_ctx.hideHeader ? (openBlock(), createElementBlock("div", _hoisted_5$1, [
					_cache[0] || (_cache[0] = createBaseVNode("h1", { class: "text-headline-xl" }, "SVWS NRW", -1)),
					_cache[1] || (_cache[1] = createBaseVNode("h2", { class: "text-headline-sm opacity-50" }, [
						createTextVNode(" Schulverwaltung für"),
						createBaseVNode("br"),
						createTextVNode("Nordrhein-Westfalen ")
					], -1)),
					_ctx.application !== void 0 ? (openBlock(), createElementBlock("h2", _hoisted_6$1, toDisplayString(_ctx.application), 1)) : createCommentVNode("", true)
				])) : createCommentVNode("", true),
				createBaseVNode("div", { class: normalizeClass(["w-full min-h-fit overflow-y-auto flex flex-col px-1", {
					"pb-4": !_ctx.hideHinweis && _ctx.version === void 0,
					"pt-4": !_ctx.hideHeader
				}]) }, [renderSlot(_ctx.$slots, "main", {}, void 0, true)], 2),
				_ctx.version !== void 0 ? (openBlock(), createElementBlock("div", _hoisted_7, [createBaseVNode("div", _hoisted_8, [renderSlot(_ctx.$slots, "logo", {}, void 0, true), createBaseVNode("div", _hoisted_9, [
					_cache[3] || (_cache[3] = createBaseVNode("span", { class: "font-bold" }, "SVWS-NRW", -1)),
					createBaseVNode("div", _hoisted_10, [createBaseVNode("div", null, [createBaseVNode("span", _hoisted_11, "v" + toDisplayString(_ctx.version), 1), _ctx.version.includes("SNAPSHOT") ? (openBlock(), createElementBlock("span", _hoisted_12, [createBaseVNode("a", { href: `https://github.com/SVWS-NRW/SVWS-Server/commit/${_ctx.githash}` }, " \xA0" + toDisplayString(_ctx.githash.substring(0, 8)), 9, _hoisted_13)])) : createCommentVNode("", true)]), createBaseVNode("div", {
						onClick: copyToClipboard,
						class: "cursor-pointer place-items-center flex"
					}, [copied.value === null ? (openBlock(), createElementBlock("span", _hoisted_14)) : copied.value === false ? (openBlock(), createElementBlock("span", _hoisted_15)) : (openBlock(), createElementBlock("span", _hoisted_16))])]),
					createBaseVNode("nav", _hoisted_17, [_cache[2] || (_cache[2] = createBaseVNode("a", {
						class: "login-footer-link",
						href: "#"
					}, "Impressum", -1)), createVNode(_component_datenschutz_modal, null, {
						default: withCtx(({ openModal }) => [createBaseVNode("a", {
							class: "login-footer-link",
							href: "#",
							onClick: ($event) => openModal()
						}, "Datenschutz", 8, _hoisted_18)]),
						_: 1
					})])
				])])])) : createCommentVNode("", true),
				!_ctx.hideHinweis ? (openBlock(), createElementBlock("p", _hoisted_19, " Hinweis: Um eine gute Lesbarkeit zu erzeugen, wird bei SVWS-NRW möglichst auf geschlechtsneutrale Begriffe wie Lehrkräfte, Klassenleitung, Erziehungsberechtigte usw. zurückgegriffen. An Stellen, wo das nicht möglich ist, wird versucht alle Geschlechter gleichermaßen zu berücksichtigen. ")) : createCommentVNode("", true)
			])], 2)])]);
		};
	}
});
var UiLoginLayout_default = /* @__PURE__ */ __plugin_vue_export_helper_default(UiLoginLayout_vue_vue_type_script_setup_true_lang_default, [["__scopeId", "data-v-d94fe4b7"]]);
var Wappenzeichen_NRW_bw_default = "/admin/assets/Wappenzeichen_NRW_bw.svg";
const _hoisted_1 = { class: "grid grow grid-cols-1 gap-3 justify-items-center py-0.5" };
const _hoisted_2 = { key: 0 };
const _hoisted_3 = { key: 1 };
const _hoisted_4 = {
	key: 2,
	class: "icon i-ri-check-line"
};
const _hoisted_5 = { class: "flex gap-2" };
const _hoisted_6 = {
	key: 1,
	class: "icon i-ri-login-circle-line"
};
var SLogin_vue_vue_type_script_setup_true_lang_default = /* @__PURE__ */ defineComponent({
	__name: "SLogin",
	props: {
		authenticated: { type: Boolean },
		hostname: {},
		setHostname: { type: Function },
		login: { type: Function },
		connectTo: { type: Function },
		schemaPrevious: {}
	},
	setup(__props) {
		const props = __props;
		const firstauth = ref(true);
		const username = ref("root");
		const password = ref("");
		const connecting = ref(false);
		const authenticating = ref(false);
		const inputFocus = ref(false);
		const connection_failed = ref(false);
		const authentication_success = ref(false);
		const connected = shallowRef(false);
		const inputHostname = computed({
			get: () => props.hostname,
			set: (value) => props.setHostname(value)
		});
		connect();
		async function connect() {
			connecting.value = true;
			inputFocus.value = false;
			try {
				connected.value = await props.connectTo(props.hostname);
				if (!connected.value) throw new Error("Verbindung zum Server fehlgeschlagen. Bitte die Serveradresse prüfen und erneut versuchen.");
			} catch (error) {
				connection_failed.value = true;
				connecting.value = false;
				throw error;
			}
			connection_failed.value = false;
			connecting.value = false;
		}
		watch(() => props.authenticated, (value) => {
			if (value) {
				authentication_success.value = true;
				document.documentElement.style.backgroundImage = "none";
				const error = /* @__PURE__ */ new Error();
				error.name = "resetAllErrors";
				throw error;
			}
		});
		async function doLogin() {
			inputFocus.value = false;
			authenticating.value = true;
			await props.login(username.value, password.value);
			authenticating.value = false;
			firstauth.value = false;
			if (!props.authenticated) throw new Error("Passwort oder Benutzername falsch.");
		}
		return (_ctx, _cache) => {
			const _component_svws_ui_text_input = SvwsUiTextInput_default;
			const _component_svws_ui_spinner = SvwsUiSpinner_default;
			const _component_svws_ui_button = SvwsUiButton_default;
			const _component_svws_ui_spacing = SvwsUiSpacing_default;
			const _component_svws_ui_input_wrapper = SvwsUiInputWrapper_default;
			const _component_ui_login_layout = UiLoginLayout_default;
			return openBlock(), createBlock(_component_ui_login_layout, {
				version: unref(version),
				githash: unref(githash),
				application: "Administrative Verwaltung",
				"under-construction": ""
			}, {
				logo: withCtx(() => [..._cache[4] || (_cache[4] = [createBaseVNode("img", {
					src: Wappenzeichen_NRW_bw_default,
					alt: "Logo NRW",
					class: "h-14"
				}, null, -1)])]),
				main: withCtx(() => [createBaseVNode("div", _hoisted_1, [createVNode(_component_svws_ui_text_input, {
					modelValue: inputHostname.value,
					"onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => inputHostname.value = $event),
					modelModifiers: { trim: true },
					type: "text",
					url: "",
					placeholder: "Serveradresse",
					onKeyup: withKeys(connect, ["enter"]),
					onFocus: _cache[1] || (_cache[1] = ($event) => inputFocus.value = true)
				}, null, 8, ["modelValue"]), createVNode(_component_svws_ui_button, {
					type: "secondary",
					onClick: connect,
					disabled: !(!connected.value || connecting.value || inputFocus.value),
					class: normalizeClass({ "opacity-25 hover:opacity-100": connected.value && !inputFocus.value })
				}, {
					default: withCtx(() => [
						!connected.value || connecting.value || inputFocus.value ? (openBlock(), createElementBlock("span", _hoisted_2, "Verbinden")) : (openBlock(), createElementBlock("span", _hoisted_3, "Verbunden")),
						createVNode(_component_svws_ui_spinner, { spinning: connecting.value }, null, 8, ["spinning"]),
						!connecting.value && connected.value && !inputFocus.value ? (openBlock(), createElementBlock("span", _hoisted_4)) : createCommentVNode("", true)
					]),
					_: 1
				}, 8, ["disabled", "class"])]), createVNode(Transition, null, {
					default: withCtx(() => [connected.value && !connecting.value ? (openBlock(), createBlock(_component_svws_ui_input_wrapper, {
						key: 0,
						class: "mt-1",
						center: ""
					}, {
						default: withCtx(() => [
							createVNode(_component_svws_ui_text_input, {
								modelValue: username.value,
								"onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => username.value = $event),
								modelModifiers: { trim: true },
								type: "text",
								placeholder: "Benutzername",
								onKeyup: withKeys(doLogin, ["enter"])
							}, null, 8, ["modelValue"]),
							createVNode(_component_svws_ui_text_input, {
								modelValue: password.value,
								"onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => password.value = $event),
								modelModifiers: { trim: true },
								type: "password",
								placeholder: "Passwort",
								onKeyup: withKeys(doLogin, ["enter"])
							}, null, 8, ["modelValue"]),
							createVNode(_component_svws_ui_spacing),
							createBaseVNode("div", _hoisted_5, [createVNode(_component_svws_ui_button, {
								type: "transparent",
								disabled: ""
							}, {
								default: withCtx(() => [..._cache[5] || (_cache[5] = [createTextVNode(" Hilfe ", -1)])]),
								_: 1
							}), createVNode(_component_svws_ui_button, {
								onClick: doLogin,
								type: "primary",
								disabled: authenticating.value
							}, {
								default: withCtx(() => [_cache[6] || (_cache[6] = createTextVNode(" Anmelden ", -1)), authenticating.value ? (openBlock(), createBlock(_component_svws_ui_spinner, {
									key: 0,
									spinning: ""
								})) : (openBlock(), createElementBlock("span", _hoisted_6))]),
								_: 1
							}, 8, ["disabled"])])
						]),
						_: 1
					})) : createCommentVNode("", true)]),
					_: 1
				})]),
				_: 1
			}, 8, ["version", "githash"]);
		};
	}
});
var SLogin_default = SLogin_vue_vue_type_script_setup_true_lang_default;
export { SLogin_default as default };

//# sourceMappingURL=SLogin.js.map