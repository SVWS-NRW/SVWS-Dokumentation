import { $ as withCtx, B as createTextVNode, C as createVNode, D as defineComponent, P as openBlock, ai as toDisplayString, r as Fragment, v as createBaseVNode, w as createBlock, x as createCommentVNode, y as createElementBlock } from "./index.js";
import "./SvwsUiModal.js";
import { b as SvwsUiMenuItem_default, c as SvwsUiMenu_default, d as SvwsUiAppLayout_default, e as SvwsUiHeader_default } from "./SvwsUiMenuItem.js";
import "./SvwsUiTooltip.js";
import { b as SvwsUiContentCard_default } from "./SvwsUiContentCard.js";
const _hoisted_1 = { class: "app--page" };
const _hoisted_2 = { class: "flex items-center" };
const _hoisted_3 = { class: "inline-flex gap-2" };
const _hoisted_4 = { class: "opacity-40" };
const _hoisted_5 = {
	key: 0,
	class: "router-tab-bar--area"
};
const _hoisted_6 = { class: "router-tab-bar--panel" };
const _hoisted_7 = { class: "page page-grid-cards" };
var SError_vue_vue_type_script_setup_true_lang_default = /* @__PURE__ */ defineComponent({
	__name: "SError",
	props: {
		code: {},
		error: {}
	},
	setup(__props) {
		function goBack() {
			window.history.back();
		}
		function reloadClient() {
			window.location.href = window.location.origin;
		}
		return (_ctx, _cache) => {
			const _component_svws_ui_menu_item = SvwsUiMenuItem_default;
			const _component_svws_ui_menu = SvwsUiMenu_default;
			const _component_svws_ui_header = SvwsUiHeader_default;
			const _component_svws_ui_content_card = SvwsUiContentCard_default;
			const _component_svws_ui_app_layout = SvwsUiAppLayout_default;
			return openBlock(), createBlock(_component_svws_ui_app_layout, null, {
				sidebar: withCtx(() => [createVNode(_component_svws_ui_menu, null, {
					default: withCtx(() => [createVNode(_component_svws_ui_menu_item, {
						active: false,
						onClick: goBack
					}, {
						label: withCtx(() => [..._cache[0] || (_cache[0] = [createTextVNode(" Zurück ", -1)])]),
						icon: withCtx(() => [..._cache[1] || (_cache[1] = [createBaseVNode("span", { class: "icon-lg i-ri-arrow-go-back-line" }, null, -1)])]),
						_: 1
					}), createVNode(_component_svws_ui_menu_item, {
						active: false,
						onClick: reloadClient
					}, {
						label: withCtx(() => [..._cache[2] || (_cache[2] = [createTextVNode(" Neu laden ", -1)])]),
						icon: withCtx(() => [..._cache[3] || (_cache[3] = [createBaseVNode("span", { class: "icon-l i-ri-restart-line" }, null, -1)])]),
						_: 1
					})]),
					_: 1
				})]),
				main: withCtx(() => [createBaseVNode("div", _hoisted_1, [createVNode(_component_svws_ui_header, null, {
					default: withCtx(() => [createBaseVNode("div", _hoisted_2, [createBaseVNode("div", null, [
						createBaseVNode("span", _hoisted_3, [_cache[4] || (_cache[4] = createBaseVNode("span", { class: "icon i-ri-alert-fill icon-error" }, null, -1)), createTextVNode(toDisplayString(_ctx.error?.name), 1)]),
						_cache[5] || (_cache[5] = createBaseVNode("br", null, null, -1)),
						createBaseVNode("span", _hoisted_4, [_ctx.code !== void 0 ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [createTextVNode(" Fehler " + toDisplayString(_ctx.code), 1)], 64)) : (openBlock(), createElementBlock(Fragment, { key: 1 }, [createTextVNode(" Unbekannter Fehlercode ")], 64))])
					])])]),
					_: 1
				}), _ctx.error !== void 0 ? (openBlock(), createElementBlock("div", _hoisted_5, [createBaseVNode("div", _hoisted_6, [createBaseVNode("div", _hoisted_7, [createVNode(_component_svws_ui_content_card, { title: _ctx.error?.message }, {
					default: withCtx(() => [createBaseVNode("pre", null, toDisplayString(_ctx.error.stack), 1)]),
					_: 1
				}, 8, ["title"])])])])) : createCommentVNode("", true)])]),
				_: 1
			});
		};
	}
});
var SError_default = SError_vue_vue_type_script_setup_true_lang_default;
export { SError_default as default };

//# sourceMappingURL=SError.js.map