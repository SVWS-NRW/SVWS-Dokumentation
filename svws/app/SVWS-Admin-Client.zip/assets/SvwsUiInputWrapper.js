import { D as defineComponent, P as openBlock, S as renderSlot, ag as normalizeClass, y as createElementBlock } from "./index.js";
var SvwsUiInputWrapper_vue_vue_type_script_setup_true_lang_default = /* @__PURE__ */ defineComponent({
	__name: "SvwsUiInputWrapper",
	props: {
		grid: { default: 1 },
		center: {
			type: Boolean,
			default: false
		}
	},
	setup(__props) {
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", { class: normalizeClass(["input-wrapper", {
				"input-wrapper--2": _ctx.grid === 2,
				"input-wrapper--4": _ctx.grid === 4,
				"input-wrapper--center": _ctx.center
			}]) }, [renderSlot(_ctx.$slots, "default")], 2);
		};
	}
});
var SvwsUiInputWrapper_default = SvwsUiInputWrapper_vue_vue_type_script_setup_true_lang_default;
export { SvwsUiInputWrapper_default as b };

//# sourceMappingURL=SvwsUiInputWrapper.js.map