import { $ as withCtx, B as createTextVNode, C as createVNode, D as defineComponent, L as onBeforeUnmount, M as onMounted, P as openBlock, S as renderSlot, Y as useSlots, Z as watch, a1 as withDirectives, a8 as ref, ag as normalizeClass, ah as normalizeStyle, ai as toDisplayString, o as vShow, q as withModifiers, r as Fragment, u as computed, v as createBaseVNode, x as createCommentVNode, y as createElementBlock } from "./index.js";
import { b as SvwsUiModal_default, c as __plugin_vue_export_helper_default } from "./SvwsUiModal.js";
import { b as SvwsUiTooltip_default } from "./SvwsUiTooltip.js";
const _sfc_main = {};
const _hoisted_1$3 = { class: "page--header" };
const _hoisted_2$3 = { class: "text-headline" };
function _sfc_render(_ctx, _cache) {
	return openBlock(), createElementBlock("div", _hoisted_1$3, [createBaseVNode("h2", _hoisted_2$3, [renderSlot(_ctx.$slots, "default")])]);
}
var SvwsUiHeader_default = /* @__PURE__ */ __plugin_vue_export_helper_default(_sfc_main, [["render", _sfc_render]]);
const _hoisted_1$2 = { class: "s-toggle-first" };
const _hoisted_2$2 = {
	key: 0,
	class: "icon i-ri-menu-fold-line"
};
const _hoisted_3$2 = {
	key: 1,
	class: "icon i-ri-menu-unfold-line"
};
const _hoisted_4$2 = { class: "app--sidebar-container" };
const _hoisted_5$1 = { class: "s-toggle-second" };
const _hoisted_6$1 = {
	key: 0,
	class: "icon i-ri-menu-fold-line"
};
const _hoisted_7$1 = {
	key: 1,
	class: "icon i-ri-menu-unfold-line"
};
const _hoisted_8$1 = { class: "app--second-sidebar-container" };
const _hoisted_9 = { class: "app--content h-full" };
const _hoisted_10 = {
	key: 0,
	class: "app-layout--aside print:!hidden"
};
const _hoisted_11 = { class: "app-layout--aside-container relative" };
var SvwsUiAppLayout_vue_vue_type_script_setup_true_lang_default = /* @__PURE__ */ defineComponent({
	__name: "SvwsUiAppLayout",
	props: {
		fullwidthContent: {
			type: Boolean,
			default: false
		},
		noSecondaryMenu: {
			type: Boolean,
			default: false
		},
		tertiaryMenu: {
			type: Boolean,
			default: false
		},
		secondaryMenuSmall: {
			type: Boolean,
			default: false
		},
		tertiaryMenuSmall: {
			type: Boolean,
			default: false
		}
	},
	setup(__props) {
		const props = __props;
		const sidebarExpanded = ref(true);
		const secondSidebarExpanded = ref(true);
		const appMenu = ref(null);
		const hasScrollbar = ref(false);
		const scrollbarWidth = ref(0);
		const hasSecondaryMenu = computed(() => !props.fullwidthContent && !props.noSecondaryMenu);
		const hasTertiaryMenu = computed(() => !props.fullwidthContent && props.tertiaryMenu);
		const scrollbarObserver = new ResizeObserver((entries) => {
			entries.forEach((entry) => {
				requestAnimationFrame(() => {
					scrollbarWidth.value = entry.target.offsetWidth - entry.target.clientWidth;
					hasScrollbar.value = scrollbarWidth.value > 0 ? true : false;
				});
			});
		});
		onMounted(() => {
			if (appMenu.value !== null) scrollbarObserver.observe(appMenu.value);
		});
		onBeforeUnmount(() => {
			if (appMenu.value !== null) scrollbarObserver.unobserve(appMenu.value);
		});
		function updateSidebarExpanded() {
			sidebarExpanded.value = !sidebarExpanded.value;
			localStorage.setItem("sidebarExpanded", sidebarExpanded.value ? "true" : "false");
		}
		if (localStorage.getItem("sidebarExpanded") !== null) sidebarExpanded.value = localStorage.getItem("sidebarExpanded") === "true";
		function updateSecondSidebarExpanded() {
			secondSidebarExpanded.value = !secondSidebarExpanded.value;
			localStorage.setItem("secondSidebarExpanded", secondSidebarExpanded.value ? "true" : "false");
		}
		if (localStorage.getItem("secondSidebarExpanded") !== null) secondSidebarExpanded.value = localStorage.getItem("secondSidebarExpanded") === "true";
		return (_ctx, _cache) => {
			const _component_svws_ui_tooltip = SvwsUiTooltip_default;
			return openBlock(), createElementBlock("div", { class: normalizeClass(["app--layout", {
				"app--layout--has-aside": _ctx.$slots.aside,
				"s-sidebar": _ctx.$slots.secondaryMenu && hasSecondaryMenu.value,
				"s-all-sidebars-collapsed": (!_ctx.$slots.secondaryMenu || !hasSecondaryMenu.value || !sidebarExpanded.value) && (!_ctx.$slots.tertiaryMenu || !hasTertiaryMenu.value || !secondSidebarExpanded.value),
				"s-sidebar-collapsed": !sidebarExpanded.value,
				"s-second-sidebar-collapsed": !secondSidebarExpanded.value
			}]) }, [
				_ctx.$slots.sidebar && !_ctx.fullwidthContent ? (openBlock(), createElementBlock("div", {
					key: 0,
					ref_key: "appMenu",
					ref: appMenu,
					class: normalizeClass(["app--menu print:!hidden", { "has-scrollbar": hasScrollbar.value }]),
					style: normalizeStyle({ "--scrollbar-width": scrollbarWidth.value + "px" })
				}, [renderSlot(_ctx.$slots, "sidebar")], 6)) : createCommentVNode("", true),
				_ctx.$slots.secondaryMenu && hasSecondaryMenu.value ? (openBlock(), createElementBlock("div", {
					key: 1,
					class: normalizeClass(["app--sidebar print:!hidden", { "app--sidebar-normal": !_ctx.secondaryMenuSmall }])
				}, [createBaseVNode("div", _hoisted_1$2, [createVNode(_component_svws_ui_tooltip, null, {
					content: withCtx(() => [createTextVNode(" Sidebar " + toDisplayString(!sidebarExpanded.value ? "einblenden" : "ausblenden"), 1)]),
					default: withCtx(() => [createBaseVNode("button", {
						type: "button",
						onClick: updateSidebarExpanded
					}, [sidebarExpanded.value ? (openBlock(), createElementBlock("span", _hoisted_2$2)) : (openBlock(), createElementBlock("span", _hoisted_3$2))])]),
					_: 1
				})]), createBaseVNode("div", _hoisted_4$2, [renderSlot(_ctx.$slots, "secondaryMenu")])], 2)) : createCommentVNode("", true),
				_ctx.$slots.tertiaryMenu && hasTertiaryMenu.value ? (openBlock(), createElementBlock("div", {
					key: 2,
					class: normalizeClass(["app--second-sidebar print:!hidden", { "app--sidebar-normal": !_ctx.tertiaryMenuSmall }])
				}, [createBaseVNode("div", _hoisted_5$1, [createVNode(_component_svws_ui_tooltip, null, {
					content: withCtx(() => [createTextVNode(" Second Sidebar " + toDisplayString(!secondSidebarExpanded.value ? "einblenden" : "ausblenden"), 1)]),
					default: withCtx(() => [createBaseVNode("button", {
						type: "button",
						onClick: updateSecondSidebarExpanded
					}, [secondSidebarExpanded.value ? (openBlock(), createElementBlock("span", _hoisted_6$1)) : (openBlock(), createElementBlock("span", _hoisted_7$1))])]),
					_: 1
				})]), createBaseVNode("div", _hoisted_8$1, [renderSlot(_ctx.$slots, "tertiaryMenu")])], 2)) : createCommentVNode("", true),
				createBaseVNode("div", _hoisted_9, [createBaseVNode("div", { class: normalizeClass(["app--content-container relative", { "fullwidth-content": _ctx.fullwidthContent }]) }, [createCommentVNode("", true), renderSlot(_ctx.$slots, "main")], 2), _ctx.$slots.aside ? (openBlock(), createElementBlock("aside", _hoisted_10, [createBaseVNode("div", _hoisted_11, [renderSlot(_ctx.$slots, "aside")])])) : createCommentVNode("", true)])
			], 2);
		};
	}
});
var SvwsUiAppLayout_default = SvwsUiAppLayout_vue_vue_type_script_setup_true_lang_default;
const _hoisted_1$1 = {
	key: 0,
	class: "region-enumeration"
};
const _hoisted_2$1 = {
	key: 1,
	class: "sidebar--menu--header"
};
const _hoisted_3$1 = {
	key: 2,
	class: "h-5"
};
const _hoisted_4$1 = { class: "sidebar--menu--body" };
const _hoisted_5 = { class: "sidebar--menu--footer" };
const _hoisted_6 = { class: "sidebar--menu--footer-credits flex flex-col items-center text-ui-secondary" };
const _hoisted_7 = { class: "text-left" };
const _hoisted_8 = { class: "mb-5" };
var SvwsUiMenu_vue_vue_type_script_setup_true_lang_default = /* @__PURE__ */ defineComponent({
	__name: "SvwsUiMenu",
	props: {
		showEinstellungenDefaultApp: {
			type: Boolean,
			default: true
		},
		focusSwitchingEnabled: {
			type: Boolean,
			default: false
		},
		focusHelpVisible: {
			type: Boolean,
			default: false
		}
	},
	setup(__props) {
		const show = ref(false);
		return (_ctx, _cache) => {
			const _component_svws_ui_modal = SvwsUiModal_default;
			return openBlock(), createElementBlock(Fragment, null, [createBaseVNode("div", { class: normalizeClass(["sidebar--menu focus-region", { "highlighted": _ctx.focusHelpVisible }]) }, [
				_ctx.focusSwitchingEnabled ? withDirectives((openBlock(), createElementBlock("p", _hoisted_1$1, "1", 512)), [[vShow, _ctx.focusHelpVisible]]) : createCommentVNode("", true),
				_ctx.$slots.header ? (openBlock(), createElementBlock("div", _hoisted_2$1, [renderSlot(_ctx.$slots, "header")])) : (openBlock(), createElementBlock("div", _hoisted_3$1)),
				createBaseVNode("div", _hoisted_4$1, [renderSlot(_ctx.$slots, "default")]),
				createBaseVNode("div", _hoisted_5, [renderSlot(_ctx.$slots, "footer"), createBaseVNode("div", _hoisted_6, [_cache[2] || (_cache[2] = createBaseVNode("div", { class: "text-sm mt-2 mb-2 text-center" }, [
					createTextVNode("Powered by"),
					createBaseVNode("br"),
					createTextVNode("SVWS NRW")
				], -1)), createBaseVNode("button", {
					role: "link",
					onClick: _cache[0] || (_cache[0] = ($event) => show.value = true),
					class: "mb-1 underline hover:text-ui-secondary-hover text-sm"
				}, " Client Info ")])])
			], 2), createVNode(_component_svws_ui_modal, {
				show: show.value,
				"onUpdate:show": _cache[1] || (_cache[1] = ($event) => show.value = $event),
				size: "small"
			}, {
				modalTitle: withCtx(() => [..._cache[3] || (_cache[3] = [createTextVNode(" SVWS-Client ", -1)])]),
				modalContent: withCtx(() => [createBaseVNode("div", _hoisted_7, [createBaseVNode("div", _hoisted_8, [_cache[4] || (_cache[4] = createTextVNode(" Version ", -1)), renderSlot(_ctx.$slots, "version")]), _cache[5] || (_cache[5] = createBaseVNode("p", { class: "text-left text-ui-secondary" }, " Hinweis: Um eine gute Lesbarkeit zu erzeugen, wird bei SVWS-NRW möglichst auf geschlechtsneutrale Begriffe wie Lehrkräfte, Klassenleitung, Erzieher usw. zurückgegriffen. An Stellen, wo das nicht möglich ist, wird versucht alle Geschlechter gleichermaßen zu berücksichtigen. ", -1))])]),
				modalActions: withCtx(() => [renderSlot(_ctx.$slots, "metaNavigation")]),
				_: 3
			}, 8, ["show"])], 64);
		};
	}
});
var SvwsUiMenu_default = SvwsUiMenu_vue_vue_type_script_setup_true_lang_default;
const _hoisted_1 = ["title"];
const _hoisted_2 = {
	key: 0,
	class: "sidebar--menu-item--icon"
};
const _hoisted_3 = { class: "sidebar--menu-item--label" };
const _hoisted_4 = {
	key: 0,
	class: "sidebar--menu-item--subline"
};
var SvwsUiMenuItem_vue_vue_type_script_setup_true_lang_default = /* @__PURE__ */ defineComponent({
	__name: "SvwsUiMenuItem",
	props: {
		active: {
			type: Boolean,
			default: false
		},
		collapsed: {
			type: Boolean,
			default: false
		},
		disabled: {
			type: Boolean,
			default: false
		},
		subline: { default: "" },
		statistik: {
			type: Boolean,
			default: false
		},
		focus: {
			type: Boolean,
			default: false
		},
		secondary: {
			type: Boolean,
			default: false
		}
	},
	emits: ["click"],
	setup(__props, { emit: __emit }) {
		const menuLink = ref();
		const props = __props;
		const emit = __emit;
		onMounted(() => doFocus());
		watch(() => props.focus, () => doFocus());
		function doFocus() {
			if (props.focus && menuLink.value) menuLink.value.focus();
		}
		function onClick(event) {
			emit("click", event);
		}
		const slots = useSlots();
		const hatlabel = computed(() => {
			const label = slots.label?.();
			if (label !== void 0 && label.length > 0 && typeof label[0].children === "string") return label[0].children;
			return "";
		});
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("a", {
				class: normalizeClass(["sidebar--menu-item", {
					"sidebar--menu-item--active": _ctx.active,
					"sidebar--menu-item--collapsed": _ctx.collapsed,
					"sidebar--menu-item--disabled": _ctx.disabled,
					"sidebar--menu-item--statistik": hatlabel.value === "Statistik" || _ctx.statistik,
					"menuFocusField": _ctx.active && _ctx.secondary,
					"navigationFocusField": _ctx.active && !_ctx.secondary
				}]),
				href: "#",
				onClick: withModifiers(onClick, ["prevent"]),
				title: _ctx.disabled ? "Nicht verfügbar" : hatlabel.value,
				ref_key: "menuLink",
				ref: menuLink
			}, [_ctx.$slots.icon ? (openBlock(), createElementBlock("span", _hoisted_2, [renderSlot(_ctx.$slots, "icon")])) : createCommentVNode("", true), createBaseVNode("span", _hoisted_3, [renderSlot(_ctx.$slots, "label"), _ctx.subline ? (openBlock(), createElementBlock("span", _hoisted_4, toDisplayString(_ctx.subline), 1)) : createCommentVNode("", true)])], 10, _hoisted_1);
		};
	}
});
var SvwsUiMenuItem_default = SvwsUiMenuItem_vue_vue_type_script_setup_true_lang_default;
export { SvwsUiMenuItem_default as b, SvwsUiMenu_default as c, SvwsUiAppLayout_default as d, SvwsUiHeader_default as e };

//# sourceMappingURL=SvwsUiMenuItem.js.map