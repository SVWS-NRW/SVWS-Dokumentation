import { $ as withCtx, B as createTextVNode, C as createVNode, D as defineComponent, M as onMounted, P as openBlock, R as renderList, S as renderSlot, U as resolveDynamicComponent, X as useId, Y as useSlots, Z as watch, a1 as withDirectives, a8 as ref, ab as toRaw, af as unref, ag as normalizeClass, ai as toDisplayString, b as SvwsUiButton_default, l as Transition, o as vShow, r as Fragment, s as Teleport, u as computed, v as createBaseVNode, w as createBlock, x as createCommentVNode, y as createElementBlock } from "./index.js";
import { b as SvwsUiTooltip_default } from "./SvwsUiTooltip.js";
import { b as ValidatorFehlerart } from "./ValidatorFehlerart.js";
const _hoisted_1 = {
	key: 0,
	class: "ui-card--header--collapse-icon"
};
const _hoisted_2 = {
	key: 1,
	class: "ui-card--header--icon"
};
const _hoisted_3 = {
	key: 2,
	class: "ui-card--header--title-wrapper"
};
const _hoisted_4 = {
	key: 0,
	class: "ui-card--header--title"
};
const _hoisted_5 = {
	key: 1,
	class: "ui-card--header--subtitle"
};
const _hoisted_6 = { class: "ui-card--header--right-section" };
const _hoisted_7 = {
	key: 0,
	class: "ui-card--header--info"
};
const _hoisted_8 = {
	key: 1,
	class: "ui-card--header--collapse-icon"
};
const _hoisted_9 = ["id"];
const _hoisted_10 = { class: "ui-card--body--content" };
const _hoisted_11 = {
	key: 0,
	id: "ui-card--button-content-left"
};
const _hoisted_12 = {
	key: 1,
	class: "ui-card--content--main"
};
const _hoisted_13 = {
	key: 2,
	id: "ui-card--button-content-right"
};
const _hoisted_14 = {
	key: 3,
	class: "ml-auto"
};
const _hoisted_15 = { key: 0 };
const _hoisted_16 = {
	key: 2,
	class: "ui-card--body--footer"
};
const _hoisted_17 = {
	key: 0,
	id: "ui-card--button-footer-left"
};
const _hoisted_18 = {
	key: 1,
	class: "ui-card--footer--main"
};
const _hoisted_19 = {
	key: 2,
	id: "ui-card--button-footer-right"
};
const _hoisted_20 = {
	key: 3,
	class: "ml-auto"
};
var UiCard_vue_vue_type_script_setup_true_lang_default = /* @__PURE__ */ defineComponent({
	__name: "UiCard",
	props: {
		compact: {
			type: Boolean,
			default: false
		},
		isOpen: {
			type: Boolean,
			default: void 0
		},
		collapsible: {
			type: Boolean,
			default: true
		},
		collapseIconPosition: { default: "right" },
		collapseIconOpened: { default: "i-ri-arrow-up-s-line" },
		collapseIconClosed: { default: "i-ri-arrow-down-s-line" },
		icon: { default: void 0 },
		title: { default: void 0 },
		subtitle: { default: void 0 },
		info: { default: void 0 },
		content: { default: void 0 },
		showDivider: {
			type: Boolean,
			default: false
		},
		footer: { default: void 0 },
		buttonMode: { default: "text" },
		buttonContainer: { default: "content" },
		buttonPosition: { default: "right" },
		buttonOrientation: { default: "horizontal" },
		onEdit: {
			type: Function,
			default: void 0
		},
		onSave: {
			type: Function,
			default: void 0
		},
		onDelete: {
			type: Function,
			default: void 0
		},
		onCancel: {
			type: Function,
			default: void 0
		},
		editButtonDisabled: {
			type: Boolean,
			default: false
		},
		saveButtonDisabled: {
			type: Boolean,
			default: false
		},
		deleteButtonDisabled: {
			type: Boolean,
			default: false
		},
		cancelButtonDisabled: {
			type: Boolean,
			default: false
		},
		editButtonDisabledReason: { default: void 0 },
		saveButtonDisabledReason: { default: void 0 },
		deleteButtonDisabledReason: { default: void 0 },
		cancelButtonDisabledReason: { default: void 0 },
		fehler: { default: () => ValidatorFehlerart.UNGENUTZT }
	},
	emits: ["update:isOpen"],
	setup(__props, { emit: __emit }) {
		const props = __props;
		const emit = __emit;
		const bodyWrapperRef = ref();
		const slots = useSlots();
		const showCollapseIconLeft = computed(() => !slots.collapseLeft && props.collapsible && props.collapseIconPosition === "left");
		const showCollapseIconRight = computed(() => !slots.collapseRight && props.collapsible && props.collapseIconPosition === "right");
		const showIcon = computed(() => !slots.icon && props.icon !== void 0 && props.icon.length !== 0);
		const showTitleWrapper = computed(() => slots.title || slots.subtitle || props.title !== void 0 && props.title.length !== 0 || props.subtitle !== void 0 && props.subtitle.length !== 0);
		const showTitle = computed(() => !slots.title && props.title !== void 0 && props.title.length !== 0);
		const showSubtitle = computed(() => !slots.subtitle && props.subtitle !== void 0 && props.subtitle.length !== 0);
		const showInfo = computed(() => !slots.info && props.info !== void 0 && props.info.length !== 0);
		const showContentMain = computed(() => !slots.default && props.content !== void 0 && props.content.length !== 0);
		const showContentLeftButton = computed(() => !slots.buttonContentLeft && showButtons.value && props.buttonPosition === "left" && props.buttonContainer === "content");
		const showContentRightButton = computed(() => !slots.buttonContentRight && showButtons.value && props.buttonPosition === "right" && props.buttonContainer === "content");
		const showFooterDivider = computed(() => !slots.footerDivider && props.showDivider);
		const showFooter = computed(() => slots.footer || slots.buttonFooterLeft || slots.buttonFooterRight || props.footer !== void 0 && props.footer.length !== 0 || props.buttonContainer === "footer" && showButtons.value);
		const showFooterMain = computed(() => !slots.footer && props.footer !== void 0 && props.footer.length !== 0);
		const showFooterRightButton = computed(() => !slots.buttonFooterRight && showButtons.value && props.buttonContainer === "footer" && props.buttonPosition === "right");
		const showFooterLeftButton = computed(() => !slots.buttonFooterLeft && showButtons.value && props.buttonContainer === "footer" && props.buttonPosition === "left");
		const showButtons = computed(() => buttons.value.length !== 0);
		const isHovered = ref(false);
		const headerBackgroundColor = computed(() => {
			if (isHovered.value) switch (toRaw(props.fehler)) {
				case ValidatorFehlerart.HINWEIS: return isActive.value ? "bg-ui-warning-hover" : "bg-ui";
				case ValidatorFehlerart.KANN: return isActive.value ? "bg-ui-caution-hover" : "bg-ui";
				case ValidatorFehlerart.MUSS: return isActive.value ? "bg-ui-danger-hover" : "bg-ui";
				default: return isActive.value ? "bg-ui-brand-hover" : "bg-ui";
			}
			else switch (toRaw(props.fehler)) {
				case ValidatorFehlerart.HINWEIS: return isActive.value ? "bg-ui-warning" : "bg-ui-warning-secondary";
				case ValidatorFehlerart.KANN: return isActive.value ? "bg-ui-caution" : "bg-ui-caution-secondary";
				case ValidatorFehlerart.MUSS: return isActive.value ? "bg-ui-danger" : "bg-ui-danger-secondary";
				default: return isActive.value ? "bg-ui-brand" : "bg-ui-brand-secondary";
			}
		});
		const headerTextColor = computed(() => {
			switch (toRaw(props.fehler)) {
				case ValidatorFehlerart.HINWEIS: return isActive.value ? "text-ui-onwarning" : "text-ui";
				case ValidatorFehlerart.KANN: return isActive.value ? "text-ui-oncaution" : "text-ui";
				case ValidatorFehlerart.MUSS: return isActive.value ? "text-ui-ondanger" : "text-ui";
				default: return isActive.value ? "text-ui-onbrand" : "text-ui";
			}
		});
		const headerIconColor = computed(() => {
			switch (toRaw(props.fehler)) {
				case ValidatorFehlerart.HINWEIS: return isActive.value ? "!icon-ui-onwarning" : "!icon-ui";
				case ValidatorFehlerart.KANN: return isActive.value ? "!icon-ui-oncaution" : "!icon-ui";
				case ValidatorFehlerart.MUSS: return isActive.value ? "!icon-ui-ondanger" : "!icon-ui";
				default: return isActive.value ? "!icon-ui-onbrand" : "!icon-ui";
			}
		});
		const borderColor = computed(() => {
			switch (toRaw(props.fehler)) {
				case ValidatorFehlerart.HINWEIS: return "border-ui-warning";
				case ValidatorFehlerart.KANN: return "border-ui-caution";
				case ValidatorFehlerart.MUSS: return "border-ui-danger";
				default: return "border-ui-brand";
			}
		});
		const buttonContainerId = computed(() => {
			if (!showButtons.value) return void 0;
			if (props.buttonContainer === "content") return props.buttonPosition === "left" ? "#ui-card--button-content-left" : "#ui-card--button-content-right";
			else return props.buttonPosition === "left" ? "#ui-card--button-footer-left" : "#ui-card--button-footer-right";
		});
		const ariaExpanded = computed(() => props.collapsible ? isActive.value : void 0);
		const buttons = computed(() => {
			const buttons$1 = new Array();
			if (props.onSave !== void 0) buttons$1.push({
				type: "primary",
				label: "Speichern",
				icon: "i-ri-check-line",
				iconType: "icon-ui-brand",
				disabled: props.saveButtonDisabled,
				disabledReason: props.saveButtonDisabledReason,
				click: props.onSave
			});
			if (props.onCancel !== void 0) buttons$1.push({
				type: "secondary",
				label: "Abbrechen",
				icon: "i-ri-close-line",
				iconType: "icon-ui-brand",
				disabled: props.cancelButtonDisabled,
				disabledReason: props.cancelButtonDisabledReason,
				click: props.onCancel
			});
			if (props.onEdit !== void 0) buttons$1.push({
				type: "primary",
				label: "Bearbeiten",
				icon: "i-ri-edit-2-line",
				iconType: "icon-ui-brand",
				disabled: props.editButtonDisabled,
				disabledReason: props.editButtonDisabledReason,
				click: props.onEdit
			});
			if (props.onDelete !== void 0) buttons$1.push({
				type: "danger",
				label: "Löschen",
				icon: "i-ri-delete-bin-line",
				iconType: "icon-ui-danger",
				disabled: props.deleteButtonDisabled,
				disabledReason: props.deleteButtonDisabledReason,
				click: props.onDelete
			});
			return buttons$1;
		});
		const isActive = ref(false);
		const instanceId = useId();
		watch(() => props.isOpen, (newValue) => {
			setActive(newValue);
		});
		onMounted(() => {
			if (props.isOpen !== void 0) setActive(props.isOpen);
			else setActive(!props.collapsible);
			if (bodyWrapperRef.value !== void 0) bodyWrapperRef.value.style.maxHeight = isActive.value ? "fit-content" : "0px";
		});
		async function openCard(content, done) {
			const element = content;
			if (element.style.maxHeight === "fit-content") return;
			element.style.maxHeight = `${element.scrollHeight}px`;
			element.addEventListener("transitionend", done, { once: true });
		}
		function afterOpenCard(content) {
			const element = content;
			element.style.maxHeight = "fit-content";
		}
		function beforeCloseCard(el) {
			const element = el;
			element.style.maxHeight = `${element.scrollHeight}px`;
		}
		async function closeCard(el, done) {
			const element = el;
			element.style.maxHeight = "0px";
			element.addEventListener("transitionend", done, { once: true });
		}
		function setActive(setActive$1) {
			if (setActive$1 !== void 0) isActive.value = setActive$1;
			else isActive.value = !isActive.value;
		}
		function tooltipDisabled(button) {
			if (props.buttonMode === "icon" || button.disabled && button.disabledReason !== void 0) return false;
			else return true;
		}
		return (_ctx, _cache) => {
			const _component_SvwsUiButton = SvwsUiButton_default;
			const _component_SvwsUiTooltip = SvwsUiTooltip_default;
			return openBlock(), createElementBlock(Fragment, null, [createBaseVNode("div", {
				class: normalizeClass(["ui-card", { "ui-card--compact": _ctx.compact }]),
				tabindex: "-1",
				onMouseover: _cache[3] || (_cache[3] = ($event) => isHovered.value = true),
				onMouseleave: _cache[4] || (_cache[4] = ($event) => isHovered.value = false)
			}, [(openBlock(), createBlock(resolveDynamicComponent(_ctx.collapsible ? "button" : "div"), {
				type: _ctx.collapsible ? "button" : "text",
				tabindex: "0",
				class: normalizeClass([[
					{ "ui-card--active": isActive.value },
					headerBackgroundColor.value,
					headerTextColor.value,
					borderColor.value
				], "ui-card--header relative z-50 focus:ring-2 focus:ring-ui focus:!rounded outline-none"]),
				onClick: _cache[0] || (_cache[0] = ($event) => _ctx.collapsible ? setActive() : null),
				"aria-expanded": ariaExpanded.value,
				"aria-controls": _ctx.collapsible ? "cardBody" + unref(instanceId) : void 0
			}, {
				default: withCtx(() => [
					showCollapseIconLeft.value ? (openBlock(), createElementBlock("div", _hoisted_1, [createVNode(Transition, {
						name: "ui-card--icon",
						mode: "out-in"
					}, {
						default: withCtx(() => [!isActive.value ? (openBlock(), createElementBlock("span", {
							key: 0,
							class: normalizeClass([_ctx.collapseIconClosed, headerIconColor.value]),
							"aria-label": "Card geschlossen"
						}, null, 2)) : (openBlock(), createElementBlock("span", {
							key: 1,
							class: normalizeClass([_ctx.collapseIconOpened, headerIconColor.value]),
							"aria-label": "Card geöffnet"
						}, null, 2))]),
						_: 1
					})])) : createCommentVNode("", true),
					renderSlot(_ctx.$slots, "collapseLeft"),
					showIcon.value ? (openBlock(), createElementBlock("div", _hoisted_2, [createBaseVNode("span", { class: normalizeClass([_ctx.icon, headerIconColor.value]) }, null, 2)])) : createCommentVNode("", true),
					renderSlot(_ctx.$slots, "icon"),
					showTitleWrapper.value ? (openBlock(), createElementBlock("div", _hoisted_3, [
						showTitle.value ? (openBlock(), createElementBlock("div", _hoisted_4, toDisplayString(_ctx.title), 1)) : createCommentVNode("", true),
						renderSlot(_ctx.$slots, "title"),
						showSubtitle.value ? (openBlock(), createElementBlock("div", _hoisted_5, toDisplayString(_ctx.subtitle), 1)) : createCommentVNode("", true),
						renderSlot(_ctx.$slots, "subtitle")
					])) : createCommentVNode("", true),
					createBaseVNode("div", _hoisted_6, [
						showInfo.value ? (openBlock(), createElementBlock("div", _hoisted_7, toDisplayString(_ctx.info), 1)) : createCommentVNode("", true),
						renderSlot(_ctx.$slots, "info"),
						showCollapseIconRight.value ? (openBlock(), createElementBlock("div", _hoisted_8, [createVNode(Transition, {
							name: "ui-card--icon",
							mode: "out-in"
						}, {
							default: withCtx(() => [!isActive.value ? (openBlock(), createElementBlock("span", {
								key: 0,
								class: normalizeClass([_ctx.collapseIconClosed, headerIconColor.value]),
								"aria-label": "Card geschlossen"
							}, null, 2)) : (openBlock(), createElementBlock("span", {
								key: 1,
								class: normalizeClass([_ctx.collapseIconOpened, headerIconColor.value]),
								"aria-label": "Card geöffnet"
							}, null, 2))]),
							_: 1
						})])) : createCommentVNode("", true),
						renderSlot(_ctx.$slots, "collapseRight")
					])
				]),
				_: 3
			}, 8, [
				"type",
				"class",
				"aria-expanded",
				"aria-controls"
			])), createVNode(Transition, {
				name: "ui-card--collapse",
				onBeforeEnter: _cache[1] || (_cache[1] = ($event) => {
					emit("update:isOpen", true);
				}),
				onEnter: openCard,
				onAfterEnter: afterOpenCard,
				onBeforeLeave: beforeCloseCard,
				onLeave: closeCard,
				onAfterLeave: _cache[2] || (_cache[2] = ($event) => {
					emit("update:isOpen", false);
				})
			}, {
				default: withCtx(() => [withDirectives(createBaseVNode("div", {
					id: "cardBody" + unref(instanceId),
					class: "ui-card--body-wrapper",
					ref_key: "bodyWrapperRef",
					ref: bodyWrapperRef
				}, [createBaseVNode("div", { class: normalizeClass(["ui-card--body", borderColor.value]) }, [
					createBaseVNode("div", _hoisted_10, [
						showContentLeftButton.value ? (openBlock(), createElementBlock("div", _hoisted_11)) : createCommentVNode("", true),
						renderSlot(_ctx.$slots, "buttonContentLeft"),
						showContentMain.value ? (openBlock(), createElementBlock("span", _hoisted_12, toDisplayString(_ctx.content), 1)) : createCommentVNode("", true),
						renderSlot(_ctx.$slots, "default"),
						showContentRightButton.value ? (openBlock(), createElementBlock("div", _hoisted_13)) : unref(slots).buttonContentRight ? (openBlock(), createElementBlock("div", _hoisted_14, [renderSlot(_ctx.$slots, "buttonContentRight")])) : createCommentVNode("", true)
					]),
					showFooterDivider.value ? (openBlock(), createElementBlock("hr", _hoisted_15)) : renderSlot(_ctx.$slots, "footerDivider", { key: 1 }),
					showFooter.value ? (openBlock(), createElementBlock("div", _hoisted_16, [
						showFooterLeftButton.value ? (openBlock(), createElementBlock("div", _hoisted_17)) : createCommentVNode("", true),
						renderSlot(_ctx.$slots, "buttonFooterLeft"),
						showFooterMain.value ? (openBlock(), createElementBlock("span", _hoisted_18, toDisplayString(_ctx.footer), 1)) : createCommentVNode("", true),
						renderSlot(_ctx.$slots, "footer"),
						showFooterRightButton.value ? (openBlock(), createElementBlock("div", _hoisted_19)) : unref(slots).buttonFooterRight ? (openBlock(), createElementBlock("div", _hoisted_20, [renderSlot(_ctx.$slots, "buttonFooterRight")])) : createCommentVNode("", true)
					])) : createCommentVNode("", true)
				], 2)], 8, _hoisted_9), [[vShow, isActive.value]])]),
				_: 3
			})], 34), buttonContainerId.value && showButtons.value ? (openBlock(), createBlock(Teleport, {
				key: 0,
				defer: "",
				to: buttonContainerId.value
			}, [createBaseVNode("div", { class: normalizeClass(["ui-card--buttons", {
				"flex-col": _ctx.buttonOrientation === "vertical",
				"ml-auto": _ctx.buttonPosition === "right"
			}]) }, [(openBlock(true), createElementBlock(Fragment, null, renderList(buttons.value, (button) => {
				return openBlock(), createBlock(_component_SvwsUiTooltip, {
					key: button.label,
					disabled: tooltipDisabled(button),
					position: _ctx.buttonOrientation === "vertical" ? "right" : "top",
					indicator: false
				}, {
					content: withCtx(() => [createTextVNode(toDisplayString(`${button.label}${button.disabled && button.disabledReason !== void 0 && button.disabledReason.length !== 0 ? `: ${button.disabledReason}` : ""}`), 1)]),
					default: withCtx(() => [createVNode(_component_SvwsUiButton, {
						class: "ui-card--button",
						disabled: button.disabled,
						onClick: button.click,
						type: props.buttonMode === "text" ? button.type : "icon",
						size: props.buttonMode === "text" && _ctx.compact ? "small" : "normal",
						"aria-label": `Button ${button.label}`
					}, {
						default: withCtx(() => [createBaseVNode("span", { class: normalizeClass(props.buttonMode === "icon" ? [button.icon, button.iconType] : "") }, toDisplayString(props.buttonMode === "text" ? button.label : ""), 3)]),
						_: 2
					}, 1032, [
						"disabled",
						"onClick",
						"type",
						"size",
						"aria-label"
					])]),
					_: 2
				}, 1032, ["disabled", "position"]);
			}), 128))], 2)], 8, ["to"])) : createCommentVNode("", true)], 64);
		};
	}
});
var UiCard_default = UiCard_vue_vue_type_script_setup_true_lang_default;
export { UiCard_default as b };

//# sourceMappingURL=UiCard.js.map