import { $ as withCtx, B as createTextVNode, C as createVNode, D as defineComponent, P as openBlock, ai as toDisplayString, b as SvwsUiButton_default, r as Fragment, u as computed, v as createBaseVNode, w as createBlock, x as createCommentVNode, y as createElementBlock, z as createSlots } from "./index.js";
import { b as SvwsUiTooltip_default } from "./SvwsUiTooltip.js";
import "./ValidatorFehlerart.js";
import "./SvwsUiTextInput.js";
import { b as SvwsUiTable_default } from "./SvwsUiTable.js";
import "./SvwsUiCheckbox.js";
const _hoisted_1 = { class: "h-full flex flex-col" };
const _hoisted_2 = { class: "secondary-menu--headline" };
const _hoisted_3 = { class: "flex flex-col gap-0.5" };
const _hoisted_4 = { class: "secondary-menu--content" };
const _hoisted_5 = { class: "line-clamp-1 break-all -my-[0.1em] py-[0.1em]" };
const _hoisted_6 = { key: 1 };
const _hoisted_7 = {
	key: 1,
	class: "opacity-25"
};
const _hoisted_8 = {
	key: 0,
	class: "icon i-ri-error-warning-line -my-0.5"
};
const _hoisted_9 = {
	key: 0,
	class: "icon i-ri-check-line -my-0.5"
};
const _hoisted_10 = {
	key: 1,
	class: "icon i-ri-alert-fill icon-error -my-0.5"
};
var SSchemaAuswahl_vue_vue_type_script_setup_true_lang_default = /* @__PURE__ */ defineComponent({
	__name: "SSchemaAuswahl",
	props: {
		hasRootPrivileges: { type: Boolean },
		auswahl: {},
		auswahlGruppe: {},
		migrationQuellinformationen: { type: Function },
		mapSchema: { type: Function },
		gotoSchema: { type: Function },
		gotoSchemaNeu: { type: Function },
		setAuswahlGruppe: { type: Function },
		addSchema: { type: Function },
		importSchema: { type: Function },
		migrateSchema: { type: Function },
		duplicateSchema: { type: Function },
		refresh: { type: Function },
		apiStatus: {},
		revision: {}
	},
	setup(__props) {
		const props = __props;
		const cols = [
			{
				key: "name",
				label: "Name",
				sortable: true,
				span: 2
			},
			{
				key: "revision",
				label: "Revision",
				sortable: true,
				span: 1
			},
			{
				key: "isTainted",
				label: "Tainted",
				tooltip: "Tainted: Schema kann von der angegebenen Revision abweichen und wird als Entwickler-Schema betrachtet",
				sortable: true,
				span: .5
			},
			{
				key: "isInConfig",
				label: "Config",
				tooltip: "Schema ist in der Config-Datei eingetragen",
				sortable: true,
				span: .5
			}
		];
		const selectedItems = computed({
			get: () => props.auswahlGruppe,
			set: (items) => void props.setAuswahlGruppe(items)
		});
		return (_ctx, _cache) => {
			const _component_svws_ui_button = SvwsUiButton_default;
			const _component_svws_ui_tooltip = SvwsUiTooltip_default;
			const _component_svws_ui_table = SvwsUiTable_default;
			return openBlock(), createElementBlock("div", _hoisted_1, [createBaseVNode("div", _hoisted_2, [createBaseVNode("h1", null, [createBaseVNode("div", _hoisted_3, [_cache[1] || (_cache[1] = createBaseVNode("span", null, "Schema", -1)), createVNode(_component_svws_ui_button, {
				onClick: _ctx.refresh,
				type: "transparent",
				title: "Liste aktualisieren",
				class: "-ml-3"
			}, {
				default: withCtx(() => [..._cache[0] || (_cache[0] = [createBaseVNode("span", { class: "icon i-ri-loop-right-line" }, null, -1), createTextVNode(" Liste aktualisieren", -1)])]),
				_: 1
			}, 8, ["onClick"])])])]), createBaseVNode("div", _hoisted_4, [createVNode(_component_svws_ui_table, {
				items: _ctx.mapSchema().values(),
				columns: cols,
				"model-value": selectedItems.value,
				"onUpdate:modelValue": _ctx.setAuswahlGruppe,
				clickable: !_ctx.auswahlGruppe.length,
				clicked: _ctx.auswahlGruppe.length ? void 0 : _ctx.auswahl,
				"onUpdate:clicked": _ctx.gotoSchema,
				selectable: _ctx.hasRootPrivileges,
				count: "",
				"scroll-into-view": "",
				scroll: ""
			}, createSlots({
				"header(isTainted)": withCtx(() => [createVNode(_component_svws_ui_tooltip, null, {
					content: withCtx(() => [..._cache[2] || (_cache[2] = [createTextVNode("Tainted: Schema ist kann von der angegebenen Revision abweichen und wird als Entwickler-Schema betrachtet", -1)])]),
					default: withCtx(() => [_cache[3] || (_cache[3] = createBaseVNode("span", { class: "icon i-ri-file-damage-line w-[1.4em] h-[1.4em] -my-1" }, null, -1))]),
					_: 1
				})]),
				"header(isInConfig)": withCtx(() => [createVNode(_component_svws_ui_tooltip, null, {
					content: withCtx(() => [..._cache[4] || (_cache[4] = [createTextVNode("Schema ist in der Config-Datei eingetragen", -1)])]),
					default: withCtx(() => [_cache[5] || (_cache[5] = createBaseVNode("span", { class: "icon i-ri-settings-2-line w-[1.4em] h-[1.4em] -my-1" }, null, -1))]),
					_: 1
				})]),
				"cell(name)": withCtx(({ value }) => [createBaseVNode("span", _hoisted_5, toDisplayString(value), 1)]),
				"cell(revision)": withCtx(({ value }) => [value > 0 && _ctx.revision !== null ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [value > _ctx.revision ? (openBlock(), createBlock(_component_svws_ui_tooltip, { key: 0 }, {
					content: withCtx(() => [createTextVNode("Dieser SVWS-Server unterstützt nur Schemata bis zur Version " + toDisplayString(_ctx.revision) + ". Um dieses Schema verwenden zu können, ist ein Upgrade des SVWS-Server notwendig.", 1)]),
					default: withCtx(() => [createBaseVNode("span", null, toDisplayString(value), 1), _cache[6] || (_cache[6] = createBaseVNode("span", { class: "icon i-ri-alert-fill icon-error -my-0.5" }, null, -1))]),
					_: 2
				}, 1024)) : (openBlock(), createElementBlock("span", _hoisted_6, toDisplayString(value), 1))], 64)) : (openBlock(), createElementBlock("span", _hoisted_7, "–"))]),
				"cell(isTainted)": withCtx(({ value }) => [value === true ? (openBlock(), createElementBlock("span", _hoisted_8)) : createCommentVNode("", true)]),
				"cell(isInConfig)": withCtx(({ value, rowData }) => [value === true ? (openBlock(), createElementBlock("span", _hoisted_9)) : createCommentVNode("", true), rowData.isDeactivated === true ? (openBlock(), createElementBlock("span", _hoisted_10)) : createCommentVNode("", true)]),
				_: 2
			}, [_ctx.hasRootPrivileges && _ctx.auswahlGruppe.length === 0 ? {
				name: "actions",
				fn: withCtx(() => [createVNode(_component_svws_ui_button, {
					onClick: _ctx.gotoSchemaNeu,
					type: "icon",
					title: "Neues Schema anlegen"
				}, {
					default: withCtx(() => [..._cache[7] || (_cache[7] = [createBaseVNode("span", { class: "icon i-ri-add-line" }, null, -1)])]),
					_: 1
				}, 8, ["onClick"])]),
				key: "0"
			} : void 0]), 1032, [
				"items",
				"model-value",
				"onUpdate:modelValue",
				"clickable",
				"clicked",
				"onUpdate:clicked",
				"selectable"
			])])]);
		};
	}
});
var SSchemaAuswahl_default = SSchemaAuswahl_vue_vue_type_script_setup_true_lang_default;
export { SSchemaAuswahl_default as default };

//# sourceMappingURL=SSchemaAuswahl.js.map