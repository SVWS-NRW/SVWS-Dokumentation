import { $ as withCtx, B as createTextVNode, C as createVNode, D as defineComponent, I as mergeProps, J as nextTick, M as onMounted, P as openBlock, R as renderList, S as renderSlot, V as toHandlers, W as useAttrs, X as useId, Z as watch, a1 as withDirectives, a8 as ref, ab as toRaw, ac as toRef, af as unref, ag as normalizeClass, ah as normalizeStyle, ai as toDisplayString, b as SvwsUiButton_default, o as vShow, p as withKeys, q as withModifiers, r as Fragment, u as computed, v as createBaseVNode, w as createBlock, x as createCommentVNode, y as createElementBlock, z as createSlots } from "./index.js";
import { b as SvwsUiTooltip_default } from "./SvwsUiTooltip.js";
import { b as SvwsUiTextInput_default } from "./SvwsUiTextInput.js";
import { b as SvwsUiCheckbox_default } from "./SvwsUiCheckbox.js";
const _hoisted_1$1 = ["for"];
const _hoisted_2$1 = [
	"name",
	"value",
	"disabled",
	"required",
	"readonly",
	"aria-labelledby",
	"placeholder"
];
const _hoisted_3$1 = ["id"];
const _hoisted_4$1 = {
	key: 0,
	class: "cursor-pointer"
};
const _hoisted_5$1 = {
	key: 1,
	class: "icon-xs i-ri-asterisk input-number--placeholder--required input-number--state-icon",
	"aria-hidden": ""
};
const _hoisted_6$1 = {
	key: 2,
	class: "sr-only"
};
const _hoisted_7$1 = {
	key: 3,
	class: "icon i-ri-alert-line input-number--state-icon"
};
const _hoisted_8$1 = {
	key: 4,
	class: "cursor-pointer"
};
const _hoisted_9$1 = {
	key: 0,
	class: "icon i-ri-alert-fill input-number--state-icon"
};
const _hoisted_10$1 = {
	key: 5,
	class: "icon-xs i-ri-lock-line"
};
const _hoisted_11$1 = {
	key: 3,
	class: "svws-input-stepper"
};
var SvwsUiInputNumber_vue_vue_type_script_setup_true_lang_default = /* @__PURE__ */ defineComponent({
	inheritAttrs: false,
	__name: "SvwsUiInputNumber",
	props: {
		modelValue: {},
		placeholder: { default: "" },
		statistics: {
			type: Boolean,
			default: false
		},
		valid: {
			type: Function,
			default: () => true
		},
		disabled: {
			type: Boolean,
			default: false
		},
		required: {
			type: Boolean,
			default: false
		},
		readonly: {
			type: Boolean,
			default: false
		},
		headless: {
			type: Boolean,
			default: false
		},
		focus: {
			type: Boolean,
			default: false
		},
		rounded: {
			type: Boolean,
			default: false
		},
		hideStepper: {
			type: Boolean,
			default: false
		},
		span: { default: void 0 }
	},
	emits: [
		"update:modelValue",
		"change",
		"blur"
	],
	setup(__props, { expose: __expose, emit: __emit }) {
		const attrs = useAttrs();
		const input = ref(null);
		const btnPlus = ref(null);
		const btnMinus = ref(null);
		const id = useId();
		const props = __props;
		const emit = __emit;
		const vFocus = { mounted: (el) => {
			if (props.focus) el.focus();
		} };
		const data = ref(props.modelValue);
		watch(() => props.modelValue, (value) => updateData(value), { immediate: false });
		const isValid = computed(() => {
			if (props.required && data.value === null) return false;
			if (data.value !== null && (attrs.min !== void 0 && attrs.min !== null && data.value < Number(attrs.min) || attrs.max !== void 0 && attrs.max !== null && data.value > Number(attrs.max))) return false;
			return props.valid(data.value);
		});
		function updateData(value) {
			if (data.value !== value) {
				data.value = value;
				emit("update:modelValue", data.value);
			}
		}
		function onInput(event) {
			const strValue = event.target.value;
			const value = strValue === "" ? null : Number(strValue);
			if (value !== data.value) updateData(value);
		}
		function onInputNumber(stepDirection) {
			if (input.value === null) return;
			if (stepDirection === "up") input.value.stepUp();
			else if (stepDirection === "down") input.value.stepDown();
			updateData(Number(input.value.value));
		}
		function onBlur(event) {
			if (event instanceof FocusEvent && [
				input.value,
				btnPlus.value,
				btnMinus.value
			].includes(event.relatedTarget)) return;
			if (props.modelValue !== data.value) emit("change", data.value);
			emit("blur", data.value);
		}
		function onKeyEnter(event) {
			if (props.modelValue !== data.value) emit("change", data.value);
		}
		function reset() {
			data.value = props.modelValue;
		}
		const labelId = useId();
		const content = computed(() => data.value);
		__expose({
			content,
			input,
			reset
		});
		return (_ctx, _cache) => {
			const _component_svws_ui_tooltip = SvwsUiTooltip_default;
			return openBlock(), createElementBlock("div", { class: normalizeClass(["input-number-component", {
				"input-number--filled": data.value !== null && data.value !== void 0,
				"input-number--invalid": isValid.value === false,
				"input-number--disabled": _ctx.disabled,
				"input-number--readonly": _ctx.readonly,
				"input-number--statistics": _ctx.statistics,
				"input-number--number": true,
				"input-number-component--headless": _ctx.headless,
				"col-span-full": _ctx.span === "full",
				"col-span-2": _ctx.span === "2"
			}]) }, [
				createBaseVNode("label", { for: unref(id) }, null, 8, _hoisted_1$1),
				_ctx.readonly ? (openBlock(), createElementBlock("div", {
					key: 0,
					class: normalizeClass({
						"input-number--control": !_ctx.headless,
						"input-number--headless": _ctx.headless,
						"input-number--rounded": _ctx.rounded
					})
				}, toDisplayString(data.value), 3)) : withDirectives((openBlock(), createElementBlock("input", mergeProps({
					key: 1,
					ref_key: "input",
					ref: input,
					name: unref(id),
					class: [{
						"input-number--control": !_ctx.headless,
						"input-number--headless": _ctx.headless,
						"input-number--rounded": _ctx.rounded
					}, "appearance-none"]
				}, { ..._ctx.$attrs }, {
					type: "number",
					inputmode: "numeric",
					value: data.value,
					disabled: _ctx.disabled,
					required: _ctx.required,
					readonly: _ctx.readonly,
					"aria-labelledby": unref(labelId),
					placeholder: _ctx.headless ? _ctx.placeholder : "",
					onInput,
					onKeyup: withKeys(onKeyEnter, ["enter"]),
					onBlur
				}), null, 16, _hoisted_2$1)), [[vFocus]]),
				_ctx.placeholder && !_ctx.headless ? (openBlock(), createElementBlock("span", {
					key: 2,
					id: unref(labelId),
					class: "input-number--placeholder gap-1"
				}, [
					_ctx.statistics ? (openBlock(), createElementBlock("span", _hoisted_4$1, [createVNode(_component_svws_ui_tooltip, { position: "right" }, {
						content: withCtx(() => [..._cache[2] || (_cache[2] = [createTextVNode("Relevant für die Statistik", -1)])]),
						default: withCtx(() => [_cache[3] || (_cache[3] = createBaseVNode("span", { class: "icon i-ri-bar-chart-2-line input-number--statistic-icon" }, null, -1))]),
						_: 1
					})])) : createCommentVNode("", true),
					createBaseVNode("span", null, toDisplayString(_ctx.placeholder), 1),
					_ctx.required ? (openBlock(), createElementBlock("span", _hoisted_5$1)) : createCommentVNode("", true),
					_ctx.required ? (openBlock(), createElementBlock("span", _hoisted_6$1, "erforderlich")) : createCommentVNode("", true),
					!isValid.value && !_ctx.statistics && !_ctx.required ? (openBlock(), createElementBlock("span", _hoisted_7$1)) : createCommentVNode("", true),
					_ctx.statistics ? (openBlock(), createElementBlock("span", _hoisted_8$1, [_ctx.required && data.value === null ? (openBlock(), createElementBlock("span", _hoisted_9$1)) : createCommentVNode("", true)])) : createCommentVNode("", true),
					_ctx.readonly ? (openBlock(), createElementBlock("span", _hoisted_10$1)) : createCommentVNode("", true)
				], 8, _hoisted_3$1)) : createCommentVNode("", true),
				data.value !== null && !_ctx.hideStepper && !_ctx.disabled && !_ctx.readonly ? (openBlock(), createElementBlock("span", _hoisted_11$1, [createBaseVNode("button", {
					ref_key: "btnMinus",
					ref: btnMinus,
					role: "button",
					onClick: _cache[0] || (_cache[0] = ($event) => onInputNumber("down")),
					onBlur,
					class: normalizeClass({ "svws-disabled": String(_ctx.$attrs?.min) === String(data.value) })
				}, [..._cache[4] || (_cache[4] = [createBaseVNode("span", { class: "icon i-ri-subtract-line" }, null, -1)])], 34), createBaseVNode("button", {
					ref_key: "btnPlus",
					ref: btnPlus,
					role: "button",
					onClick: _cache[1] || (_cache[1] = ($event) => onInputNumber("up")),
					onBlur,
					class: normalizeClass({ "svws-disabled": String(_ctx.$attrs?.max) === String(data.value) })
				}, [..._cache[5] || (_cache[5] = [createBaseVNode("span", { class: "icon i-ri-add-line" }, null, -1)])], 34)])) : createCommentVNode("", true)
			], 2);
		};
	}
});
var SvwsUiInputNumber_default = SvwsUiInputNumber_vue_vue_type_script_setup_true_lang_default;
const _hoisted_1 = {
	key: 0,
	class: "region-enumeration"
};
const _hoisted_2 = { class: "flex gap-2 w-full overflow-hidden" };
const _hoisted_3 = {
	key: 0,
	class: "grow"
};
const _hoisted_4 = { class: "min-w-[10rem] flex flex-col gap-0.5 pt-1" };
const _hoisted_5 = {
	key: 0,
	class: "icon i-ri-filter-line"
};
const _hoisted_6 = {
	key: 1,
	class: "icon i-ri-arrow-up-s-line"
};
const _hoisted_7 = {
	key: 0,
	class: "svws-ui-table-filter--advanced"
};
const _hoisted_8 = {
	key: 0,
	class: "region-enumeration"
};
const _hoisted_9 = {
	key: 1,
	class: "svws-ui-thead",
	role: "rowgroup",
	"aria-label": "Tabellenkopf"
};
const _hoisted_10 = {
	key: 0,
	class: "svws-ui-td svws-align-center",
	role: "columnheader",
	"aria-label": "Alle auswählen"
};
const _hoisted_11 = [
	"onClick",
	"onKeyup",
	"tabindex"
];
const _hoisted_12 = { class: "line-clamp-1 break-all leading-tight" };
const _hoisted_13 = {
	key: 2,
	class: "line-clamp-1 break-all leading-tight"
};
const _hoisted_14 = {
	class: "svws-ui-tbody",
	role: "rowgroup",
	"aria-label": "Tabelleninhalt"
};
const _hoisted_15 = {
	class: "col-span-full svws-no-data-text svws-ui-td",
	role: "cell"
};
const _hoisted_16 = { class: "py-2 font-normal" };
const _hoisted_17 = [
	"onClick",
	"onKeydown",
	"data",
	"draggable"
];
const _hoisted_18 = [
	"checked",
	"disabled",
	"onInput",
	"onKeydown"
];
const _hoisted_19 = {
	key: 1,
	class: "w-full border-b border-ui"
};
const _hoisted_20 = {
	key: 3,
	class: "text-ui-secondary"
};
const _hoisted_21 = {
	key: 2,
	class: "svws-ui-tfoot--data",
	role: "rowgroup"
};
const _hoisted_22 = {
	key: 3,
	class: "svws-ui-tfoot",
	role: "rowgroup",
	"aria-label": "Fußzeile"
};
const _hoisted_23 = {
	key: 0,
	class: "svws-ui-td svws-align-center",
	role: "columnheader",
	"aria-label": "Alle auswählen"
};
const _hoisted_24 = {
	key: 1,
	class: "text-sm svws-ui-td font-medium",
	role: "cell"
};
const _hoisted_25 = { class: "text-ui-secondary" };
const _hoisted_26 = { class: "text-ui-secondary" };
const _hoisted_27 = {
	key: 2,
	class: "grow justify-end svws-ui-td",
	role: "cell"
};
var SvwsUiTable_vue_vue_type_script_setup_true_lang_default = /* @__PURE__ */ defineComponent({
	inheritAttrs: false,
	__name: "SvwsUiTable",
	props: {
		columns: { default: () => [] },
		hiddenColumns: { default: () => /* @__PURE__ */ new Set() },
		items: { default: () => [] },
		modelValue: { default: void 0 },
		uniqueKey: { default: void 0 },
		clickable: {
			type: Boolean,
			default: false
		},
		clicked: { default: void 0 },
		selectable: {
			type: Boolean,
			default: false
		},
		disableHeader: {
			type: Boolean,
			default: false
		},
		disableFooter: {
			type: Boolean,
			default: false
		},
		count: {
			type: Boolean,
			default: false
		},
		noData: {
			type: Boolean,
			default: void 0
		},
		noDataText: { default: "Keine Einträge gefunden." },
		scrollIntoView: {
			type: Boolean,
			default: void 0
		},
		type: { default: "table" },
		hasBackground: {
			type: Boolean,
			default: false
		},
		filterOpen: {
			type: Boolean,
			default: false
		},
		filterHide: {
			type: Boolean,
			default: true
		},
		filtered: {
			type: Boolean,
			default: false
		},
		filterReset: {
			type: Function,
			default: void 0
		},
		sortByAndOrder: { default: () => ({
			key: null,
			order: null
		}) },
		sortByMulti: { default: void 0 },
		toggleColumns: {
			type: Boolean,
			default: false
		},
		scroll: {
			type: Boolean,
			default: false
		},
		allowArrowKeySelection: {
			type: Boolean,
			default: false
		},
		unselectable: { default: () => /* @__PURE__ */ new Set() },
		focusFirstElement: {
			type: Boolean,
			default: false
		},
		focusSwitchingEnabled: {
			type: Boolean,
			default: false
		},
		focusHelpVisible: {
			type: Boolean,
			default: false
		},
		multiSelectFocusEnabled: {
			type: Boolean,
			default: false
		},
		lockSelectable: {
			type: Boolean,
			default: false
		},
		rowDraggable: {
			type: Function,
			default: () => false
		},
		rowDragstart: {
			type: Function,
			default: () => {}
		},
		rowDragend: {
			type: Function,
			default: () => {}
		}
	},
	emits: [
		"update:modelValue",
		"update:sortByAndOrder",
		"update:clicked",
		"update:filterOpen",
		"update:hiddenColumns"
	],
	setup(__props, { emit: __emit }) {
		const props = __props;
		const emit = __emit;
		const itemRefs = ref(/* @__PURE__ */ new Map());
		const selectionRefs = ref(/* @__PURE__ */ new Map());
		function capitalizeFirstLetter(string) {
			return string.charAt(0).toUpperCase() + string.slice(1);
		}
		function getKeys(items) {
			const accumulatedObject = [...items].reduce((accumulator, value) => {
				return {
					...accumulator,
					...value
				};
			}, {});
			return Object.keys(accumulatedObject);
		}
		function switchElement(event, list, index, backwards) {
			if (!props.allowArrowKeySelection) return;
			let targetIndex;
			if (index === list.size - 1 && !backwards) targetIndex = 0;
			else if (index === 0 && backwards) targetIndex = list.size - 1;
			else targetIndex = backwards ? index - 1 : index + 1;
			const ele = list.get(targetIndex);
			if (ele !== null && ele !== void 0) ele.focus();
		}
		const buildTableColumn = (source, initialIndex) => {
			const input = typeof source === "string" ? { key: source } : source;
			return {
				source,
				initialIndex,
				key: input.key,
				name: input.name ?? input.key,
				label: input.label ?? capitalizeFirstLetter(input.key),
				sortable: input.sortable ?? false,
				span: input.span ?? 1,
				fixedWidth: input.fixedWidth === void 0 ? 0 : Number(input.fixedWidth),
				minWidth: input.minWidth === void 0 ? 0 : Number(input.minWidth),
				align: input.align ?? "left",
				tooltip: input.tooltip ?? "",
				disabled: input.disabled ?? false,
				type: input.type ?? "text",
				divider: input.divider ?? false,
				toggle: input.toggle ?? false,
				toggleInvisible: input.toggleInvisible ?? false,
				statistic: input.statistic ?? false
			};
		};
		const columnsComputed = computed(() => props.columns.length === 0 ? getKeys(props.items).map((item, index) => buildTableColumn(item, index)) : props.columns.map((column, index) => buildTableColumn(column, index)).filter((column) => !props.hiddenColumns.has(column.key)));
		const gridTemplateColumns = computed(() => columnsComputed.value.map((column) => `minmax(${column.fixedWidth > 0 ? column.fixedWidth + "rem" : column.minWidth > 0 ? column.minWidth + "rem" : "4rem"}, ${column.fixedWidth > 0 ? column.fixedWidth + "rem" : column.span + "fr"})`).join(" "));
		const gridTemplateColumnsComputed = computed(() => gridTemplateColumns.value.length > 0 ? gridTemplateColumns.value : "repeat(auto-fit, minmax(0, 1fr))");
		const getGridTemplateColumns = computed(() => `grid-template-columns: ${props.selectable ? "2rem" : ""} ${gridTemplateColumnsComputed.value}`);
		const rowsComputed = computed(() => [...props.items].map((source, index) => ({
			selectable: !props.unselectable.has(toRaw(source)),
			initialIndex: index,
			source: toRaw(source),
			cells: columnsComputed.value.map((column) => ({
				rowIndex: index,
				rowData: toRaw(source),
				column,
				value: source[column.key] ?? ""
			}))
		})));
		const sortedRows = computed(() => {
			if (rowsComputed.value.length < 0 || props.sortByMulti !== void 0) return rowsComputed.value;
			const columnIndex = columnsComputed.value.findIndex(({ key, sortable }) => internalSortByAndOrder.value.key === key && sortable);
			if (columnIndex < 0 || columnIndex > columnsComputed.value.length - 1) return rowsComputed.value;
			const sortingOrderRatio = internalSortByAndOrder.value.order === false ? -1 : 1;
			return [...rowsComputed.value].sort((a, b) => {
				if (internalSortByAndOrder.value.order === null) return a.initialIndex - b.initialIndex;
				const firstValue = String(a.cells[columnIndex].value);
				const secondValue = String(b.cells[columnIndex].value);
				return sortingOrderRatio * firstValue.localeCompare(secondValue);
			});
		});
		function cycleSorting(value) {
			if (value === null || value === void 0) return true;
			if (value === true) return false;
			return null;
		}
		const internalSortByAndOrder = ref(props.sortByAndOrder);
		function toggleSorting(column) {
			const neu = {
				key: column.key,
				order: true
			};
			if (column.key === internalSortByAndOrder.value.key) neu.order = cycleSorting(internalSortByAndOrder.value.order);
			else if (props.sortByMulti !== void 0) {
				const alt = props.sortByMulti.get(column.key);
				neu.order = cycleSorting(alt);
			}
			internalSortByAndOrder.value = neu;
			emit("update:sortByAndOrder", neu);
		}
		const filterOpenProp = toRef(props, "filterOpen");
		const isFilterOpen = ref(filterOpenProp.value);
		function toggleFilterOpen() {
			isFilterOpen.value = !isFilterOpen.value;
			emit("update:filterOpen", isFilterOpen.value);
		}
		const selectedItemsRaw = computed(() => (props.modelValue ?? []).map((i) => toRaw(i)));
		const allRowsSelected = computed(() => sortedRows.value.length === 0 ? false : sortedRows.value.filter((row) => !props.unselectable.has(row.source)).every(isRowSelected));
		const someNotAllRowsSelected = computed(() => sortedRows.value.length === 0 ? false : sortedRows.value.some(isRowSelected) && !allRowsSelected.value);
		const selectedItemsNotListed = computed(() => selectedItemsRaw.value.filter((i) => !sortedRows.value.some((r) => toRaw(r.source) === i)));
		function isRowSelected(row) {
			return selectedItemsRaw.value.includes(row.source);
		}
		function selectAllRows() {
			emit("update:modelValue", [...sortedRows.value.filter((row) => !props.unselectable.has(row.source)).map((row) => row.source).concat(selectedItemsNotListed.value)]);
		}
		function unselectAllVisibleRows() {
			emit("update:modelValue", [...selectedItemsNotListed.value]);
		}
		function unselectAllRows() {
			emit("update:modelValue", []);
		}
		function unselectAllNotListedRows() {
			emit("update:modelValue", [...selectedItemsRaw.value.filter((i) => sortedRows.value.some((r) => toRaw(r.source) === i))]);
		}
		function selectRow(row) {
			emit("update:modelValue", selectedItemsRaw.value.concat(row.source));
		}
		function unselectRow(row) {
			const index = selectedItemsRaw.value.indexOf(row.source);
			const newSelection = selectedItemsRaw.value.slice();
			newSelection.splice(index, 1);
			emit("update:modelValue", newSelection);
		}
		function toggleRowSelection(row) {
			if (!props.selectable) return;
			if (isRowSelected(row)) unselectRow(row);
			else selectRow(row);
		}
		function toggleBulkSelection() {
			if (allRowsSelected.value) unselectAllVisibleRows();
			else selectAllRows();
		}
		const clickedItemRaw = computed(() => toRaw(props.clicked) ?? null);
		const clickedItemIndex = ref();
		function isRowClicked(row) {
			const is = row.source === clickedItemRaw.value;
			if (!is) return false;
			clickedItemIndex.value = sortedRows.value.indexOf(row);
			return true;
		}
		function toggleRowClick(row) {
			if (!props.clickable) return;
			setClickedRow(row);
		}
		function setClickedRow(row) {
			if (!props.clickable) return;
			emit("update:clicked", row.source);
		}
		watch(() => props.clicked, (neu, alt) => {
			if (neu === void 0 || neu === null) return;
			const index = clickedItemIndex.value = sortedRows.value.map((r) => r.source).indexOf(neu);
			const clickedElementHtml = itemRefs.value.get(index);
			if (alt !== neu && clickedElementHtml instanceof HTMLElement) clickedElementHtml.focus();
		});
		watch(() => props.items, () => nextTick(scrollToClickedElement));
		function isInView(el) {
			const box = el.getBoundingClientRect();
			return box.top < window.innerHeight && box.bottom >= 0;
		}
		function scrollToClickedElement() {
			if (props.modelValue !== void 0 && props.modelValue.length > 0) return;
			if (props.scrollIntoView === void 0 || props.scrollIntoView === false || clickedItemIndex.value === void 0) return;
			const clickedElementHtml = itemRefs.value.get(clickedItemIndex.value);
			const scrollOptions = {
				behavior: "auto",
				block: "center"
			};
			if (clickedElementHtml !== void 0 && clickedElementHtml !== null) {
				if (typeof clickedElementHtml.scrollIntoViewIfNeeded === "function") clickedElementHtml.scrollIntoViewIfNeeded(scrollOptions);
				else if (!isInView(clickedElementHtml)) clickedElementHtml.scrollIntoView(scrollOptions);
			}
		}
		const noDataCalculated = computed(() => sortedRows.value.length === 0);
		const data = ref(props.hiddenColumns);
		watch(() => props.hiddenColumns, (value) => updateHiddenColumnsSet(value), { immediate: false });
		function updateHiddenColumnsSet(value) {
			if (data.value.size === value.size && [...data.value].every((dataVal) => value.has(dataVal))) return;
			data.value = value;
		}
		function updateHiddenColumns(columnKey, ok) {
			if (ok) data.value.delete(columnKey);
			else data.value.add(columnKey);
			emit("update:hiddenColumns", data.value);
		}
		const win11FForMacOS = computed(() => {
			const userAgent = window.navigator.userAgent;
			if (userAgent.includes("Mac")) return true;
			if (userAgent.includes("Win") && userAgent.includes("Firefox")) return true;
			return false;
		});
		onMounted(() => {
			if (props.focusFirstElement) itemRefs.value.get(0)?.focus();
			else itemRefs.value.get(clickedItemIndex.value)?.focus();
		});
		function rowDragListeners(row) {
			if (!props.rowDraggable(row)) return {};
			return {
				dragstart: (event) => props.rowDragstart(event, row),
				dragend: (event) => props.rowDragend(event, row)
			};
		}
		return (_ctx, _cache) => {
			const _component_svws_ui_button = SvwsUiButton_default;
			const _component_svws_ui_checkbox = SvwsUiCheckbox_default;
			const _component_svws_ui_tooltip = SvwsUiTooltip_default;
			const _component_svws_ui_text_input = SvwsUiTextInput_default;
			const _component_svws_ui_input_number = SvwsUiInputNumber_default;
			return openBlock(), createElementBlock(Fragment, null, [
				_ctx.focusSwitchingEnabled && (_ctx.$slots.search || _ctx.$slots.filter || _ctx.$slots.filterAdvanced || _ctx.toggleColumns) ? withDirectives((openBlock(), createElementBlock("p", _hoisted_1, "3", 512)), [[vShow, _ctx.focusHelpVisible]]) : createCommentVNode("", true),
				_ctx.$slots.search || _ctx.$slots.filter || _ctx.$slots.filterAdvanced || _ctx.toggleColumns ? (openBlock(), createElementBlock("div", {
					key: 1,
					class: normalizeClass(["svws-ui-table-filter focus-region", {
						"svws-open": _ctx.$slots.filter && isFilterOpen.value,
						"highlighted": _ctx.focusHelpVisible
					}])
				}, [createBaseVNode("div", _hoisted_2, [
					_ctx.$slots.search ? (openBlock(), createElementBlock("div", _hoisted_3, [renderSlot(_ctx.$slots, "search")])) : createCommentVNode("", true),
					_ctx.$slots.filter ? (openBlock(), createElementBlock("div", {
						key: 1,
						class: normalizeClass(["flex shrink-0 items-center gap-1", {
							"mr-5": _ctx.$slots.filterAdvanced || _ctx.toggleColumns,
							"ml-2": _ctx.$slots.search,
							"ml-auto": !_ctx.$slots.search
						}])
					}, [renderSlot(_ctx.$slots, "filter")], 2)) : createCommentVNode("", true),
					_ctx.toggleColumns ? (openBlock(), createElementBlock("div", {
						key: 2,
						class: normalizeClass({ "ml-auto": !_ctx.$slots.filter })
					}, [createVNode(_component_svws_ui_tooltip, {
						indicator: false,
						hover: false,
						"show-arrow": false,
						position: "top",
						class: "h-full"
					}, {
						content: withCtx(() => [createBaseVNode("ul", _hoisted_4, [(openBlock(true), createElementBlock(Fragment, null, renderList(_ctx.columns.filter((col) => typeof col !== "string" && !col.toggleInvisible), (column, index) => {
							return openBlock(), createElementBlock("li", { key: index }, [typeof column !== "string" ? (openBlock(), createBlock(_component_svws_ui_checkbox, {
								key: 0,
								"model-value": !_ctx.hiddenColumns.has(column.key),
								disabled: !column.toggle,
								"onUpdate:modelValue": (ok) => updateHiddenColumns(column.key, ok)
							}, {
								default: withCtx(() => [createTextVNode(toDisplayString(column.label), 1)]),
								_: 2
							}, 1032, [
								"model-value",
								"disabled",
								"onUpdate:modelValue"
							])) : createCommentVNode("", true)]);
						}), 128))])]),
						default: withCtx(() => [createVNode(_component_svws_ui_button, {
							type: "transparent",
							class: "h-full"
						}, createSlots({
							default: withCtx(() => [_cache[2] || (_cache[2] = createBaseVNode("span", { class: "icon i-ri-table-line" }, null, -1)), _cache[3] || (_cache[3] = createBaseVNode("span", null, "Daten", -1))]),
							_: 2
						}, [_ctx.hiddenColumns.size ? {
							name: "badge",
							fn: withCtx(() => [_cache[1] || (_cache[1] = createBaseVNode("span", null, null, -1))]),
							key: "0"
						} : void 0]), 1024)]),
						_: 1
					})], 2)) : createCommentVNode("", true),
					_ctx.$slots.filterAdvanced && _ctx.filterHide ? (openBlock(), createElementBlock("div", {
						key: 3,
						class: normalizeClass(["flex shrink-0", { "ml-auto": !_ctx.$slots.filter && !_ctx.toggleColumns }])
					}, [createVNode(_component_svws_ui_button, {
						type: "transparent",
						size: "small",
						onClick: toggleFilterOpen,
						class: normalizeClass({ "opacity-50 hover:opacity-100 focus-visible:opacity-100": !_ctx.filtered && isFilterOpen.value }),
						"filter-button": ""
					}, createSlots({
						default: withCtx(() => [!_ctx.filterReset || !_ctx.filtered ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [!isFilterOpen.value ? (openBlock(), createElementBlock("span", _hoisted_5)) : (openBlock(), createElementBlock("span", _hoisted_6))], 64)) : createCommentVNode("", true), _cache[5] || (_cache[5] = createBaseVNode("span", null, "Filter", -1))]),
						_: 2
					}, [_ctx.filtered ? {
						name: "badge",
						fn: withCtx(() => [_cache[4] || (_cache[4] = createBaseVNode("span", null, null, -1))]),
						key: "0"
					} : void 0]), 1032, ["class"]), _ctx.filterReset && _ctx.filtered ? (openBlock(), createBlock(_component_svws_ui_button, {
						key: 0,
						type: "icon",
						onClick: _ctx.filterReset,
						title: "Filter zurücksetzen"
					}, {
						default: withCtx(() => [..._cache[6] || (_cache[6] = [createBaseVNode("span", { class: "icon i-ri-filter-off-line" }, null, -1)])]),
						_: 1
					}, 8, ["onClick"])) : createCommentVNode("", true)], 2)) : createCommentVNode("", true)
				]), _ctx.$slots.filterAdvanced && isFilterOpen.value ? (openBlock(), createElementBlock("div", _hoisted_7, [renderSlot(_ctx.$slots, "filterAdvanced")])) : createCommentVNode("", true)], 2)) : createCommentVNode("", true),
				createBaseVNode("div", mergeProps({
					class: "svws-ui-table focus-region",
					role: "table",
					"aria-label": "Tabelle"
				}, _ctx.$attrs, {
					style: {
						"scrollbar-gutter": "stable",
						"scrollbar-width": "thin",
						"scrollbar-color": "rgba(0,0,0,0.2) transparent"
					},
					class: {
						"svws-clickable": _ctx.clickable && (typeof _ctx.noData !== "undefined" ? !_ctx.noData : !noDataCalculated.value),
						"svws-selectable": _ctx.selectable,
						"svws-has-selection": _ctx.selectable && selectedItemsRaw.value.length > 0,
						"svws-sortable": _ctx.sortByAndOrder.key,
						"svws-no-data": typeof _ctx.noData !== "undefined" ? _ctx.noData : noDataCalculated.value,
						"svws-type-navigation": _ctx.type === "navigation",
						"svws-type-grid": _ctx.type === "grid",
						"svws-has-background": _ctx.hasBackground,
						"overflow-visible": !_ctx.scroll,
						"overflow-auto": _ctx.scroll,
						"pr-4": _ctx.scroll && win11FForMacOS.value,
						"highlighted": _ctx.focusHelpVisible
					}
				}), [
					_ctx.focusHelpVisible ? (openBlock(), createElementBlock("p", _hoisted_8, "4")) : createCommentVNode("", true),
					!_ctx.disableHeader ? (openBlock(), createElementBlock("div", _hoisted_9, [renderSlot(_ctx.$slots, "header", {
						allRowsSelected: allRowsSelected.value,
						toggleAllRows: toggleBulkSelection,
						columns: columnsComputed.value
					}, () => [createBaseVNode("div", {
						role: "row",
						class: "svws-ui-tr",
						style: normalizeStyle(getGridTemplateColumns.value)
					}, [_ctx.selectable ? (openBlock(), createElementBlock("div", _hoisted_10, [createVNode(_component_svws_ui_checkbox, {
						"model-value": allRowsSelected.value,
						indeterminate: someNotAllRowsSelected.value,
						"onUpdate:modelValue": toggleBulkSelection,
						disabled: (typeof _ctx.noData !== "undefined" ? _ctx.noData : noDataCalculated.value) || _ctx.lockSelectable
					}, null, 8, [
						"model-value",
						"indeterminate",
						"disabled"
					])])) : createCommentVNode("", true), (openBlock(true), createElementBlock(Fragment, null, renderList(columnsComputed.value, (column) => {
						return openBlock(), createElementBlock("div", {
							class: normalizeClass(["svws-ui-td", [
								`svws-column-key--${column.key}`,
								`svws-align-${column.align}`,
								{
									"svws-disabled": column.disabled,
									"svws-sortable-column": column.sortable,
									"svws-active": column.sortable && internalSortByAndOrder.value.key === column.name && typeof internalSortByAndOrder.value.order === "boolean",
									"svws-divider": column.divider
								}
							]]),
							role: "columnheader",
							key: column.key,
							onClick: withModifiers(($event) => column.sortable && toggleSorting(column), ["exact"]),
							onKeyup: withKeys(($event) => column.sortable && toggleSorting(column), ["enter"]),
							tabindex: column.sortable ? 0 : -1
						}, [renderSlot(_ctx.$slots, `header(${column.key})`, { column }, () => [column.statistic ? (openBlock(), createElementBlock("span", {
							key: 0,
							class: normalizeClass(["icon i-ri-bar-chart-2-line", {
								"icon-ui-disabled": noDataCalculated.value,
								"icon-ui-statistic": !noDataCalculated.value
							}])
						}, null, 2)) : createCommentVNode("", true), column.tooltip ? (openBlock(), createBlock(_component_svws_ui_tooltip, { key: 1 }, {
							content: withCtx(() => [createTextVNode(toDisplayString(column.tooltip), 1)]),
							default: withCtx(() => [createBaseVNode("span", _hoisted_12, toDisplayString(column.label), 1)]),
							_: 2
						}, 1024)) : (openBlock(), createElementBlock("span", _hoisted_13, toDisplayString(column.label), 1))]), column.sortable ? (openBlock(), createElementBlock("span", {
							key: 0,
							class: normalizeClass(["svws-sorting-icon", { "-order-1": column.align === "right" }])
						}, [createBaseVNode("span", { class: normalizeClass(["icon i-ri-arrow-up-down-line svws-sorting-asc", { "svws-active": (internalSortByAndOrder.value.key === column.name || _ctx.sortByMulti?.has(column.name)) && (internalSortByAndOrder.value.order === true || _ctx.sortByMulti?.get(column.name) === true) }]) }, null, 2), createBaseVNode("span", { class: normalizeClass(["icon i-ri-arrow-up-down-line svws-sorting-desc", { "svws-active": (internalSortByAndOrder.value.key === column.name || _ctx.sortByMulti?.has(column.name)) && (internalSortByAndOrder.value.order === false || _ctx.sortByMulti?.get(column.name) === false) }]) }, null, 2)], 2)) : createCommentVNode("", true)], 42, _hoisted_11);
					}), 128))], 4)])])) : createCommentVNode("", true),
					createBaseVNode("div", _hoisted_14, [renderSlot(_ctx.$slots, "body", { rows: sortedRows.value }, () => [noDataCalculated.value && _ctx.noData ? (openBlock(), createElementBlock("div", {
						key: 0,
						class: "svws-ui-tr",
						role: "row",
						style: normalizeStyle(getGridTemplateColumns.value)
					}, [createBaseVNode("div", _hoisted_15, [createBaseVNode("span", _hoisted_16, [renderSlot(_ctx.$slots, "noData", {}, () => [createTextVNode(toDisplayString(_ctx.noDataText), 1)])])])], 4)) : createCommentVNode("", true), (openBlock(true), createElementBlock(Fragment, null, renderList(sortedRows.value, (row, index) => {
						return renderSlot(_ctx.$slots, "rowCustom", { row: row.source }, () => [(openBlock(), createElementBlock("div", mergeProps({
							class: ["svws-ui-tr", {
								"svws-selected": isRowSelected(row),
								"svws-clicked": isRowClicked(row),
								"listFocusField": isRowClicked(row) || _ctx.multiSelectFocusEnabled && isRowSelected(row)
							}],
							style: getGridTemplateColumns.value,
							role: "row",
							key: `table-row_${row}_${index}`,
							onClick: withModifiers(($event) => toggleRowClick(row), ["exact"]),
							ref_for: true,
							ref: (el) => itemRefs.value.set(index, el),
							tabindex: "0",
							onKeydown: [
								withKeys(($event) => toggleRowClick(row), ["enter"]),
								withKeys(withModifiers(($event) => switchElement($event, itemRefs.value, index, false), ["prevent"]), ["down"]),
								withKeys(withModifiers(($event) => switchElement($event, itemRefs.value, index, true), ["prevent"]), ["up"])
							],
							data: row.source,
							draggable: _ctx.rowDraggable(row.source)
						}, toHandlers(rowDragListeners(row.source), true)), [renderSlot(_ctx.$slots, "row", { row: row.source }, () => [_ctx.selectable ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [row.selectable ? (openBlock(), createElementBlock("div", {
							class: "svws-ui-td svws-align-center",
							role: "cell",
							key: `selectable__${row}_${index}`
						}, [createBaseVNode("input", {
							type: "checkbox",
							checked: isRowSelected(row),
							disabled: _ctx.lockSelectable,
							onInput: ($event) => toggleRowSelection(row),
							onClick: _cache[0] || (_cache[0] = withModifiers(() => {}, ["stop"])),
							ref_for: true,
							ref: (el) => selectionRefs.value.set(index, el),
							onKeydown: [withKeys(withModifiers(($event) => switchElement($event, selectionRefs.value, index, false), ["prevent", "stop"]), ["down"]), withKeys(withModifiers(($event) => switchElement($event, selectionRefs.value, index, true), ["prevent", "stop"]), ["up"])]
						}, null, 40, _hoisted_18)])) : (openBlock(), createElementBlock("div", _hoisted_19))], 64)) : createCommentVNode("", true), renderSlot(_ctx.$slots, "rowSelectable", { row: row.source }, () => [(openBlock(true), createElementBlock(Fragment, null, renderList(row.cells, (cell) => {
							return openBlock(), createElementBlock("div", {
								class: normalizeClass(["svws-ui-td", [
									`svws-column-key--${cell.column.key}`,
									`svws-align-${cell.column.align}`,
									{
										"svws-disabled": cell.column.disabled,
										"svws-no-value": cell.value === null || cell.value === void 0 || cell.value === "",
										"svws-divider": cell.column.divider
									}
								]]),
								role: "cell",
								key: `table-cell_${cell.column.key + cell.rowIndex}`
							}, [`cell(${cell.column.key})` in _ctx.$slots ? renderSlot(_ctx.$slots, `cell(${cell.column.key})`, mergeProps({
								key: 0,
								ref_for: true
							}, cell)) : renderSlot(_ctx.$slots, "cell", mergeProps({
								key: 1,
								ref_for: true
							}, cell), () => [row.isEditing && cell.column.type !== "number" ? (openBlock(), createBlock(_component_svws_ui_text_input, {
								key: 0,
								modelValue: cell.value,
								"onUpdate:modelValue": ($event) => cell.value = $event,
								headless: true,
								type: cell.column.type,
								onClick: withModifiers(($event) => setClickedRow(row), ["stop"])
							}, null, 8, [
								"modelValue",
								"onUpdate:modelValue",
								"type",
								"onClick"
							])) : createCommentVNode("", true), row.isEditing && cell.column.type === "number" ? (openBlock(), createBlock(_component_svws_ui_input_number, {
								key: 1,
								modelValue: cell.value,
								"onUpdate:modelValue": ($event) => cell.value = $event,
								headless: true,
								type: cell.column.type,
								onClick: withModifiers(($event) => setClickedRow(row), ["stop"])
							}, null, 8, [
								"modelValue",
								"onUpdate:modelValue",
								"type",
								"onClick"
							])) : cell.value ? (openBlock(), createElementBlock(Fragment, { key: 2 }, [createTextVNode(toDisplayString(cell.column.type === "date" ? new Date(cell.value).toLocaleDateString("de", {
								day: "2-digit",
								month: "2-digit",
								year: "numeric",
								timeZone: "Europe/Berlin"
							}) : cell.value), 1)], 64)) : (openBlock(), createElementBlock("span", _hoisted_20, "—"))])], 2);
						}), 128))])])], 16, _hoisted_17))]);
					}), 256))])]),
					_ctx.$slots.dataFooter ? (openBlock(), createElementBlock("div", _hoisted_21, [renderSlot(_ctx.$slots, "dataFooter")])) : createCommentVNode("", true),
					!_ctx.disableFooter && (_ctx.selectable || _ctx.$slots.footer || _ctx.$slots.actions || _ctx.count) ? (openBlock(), createElementBlock("div", _hoisted_22, [renderSlot(_ctx.$slots, "footer", {
						allRowsSelected: allRowsSelected.value,
						toggleAllRows: toggleBulkSelection,
						rows: sortedRows.value
					}, () => [createBaseVNode("div", {
						class: "svws-ui-tr",
						style: normalizeStyle(getGridTemplateColumns.value),
						role: "row"
					}, [
						_ctx.selectable ? (openBlock(), createElementBlock("div", _hoisted_23, [createVNode(_component_svws_ui_checkbox, {
							"model-value": allRowsSelected.value,
							indeterminate: someNotAllRowsSelected.value,
							"onUpdate:modelValue": toggleBulkSelection,
							disabled: (typeof _ctx.noData !== "undefined" ? _ctx.noData : noDataCalculated.value) || _ctx.lockSelectable
						}, null, 8, [
							"model-value",
							"indeterminate",
							"disabled"
						])])) : createCommentVNode("", true),
						_ctx.count ? (openBlock(), createElementBlock("div", _hoisted_24, [allRowsSelected.value && _ctx.modelValue ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [createTextVNode("Alle " + toDisplayString(_ctx.modelValue.length - selectedItemsNotListed.value.length - _ctx.unselectable.size) + " ausgewählt", 1), selectedItemsNotListed.value.length > 0 ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [
							_cache[9] || (_cache[9] = createTextVNode(", ", -1)),
							createVNode(_component_svws_ui_button, {
								class: "m-0.5",
								type: "transparent",
								size: "small",
								title: "Weitere ausgewählte Einträge, die nicht angezeigt werden. Klicken entfernt aus der Liste.",
								onClick: unselectAllNotListedRows
							}, {
								default: withCtx(() => [_cache[7] || (_cache[7] = createBaseVNode("span", { class: "icon-sm i-ri-close-line" }, null, -1)), createTextVNode(toDisplayString(selectedItemsNotListed.value.length) + " Weitere nicht angezeigt", 1)]),
								_: 1
							}),
							_cache[10] || (_cache[10] = createTextVNode(", ", -1)),
							createVNode(_component_svws_ui_button, {
								type: "transparent",
								size: "small",
								title: "Alle ausgwählten Einträge. Klicken, um alle aus der Auswahl zu entfernen.",
								onClick: unselectAllRows
							}, {
								default: withCtx(() => [_cache[8] || (_cache[8] = createBaseVNode("span", { class: "icon-sm i-ri-close-line" }, null, -1)), createTextVNode(toDisplayString(_ctx.modelValue.length - _ctx.unselectable.size), 1)]),
								_: 1
							}),
							_cache[11] || (_cache[11] = createTextVNode(" insgesamt", -1))
						], 64)) : createCommentVNode("", true)], 64)) : someNotAllRowsSelected.value && _ctx.modelValue ? (openBlock(), createElementBlock(Fragment, { key: 1 }, [
							createTextVNode(toDisplayString(_ctx.modelValue.length - selectedItemsNotListed.value.length) + "/", 1),
							createBaseVNode("span", _hoisted_25, toDisplayString(sortedRows.value.length - _ctx.unselectable.size), 1),
							_cache[14] || (_cache[14] = createTextVNode(" ausgewählt", -1)),
							selectedItemsNotListed.value.length > 0 ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [createVNode(_component_svws_ui_button, {
								class: "m-0.5",
								type: "transparent",
								size: "small",
								title: "Weitere ausgewählte Einträge, die nicht angezeigt werden. Klicken entfernt aus der Liste.",
								onClick: unselectAllNotListedRows
							}, {
								default: withCtx(() => [_cache[12] || (_cache[12] = createBaseVNode("span", { class: "icon-sm i-ri-close-line" }, null, -1)), createTextVNode(toDisplayString(selectedItemsNotListed.value.length) + " Weitere", 1)]),
								_: 1
							}), createVNode(_component_svws_ui_button, {
								type: "transparent",
								size: "small",
								title: "Alle ausgwählten Einträge. Klicken, um alle aus der Auswahl zu entfernen.",
								onClick: unselectAllRows
							}, {
								default: withCtx(() => [_cache[13] || (_cache[13] = createBaseVNode("span", { class: "icon-sm i-ri-close-line" }, null, -1)), createTextVNode(toDisplayString(_ctx.modelValue.length - _ctx.unselectable.size) + " insgesamt", 1)]),
								_: 1
							})], 64)) : createCommentVNode("", true)
						], 64)) : (openBlock(), createElementBlock(Fragment, { key: 2 }, [createBaseVNode("span", _hoisted_26, toDisplayString(sortedRows.value.length - _ctx.unselectable.size === 1 ? "1 Eintrag" : `${sortedRows.value.length - _ctx.unselectable.size} Einträge`), 1), selectedItemsNotListed.value.length > 0 ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [_cache[16] || (_cache[16] = createTextVNode(", ", -1)), createVNode(_component_svws_ui_button, {
							class: "m-0.5",
							type: "transparent",
							size: "small",
							onClick: unselectAllNotListedRows
						}, {
							default: withCtx(() => [_cache[15] || (_cache[15] = createBaseVNode("span", { class: "icon-sm i-ri-close-line" }, null, -1)), createTextVNode(toDisplayString(selectedItemsNotListed.value.length) + " Ausgewählte nicht angezeigt", 1)]),
							_: 1
						})], 64)) : createCommentVNode("", true)], 64))])) : createCommentVNode("", true),
						_ctx.$slots.actions ? (openBlock(), createElementBlock("div", _hoisted_27, [renderSlot(_ctx.$slots, "actions")])) : createCommentVNode("", true)
					], 4)])])) : createCommentVNode("", true)
				], 16)
			], 64);
		};
	}
});
var SvwsUiTable_default = SvwsUiTable_vue_vue_type_script_setup_true_lang_default;
export { SvwsUiTable_default as b };

//# sourceMappingURL=SvwsUiTable.js.map