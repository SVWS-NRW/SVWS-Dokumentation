import { g as JavaEnum, k as Class } from "./index.js";
var ValidatorFehlerart = class ValidatorFehlerart extends JavaEnum {
	static all_values_by_ordinal = [];
	static all_values_by_name = /* @__PURE__ */ new Map();
	static MUSS = new ValidatorFehlerart("MUSS", 0);
	static KANN = new ValidatorFehlerart("KANN", 1);
	static HINWEIS = new ValidatorFehlerart("HINWEIS", 2);
	static UNGENUTZT = new ValidatorFehlerart("UNGENUTZT", 3);
	constructor(name, ordinal) {
		super(name, ordinal);
		ValidatorFehlerart.all_values_by_ordinal.push(this);
		ValidatorFehlerart.all_values_by_name.set(name, this);
	}
	static values() {
		return [...this.all_values_by_ordinal];
	}
	static valueOf(name) {
		const tmp = this.all_values_by_name.get(name);
		return !tmp ? null : tmp;
	}
	transpilerCanonicalName() {
		return "de.svws_nrw.asd.validate.ValidatorFehlerart";
	}
	isTranspiledInstanceOf(name) {
		return [
			"de.svws_nrw.asd.validate.ValidatorFehlerart",
			"java.lang.Enum",
			"java.lang.Comparable"
		].includes(name);
	}
	static class = new Class("de.svws_nrw.asd.validate.ValidatorFehlerart");
};
export { ValidatorFehlerart as b };

//# sourceMappingURL=ValidatorFehlerart.js.map