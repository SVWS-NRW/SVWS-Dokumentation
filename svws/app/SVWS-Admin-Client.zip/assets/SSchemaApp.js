import { $ as withCtx, C as createVNode, D as defineComponent, P as openBlock, T as resolveComponent, ai as toDisplayString, u as computed, v as createBaseVNode, x as createCommentVNode, y as createElementBlock } from "./index.js";
import { b as SvwsUiTabBar_default } from "./SvwsUiTabBar.js";
const _hoisted_1 = {
	key: 0,
	class: "flex flex-col w-full h-full overflow-hidden"
};
const _hoisted_2 = { class: "svws-ui-header max-w-[140rem]" };
const _hoisted_3 = { class: "svws-ui-header--title gap-x-8 lg:gap-x-16 w-full" };
const _hoisted_4 = { class: "svws-headline-wrapper flex-[2]" };
const _hoisted_5 = { class: "svws-headline" };
const _hoisted_6 = { class: "svws-subline" };
const _hoisted_7 = {
	key: 0,
	class: "opacity-50"
};
const _hoisted_8 = { key: 1 };
const _hoisted_9 = { key: 2 };
const _hoisted_10 = {
	key: 0,
	class: "flex-1 flex flex-col bg-ui-75 py-2 px-4 rounded-lg text-base -mr-3"
};
const _hoisted_11 = { class: "text-headline-md" };
const _hoisted_12 = ["title"];
const _hoisted_13 = { class: "opacity-50" };
const _hoisted_14 = {
	key: 1,
	class: "app--content--placeholder"
};
var SSchemaApp_vue_vue_type_script_setup_true_lang_default = /* @__PURE__ */ defineComponent({
	__name: "SSchemaApp",
	props: {
		auswahl: {},
		schuleInfo: { type: Function },
		tabManager: { type: Function }
	},
	setup(__props) {
		const props = __props;
		const info = computed(() => props.schuleInfo());
		return (_ctx, _cache) => {
			const _component_router_view = resolveComponent("router-view");
			const _component_svws_ui_tab_bar = SvwsUiTabBar_default;
			return _ctx.auswahl !== void 0 ? (openBlock(), createElementBlock("div", _hoisted_1, [createBaseVNode("header", _hoisted_2, [createBaseVNode("div", _hoisted_3, [createBaseVNode("div", _hoisted_4, [createBaseVNode("h2", _hoisted_5, [createBaseVNode("span", null, toDisplayString(_ctx.auswahl.name), 1)]), createBaseVNode("span", _hoisted_6, [_ctx.auswahl.revision < 0 ? (openBlock(), createElementBlock("span", _hoisted_7, " Kein SVWS-Schema ")) : (openBlock(), createElementBlock("span", _hoisted_8, " Revision: " + toDisplayString(_ctx.auswahl.revision), 1)), _ctx.auswahl.username !== "" ? (openBlock(), createElementBlock("span", _hoisted_9, ", DB-Benutzer: " + toDisplayString(_ctx.auswahl.username), 1)) : createCommentVNode("", true)])]), info.value !== void 0 ? (openBlock(), createElementBlock("div", _hoisted_10, [
				createBaseVNode("span", _hoisted_11, toDisplayString(info.value.bezeichnung.split("\n")[0]), 1),
				createBaseVNode("span", {
					class: "opacity-50 line-clamp-1",
					title: `${info.value.bezeichnung} (${info.value.strassenname} ${info.value.hausnummer} ${info.value.hausnummerZusatz ?? ""} ${info.value.ort})`
				}, toDisplayString(info.value.bezeichnung.split("\n").slice(1).join("\n")) + " (" + toDisplayString(info.value.strassenname) + " " + toDisplayString(info.value.hausnummer) + " " + toDisplayString(info.value.hausnummerZusatz ?? "") + " " + toDisplayString(info.value.ort) + ")", 9, _hoisted_12),
				createBaseVNode("span", _hoisted_13, toDisplayString(info.value.schulNr) + " " + toDisplayString(info.value.schulform), 1)
			])) : createCommentVNode("", true)]), _cache[0] || (_cache[0] = createBaseVNode("div", { class: "svws-ui-header--actions" }, null, -1))]), createVNode(_component_svws_ui_tab_bar, { "tab-manager": _ctx.tabManager }, {
				default: withCtx(() => [createVNode(_component_router_view)]),
				_: 1
			}, 8, ["tab-manager"])])) : (openBlock(), createElementBlock("div", _hoisted_14, [..._cache[1] || (_cache[1] = [createBaseVNode("span", { class: "icon i-ri-archive-stack-line" }, null, -1)])]));
		};
	}
});
var SSchemaApp_default = SSchemaApp_vue_vue_type_script_setup_true_lang_default;
export { SSchemaApp_default as default };

//# sourceMappingURL=SSchemaApp.js.map