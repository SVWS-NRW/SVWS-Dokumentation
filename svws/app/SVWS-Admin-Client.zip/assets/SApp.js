import { $ as withCtx, B as createTextVNode, C as createVNode, D as defineComponent, P as openBlock, R as renderList, T as resolveComponent, a8 as ref, af as unref, ag as normalizeClass, ai as toDisplayString, b as SvwsUiButton_default, f as version, q as withModifiers, r as Fragment, v as createBaseVNode, w as createBlock, x as createCommentVNode, y as createElementBlock } from "./index.js";
import "./SvwsUiModal.js";
import { b as SvwsUiMenuItem_default, c as SvwsUiMenu_default, d as SvwsUiAppLayout_default, e as SvwsUiHeader_default } from "./SvwsUiMenuItem.js";
import { b as SvwsUiTooltip_default } from "./SvwsUiTooltip.js";
import { b as DatenschutzModal_default } from "./DatenschutzModal.js";
const _hoisted_1$1 = { class: "app--menu--initials--label" };
const _hoisted_2$1 = { class: "opacity-50" };
const _hoisted_3$1 = { class: "opacity-50" };
var SvwsUiMenuHeader_vue_vue_type_script_setup_true_lang_default = /* @__PURE__ */ defineComponent({
	__name: "SvwsUiMenuHeader",
	props: {
		collapsed: {
			type: Boolean,
			default: false
		},
		user: { default: void 0 },
		schule: { default: void 0 },
		schema: { default: void 0 },
		isAdminClient: {
			type: Boolean,
			default: false
		}
	},
	emits: ["click"],
	setup(__props, { emit: __emit }) {
		const emit = __emit;
		function onClick(event) {
			emit("click", event);
		}
		return (_ctx, _cache) => {
			const _component_svws_ui_tooltip = SvwsUiTooltip_default;
			return openBlock(), createElementBlock("a", {
				class: "app--menu--initials",
				href: "#",
				onClick: withModifiers(onClick, ["prevent"])
			}, [_ctx.user ? (openBlock(), createBlock(_component_svws_ui_tooltip, {
				key: 0,
				position: "right",
				indicator: false
			}, {
				content: withCtx(() => [createBaseVNode("div", _hoisted_1$1, [
					createTextVNode(" Angemeldet als " + toDisplayString(_ctx.user) + " ", 1),
					_ctx.schule ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [_cache[0] || (_cache[0] = createBaseVNode("br", null, null, -1)), createBaseVNode("span", _hoisted_2$1, toDisplayString(_ctx.schule), 1)], 64)) : createCommentVNode("", true),
					_ctx.schema ? (openBlock(), createElementBlock(Fragment, { key: 1 }, [_cache[1] || (_cache[1] = createBaseVNode("br", null, null, -1)), createBaseVNode("span", _hoisted_3$1, "DB: " + toDisplayString(_ctx.schema), 1)], 64)) : createCommentVNode("", true)
				])]),
				default: withCtx(() => [createBaseVNode("div", { class: normalizeClass(["app--menu--initials--icon", { "svws-is-admin-client": _ctx.isAdminClient }]) }, [_ctx.user.length > 5 ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [createTextVNode(toDisplayString(_ctx.user.split(" ").map((username) => username[0]).join("").toUpperCase()), 1)], 64)) : (openBlock(), createElementBlock(Fragment, { key: 1 }, [createTextVNode(toDisplayString(_ctx.user.slice(0, 2).toUpperCase()), 1)], 64))], 2)]),
				_: 1
			})) : createCommentVNode("", true)]);
		};
	}
});
var SvwsUiMenuHeader_default = SvwsUiMenuHeader_vue_vue_type_script_setup_true_lang_default;
const _hoisted_1 = { href: "https://www.svws.nrw.de/faq/impressum" };
const _hoisted_2 = {
	key: 0,
	class: "h-full flex flex-col"
};
const _hoisted_3 = { class: "secondary-menu--headline" };
var SApp_vue_vue_type_script_setup_true_lang_default = /* @__PURE__ */ defineComponent({
	__name: "SApp",
	props: {
		username: {},
		isServerAdmin: { type: Boolean },
		logout: { type: Function },
		setApp: { type: Function },
		app: {},
		apps: {},
		appsHidden: {},
		apiStatus: {}
	},
	setup(__props) {
		const props = __props;
		const pendingSetApp = ref("");
		function isVisible(item) {
			if (item.name === "config" && !props.isServerAdmin) return false;
			return true;
		}
		function is_active(current) {
			const routename = props.app.name.split(".")[0];
			const title = current.text;
			if (routename !== current.name) return false;
			if (document.title !== title) document.title = title;
			return true;
		}
		async function startSetApp(app) {
			pendingSetApp.value = app.text;
			await props.setApp(app);
			pendingSetApp.value = "";
		}
		async function doLogout() {
			document.title = "Abmelden…";
			await props.logout();
			document.title = "SVWS NRW";
		}
		return (_ctx, _cache) => {
			const _component_svws_ui_menu_header = SvwsUiMenuHeader_default;
			const _component_svws_ui_menu_item = SvwsUiMenuItem_default;
			const _component_svws_ui_button = SvwsUiButton_default;
			const _component_datenschutz_modal = DatenschutzModal_default;
			const _component_svws_ui_menu = SvwsUiMenu_default;
			const _component_router_view = resolveComponent("router-view");
			const _component_svws_ui_header = SvwsUiHeader_default;
			const _component_svws_ui_app_layout = SvwsUiAppLayout_default;
			return openBlock(), createBlock(_component_svws_ui_app_layout, { "no-secondary-menu": _ctx.app.name === "config" }, {
				sidebar: withCtx(() => [createVNode(_component_svws_ui_menu, null, {
					header: withCtx(() => [createVNode(_component_svws_ui_menu_header, {
						user: _ctx.username,
						schule: "Admin-Client",
						"is-admin-client": ""
					}, null, 8, ["user"])]),
					default: withCtx(() => [(openBlock(true), createElementBlock(Fragment, null, renderList(_ctx.apps, (item) => {
						return openBlock(), createElementBlock(Fragment, { key: item.name }, [isVisible(item) ? (openBlock(), createBlock(_component_svws_ui_menu_item, {
							key: 0,
							active: is_active(item),
							onClick: ($event) => startSetApp(item)
						}, {
							label: withCtx(() => [createTextVNode(toDisplayString(item.text), 1)]),
							icon: withCtx(() => [..._cache[0] || (_cache[0] = [createBaseVNode("span", { class: "icon-lg i-ri-archive-stack-line" }, null, -1)])]),
							_: 2
						}, 1032, ["active", "onClick"])) : createCommentVNode("", true)], 64);
					}), 128))]),
					footer: withCtx(() => [createVNode(_component_svws_ui_menu_item, {
						subline: "",
						onClick: doLogout
					}, {
						label: withCtx(() => [..._cache[1] || (_cache[1] = [createTextVNode("Abmelden", -1)])]),
						icon: withCtx(() => [..._cache[2] || (_cache[2] = [createBaseVNode("span", { class: "icon-lg i-ri-logout-circle-line" }, null, -1)])]),
						_: 1
					})]),
					version: withCtx(() => [createTextVNode(toDisplayString(unref(version)), 1)]),
					metaNavigation: withCtx(() => [createBaseVNode("a", _hoisted_1, [createVNode(_component_svws_ui_button, { type: "transparent" }, {
						default: withCtx(() => [..._cache[3] || (_cache[3] = [createTextVNode(" Impressum ", -1)])]),
						_: 1
					})]), createVNode(_component_datenschutz_modal, null, {
						default: withCtx(({ openModal }) => [createVNode(_component_svws_ui_button, {
							type: "transparent",
							onClick: ($event) => openModal()
						}, {
							default: withCtx(() => [..._cache[4] || (_cache[4] = [createTextVNode(" Datenschutz ", -1)])]),
							_: 2
						}, 1032, ["onClick"])]),
						_: 1
					})]),
					_: 1
				})]),
				secondaryMenu: withCtx(() => [pendingSetApp.value ? (openBlock(), createElementBlock("div", _hoisted_2, [createBaseVNode("div", _hoisted_3, [createBaseVNode("h1", null, [createBaseVNode("span", null, toDisplayString(pendingSetApp.value), 1)])])])) : (openBlock(), createBlock(_component_router_view, {
					key: _ctx.app.name,
					name: "liste"
				}))]),
				main: withCtx(() => [createBaseVNode("div", { class: normalizeClass(["app--page h-full", _ctx.app.name]) }, [createBaseVNode("div", { class: normalizeClass(["h-full w-full flex flex-col grow", { "svws-api--pending": _ctx.apiStatus.pending }]) }, [pendingSetApp.value ? (openBlock(), createBlock(_component_svws_ui_header, { key: 0 }, {
					default: withCtx(() => [..._cache[5] || (_cache[5] = [createBaseVNode("div", { class: "flex items-center" }, [createBaseVNode("div", null, [
						createBaseVNode("span", { class: "inline-block h-[1em] rounded-sm animate-pulse w-52 bg-ui-75" }),
						createBaseVNode("br"),
						createBaseVNode("span", { class: "inline-block h-[1em] rounded-sm animate-pulse w-20 bg-ui-75" })
					])], -1)])]),
					_: 1
				})) : (openBlock(), createBlock(_component_router_view, { key: _ctx.app.name }))], 2)], 2)]),
				_: 1
			}, 8, ["no-secondary-menu"]);
		};
	}
});
var SApp_default = SApp_vue_vue_type_script_setup_true_lang_default;
export { SApp_default as default };

//# sourceMappingURL=SApp.js.map