import { D as defineComponent, P as openBlock, S as renderSlot, X as useId, af as unref, ag as normalizeClass, ai as toDisplayString, v as createBaseVNode, x as createCommentVNode, y as createElementBlock } from "./index.js";
const _hoisted_1 = ["id"];
const _hoisted_2 = ["title"];
const _hoisted_3 = {
	key: 0,
	class: "content-card--actions"
};
var SvwsUiContentCard_vue_vue_type_script_setup_true_lang_default = /* @__PURE__ */ defineComponent({
	__name: "SvwsUiContentCard",
	props: {
		title: { default: "" },
		overflowScroll: {
			type: Boolean,
			default: false
		},
		largeTitle: {
			type: Boolean,
			default: false
		},
		hasBackground: {
			type: Boolean,
			default: false
		}
	},
	setup(__props) {
		const idComponent = useId();
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", {
				id: unref(idComponent),
				class: normalizeClass(["content-card", {
					"h-full": _ctx.overflowScroll,
					"svws-has-background": _ctx.hasBackground
				}])
			}, [_ctx.title || _ctx.$slots.actions || _ctx.$slots.title ? (openBlock(), createElementBlock("div", {
				key: 0,
				class: normalizeClass(["content-card--header", { "content-card--header--has-actions": _ctx.$slots.actions }])
			}, [renderSlot(_ctx.$slots, "title", {}, () => [_ctx.title ? (openBlock(), createElementBlock("h3", {
				key: 0,
				class: normalizeClass(["content-card--headline", { "content-card--headline--large": _ctx.largeTitle }]),
				title: _ctx.title
			}, toDisplayString(_ctx.title), 11, _hoisted_2)) : createCommentVNode("", true)]), _ctx.$slots.actions ? (openBlock(), createElementBlock("div", _hoisted_3, [renderSlot(_ctx.$slots, "actions")])) : createCommentVNode("", true)], 2)) : createCommentVNode("", true), createBaseVNode("div", { class: normalizeClass(["content-card--content", { "content-card--content--overflow-scroll": _ctx.overflowScroll }]) }, [renderSlot(_ctx.$slots, "default")], 2)], 10, _hoisted_1);
		};
	}
});
var SvwsUiContentCard_default = SvwsUiContentCard_vue_vue_type_script_setup_true_lang_default;
export { SvwsUiContentCard_default as b };

//# sourceMappingURL=SvwsUiContentCard.js.map