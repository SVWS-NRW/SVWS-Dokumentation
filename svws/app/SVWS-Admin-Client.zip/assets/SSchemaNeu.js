import { $ as withCtx, A as createStaticVNode, B as createTextVNode, C as createVNode, D as defineComponent, P as openBlock, a8 as ref, aa as shallowRef, af as unref, b as SvwsUiButton_default, d as TabManager, h as SimpleOperationResponse, i as BenutzerKennwort, r as Fragment, v as createBaseVNode, w as createBlock, x as createCommentVNode, y as createElementBlock } from "./index.js";
import "./SvwsUiTooltip.js";
import { b as SvwsUiSpacing_default } from "./SvwsUiSpacing.js";
import { b as SvwsUiSpinner_default } from "./SvwsUiSpinner.js";
import "./ValidatorFehlerart.js";
import { b as SvwsUiTextInput_default } from "./SvwsUiTextInput.js";
import { b as SvwsUiTabBar_default } from "./SvwsUiTabBar.js";
import { b as SvwsUiCheckbox_default } from "./SvwsUiCheckbox.js";
import { b as validatorSchemaName, c as SvwsUiSelect_default, d as LogBox_default } from "./helfer.js";
import { b as UiCard_default } from "./UiCard.js";
const _hoisted_1$4 = { class: "input-wrapper mt-2" };
const _hoisted_2$4 = {
	key: 1,
	class: "icon i-ri-play-line"
};
var SSchemaNeuDuplicate_vue_vue_type_script_setup_true_lang_default = /* @__PURE__ */ defineComponent({
	__name: "SSchemaNeuDuplicate",
	props: {
		duplicateSchema: { type: Function },
		loading: { type: Boolean },
		setStatus: { type: Function },
		validatorUsername: { type: Function },
		isOpen: { type: Boolean },
		schema: {}
	},
	emits: ["opened"],
	setup(__props, { emit: __emit }) {
		const props = __props;
		const emit = __emit;
		const schemaNeu = ref("");
		const user = ref("");
		const password = ref("");
		async function actionFunction() {
			props.setStatus(true);
			const formData = new FormData();
			formData.append("schemaUsername", user.value);
			formData.append("schemaUserPassword", password.value);
			const result = await props.duplicateSchema(formData, schemaNeu.value);
			schemaNeu.value = "";
			props.setStatus(false, result.success, result.log);
		}
		return (_ctx, _cache) => {
			const _component_svws_ui_text_input = SvwsUiTextInput_default;
			const _component_svws_ui_spacing = SvwsUiSpacing_default;
			const _component_svws_ui_spinner = SvwsUiSpinner_default;
			const _component_svws_ui_button = SvwsUiButton_default;
			const _component_ui_card = UiCard_default;
			return openBlock(), createBlock(_component_ui_card, {
				icon: "i-ri-file-copy-line",
				title: `Schema „${_ctx.schema}“ duplizieren`,
				subtitle: "Dupliziert das aktuell ausgewählte Schema in ein neues Schema.",
				"is-open": _ctx.isOpen,
				"onUpdate:isOpen": _cache[3] || (_cache[3] = (open) => emit("opened", open))
			}, {
				buttonFooterLeft: withCtx(() => [createVNode(_component_svws_ui_button, {
					disabled: user.value === "root" || schemaNeu.value.length === 0 || user.value.length === 0 || password.value.length === 0 || _ctx.schema === schemaNeu.value || _ctx.loading,
					title: "Duplizieren",
					onClick: actionFunction,
					"is-loading": _ctx.loading,
					class: "mt-4"
				}, {
					default: withCtx(() => [_ctx.loading ? (openBlock(), createBlock(_component_svws_ui_spinner, {
						key: 0,
						spinning: ""
					})) : (openBlock(), createElementBlock("span", _hoisted_2$4)), _cache[5] || (_cache[5] = createTextVNode(" Duplizieren ", -1))]),
					_: 1
				}, 8, ["disabled", "is-loading"])]),
				default: withCtx(() => [createBaseVNode("div", _hoisted_1$4, [
					_cache[4] || (_cache[4] = createTextVNode(" Der Name des Schemas darf nur Buchstaben (ohne Umlaute), Zahlen sowie die Zeichen \"$\" und \"_\" enthalten: ", -1)),
					createVNode(_component_svws_ui_text_input, {
						modelValue: schemaNeu.value,
						"onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => schemaNeu.value = $event),
						modelModifiers: { trim: true },
						required: "",
						placeholder: "Name des neuen Schemas",
						valid: unref(validatorSchemaName)
					}, null, 8, ["modelValue", "valid"]),
					createVNode(_component_svws_ui_spacing),
					createVNode(_component_svws_ui_text_input, {
						modelValue: user.value,
						"onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => user.value = $event),
						modelModifiers: { trim: true },
						required: "",
						placeholder: "Benutzername",
						valid: _ctx.validatorUsername
					}, null, 8, ["modelValue", "valid"]),
					createVNode(_component_svws_ui_text_input, {
						modelValue: password.value,
						"onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => password.value = $event),
						modelModifiers: { trim: true },
						required: "",
						placeholder: "Passwort"
					}, null, 8, ["modelValue"])
				])]),
				_: 1
			}, 8, ["title", "is-open"]);
		};
	}
});
var SSchemaNeuDuplicate_default = SSchemaNeuDuplicate_vue_vue_type_script_setup_true_lang_default;
const _hoisted_1$3 = { class: "input-wrapper mt-2" };
const _hoisted_2$3 = ["disabled"];
const _hoisted_3$2 = {
	key: 1,
	class: "icon i-ri-play-line"
};
var SSchemaNeuMigrate_vue_vue_type_script_setup_true_lang_default = /* @__PURE__ */ defineComponent({
	__name: "SSchemaNeuMigrate",
	props: {
		migrateSchema: { type: Function },
		migrationQuellinformationen: { type: Function },
		setStatus: { type: Function },
		loading: { type: Boolean },
		validatorUsername: { type: Function },
		isOpen: { type: Boolean }
	},
	emits: ["opened"],
	setup(__props, { emit: __emit }) {
		const props = __props;
		const emit = __emit;
		const items = /* @__PURE__ */ new Map();
		items.set("mysql", "MySQL");
		items.set("mariadb", "MariaDB");
		items.set("mssql", "MSSQL");
		items.set("mdb", "Access (MDB)");
		const zielSchema = shallowRef("");
		const zielUsername = shallowRef("");
		const zielUserPassword = shallowRef("");
		async function actionFunction() {
			props.setStatus(true);
			const formData = new FormData();
			if (file.value !== null) {
				formData.append("database", file.value);
				formData.append("databasePassword", props.migrationQuellinformationen().password);
			}
			formData.append("schema", zielSchema.value);
			formData.append("db", props.migrationQuellinformationen().dbms);
			formData.append("srcUsername", props.migrationQuellinformationen().user);
			formData.append("srcPassword", props.migrationQuellinformationen().password);
			formData.append("srcSchema", props.migrationQuellinformationen().schema);
			formData.append("srcLocation", props.migrationQuellinformationen().location);
			formData.append("schulnummer", props.migrationQuellinformationen().schulnummer);
			formData.append("schemaUsername", zielUsername.value);
			formData.append("schemaUserPassword", zielUserPassword.value);
			try {
				const result = await props.migrateSchema(formData);
				props.setStatus(false, result.success, result.log);
				if (result.success) {
					zielSchema.value = "";
					zielUserPassword.value = "";
					zielUsername.value = "";
				}
			} catch (e) {
				console.log(e);
				props.setStatus(false);
			}
		}
		const file = shallowRef(null);
		function onFileChanged(event) {
			const target = event.target;
			if (target.files) file.value = target.files[0];
		}
		return (_ctx, _cache) => {
			const _component_svws_ui_select = SvwsUiSelect_default;
			const _component_svws_ui_spacing = SvwsUiSpacing_default;
			const _component_svws_ui_text_input = SvwsUiTextInput_default;
			const _component_svws_ui_checkbox = SvwsUiCheckbox_default;
			const _component_svws_ui_spinner = SvwsUiSpinner_default;
			const _component_svws_ui_button = SvwsUiButton_default;
			const _component_ui_card = UiCard_default;
			return openBlock(), createBlock(_component_ui_card, {
				icon: "i-ri-database-2-line",
				title: "Schild2-Datenbank migrieren",
				subtitle: "Eine Schild2-Datenbank wird in ein neues Schema migriert.",
				"is-open": _ctx.isOpen,
				"onUpdate:isOpen": _cache[10] || (_cache[10] = (open) => emit("opened", open))
			}, {
				buttonFooterLeft: withCtx(() => [createVNode(_component_svws_ui_button, {
					disabled: zielSchema.value.length === 0 || zielUsername.value.length === 0 || zielUserPassword.value.length === 0 || _ctx.loading || zielUsername.value === "root",
					title: "Migrieren",
					onClick: actionFunction,
					"is-loading": _ctx.loading,
					class: "mt-4"
				}, {
					default: withCtx(() => [_ctx.loading ? (openBlock(), createBlock(_component_svws_ui_spinner, {
						key: 0,
						spinning: ""
					})) : (openBlock(), createElementBlock("span", _hoisted_3$2)), _cache[16] || (_cache[16] = createTextVNode(" Migrieren ", -1))]),
					_: 1
				}, 8, ["disabled", "is-loading"])]),
				default: withCtx(() => [createBaseVNode("div", _hoisted_1$3, [
					createVNode(_component_svws_ui_select, {
						modelValue: _ctx.migrationQuellinformationen().dbms,
						"onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => _ctx.migrationQuellinformationen().dbms = $event),
						items: unref(items).keys(),
						"item-text": (i) => unref(items).get(i) || "",
						title: "Datenbank-Typ"
					}, null, 8, [
						"modelValue",
						"items",
						"item-text"
					]),
					createVNode(_component_svws_ui_spacing),
					_ctx.migrationQuellinformationen().dbms !== "mdb" ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [
						_cache[12] || (_cache[12] = createBaseVNode("div", { class: "font-bold text-button" }, "Quell-Datenbank:", -1)),
						createVNode(_component_svws_ui_text_input, {
							modelValue: _ctx.migrationQuellinformationen().location,
							"onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => _ctx.migrationQuellinformationen().location = $event),
							modelModifiers: { trim: true },
							placeholder: "Datenbank-Host (hostname:port) oder (ip:port)"
						}, null, 8, ["modelValue"]),
						createVNode(_component_svws_ui_text_input, {
							modelValue: _ctx.migrationQuellinformationen().schema,
							"onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => _ctx.migrationQuellinformationen().schema = $event),
							modelModifiers: { trim: true },
							placeholder: "Datenbank-Schema (z.B. schild_nrw)"
						}, null, 8, ["modelValue"]),
						createVNode(_component_svws_ui_text_input, {
							modelValue: _ctx.migrationQuellinformationen().user,
							"onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => _ctx.migrationQuellinformationen().user = $event),
							modelModifiers: { trim: true },
							placeholder: "Name des Datenbankbenutzers",
							valid: _ctx.validatorUsername
						}, null, 8, ["modelValue", "valid"]),
						createVNode(_component_svws_ui_text_input, {
							modelValue: _ctx.migrationQuellinformationen().password,
							"onUpdate:modelValue": _cache[4] || (_cache[4] = ($event) => _ctx.migrationQuellinformationen().password = $event),
							modelModifiers: { trim: true },
							placeholder: "Passwort des Datenbankbenutzers",
							type: "password"
						}, null, 8, ["modelValue"]),
						createVNode(_component_svws_ui_spacing),
						createVNode(_component_svws_ui_checkbox, {
							modelValue: _ctx.migrationQuellinformationen().schildzentral,
							"onUpdate:modelValue": _cache[5] || (_cache[5] = ($event) => _ctx.migrationQuellinformationen().schildzentral = $event)
						}, {
							default: withCtx(() => [..._cache[11] || (_cache[11] = [createTextVNode("Migration aus einer Schild-2-Zentral-Instanz", -1)])]),
							_: 1
						}, 8, ["modelValue"]),
						_ctx.migrationQuellinformationen().schildzentral ? (openBlock(), createBlock(_component_svws_ui_text_input, {
							key: 0,
							modelValue: _ctx.migrationQuellinformationen().schulnummer,
							"onUpdate:modelValue": _cache[6] || (_cache[6] = ($event) => _ctx.migrationQuellinformationen().schulnummer = $event),
							placeholder: "zu migrierende Schulnummer"
						}, null, 8, ["modelValue"])) : createCommentVNode("", true)
					], 64)) : (openBlock(), createElementBlock(Fragment, { key: 1 }, [_cache[13] || (_cache[13] = createBaseVNode("div", { class: "font-bold text-button" }, "Quell-Datenbank: Access-Datei (.mdb) hochladen", -1)), createBaseVNode("input", {
						type: "file",
						onChange: onFileChanged,
						disabled: _ctx.loading,
						accept: ".mdb"
					}, null, 40, _hoisted_2$3)], 64)),
					createVNode(_component_svws_ui_spacing),
					_cache[14] || (_cache[14] = createBaseVNode("div", { class: "font-bold text-button mt-2" }, "Ziel-Datenbank (wird erstellt):", -1)),
					_cache[15] || (_cache[15] = createTextVNode(" Der Name des Schemas darf nur Buchstaben (ohne Umlaute), Zahlen sowie die Zeichen \"$\" und \"_\" enthalten: ", -1)),
					createVNode(_component_svws_ui_text_input, {
						modelValue: zielSchema.value,
						"onUpdate:modelValue": _cache[7] || (_cache[7] = ($event) => zielSchema.value = $event),
						modelModifiers: { trim: true },
						placeholder: "Schema (wird erstellt, z.B. svwsdb)",
						valid: unref(validatorSchemaName)
					}, null, 8, ["modelValue", "valid"]),
					createVNode(_component_svws_ui_text_input, {
						modelValue: zielUsername.value,
						"onUpdate:modelValue": _cache[8] || (_cache[8] = ($event) => zielUsername.value = $event),
						modelModifiers: { trim: true },
						placeholder: "Name des Datenbankbenutzers",
						valid: (value) => value !== "root"
					}, null, 8, ["modelValue", "valid"]),
					createVNode(_component_svws_ui_text_input, {
						modelValue: zielUserPassword.value,
						"onUpdate:modelValue": _cache[9] || (_cache[9] = ($event) => zielUserPassword.value = $event),
						modelModifiers: { trim: true },
						placeholder: "Passwort des Datenbankbenutzers",
						type: "password"
					}, null, 8, ["modelValue"])
				])]),
				_: 1
			}, 8, ["is-open"]);
		};
	}
});
var SSchemaNeuMigrate_default = SSchemaNeuMigrate_vue_vue_type_script_setup_true_lang_default;
const _hoisted_1$2 = { class: "input-wrapper" };
const _hoisted_2$2 = { class: "space-y-2" };
const _hoisted_3$1 = ["disabled"];
const _hoisted_4$1 = {
	key: 1,
	class: "icon i-ri-play-line"
};
var SSchemaNeuRestore_vue_vue_type_script_setup_true_lang_default = /* @__PURE__ */ defineComponent({
	__name: "SSchemaNeuRestore",
	props: {
		importSchema: { type: Function },
		setStatus: { type: Function },
		loading: { type: Boolean },
		validatorUsername: { type: Function },
		isOpen: { type: Boolean }
	},
	emits: ["opened"],
	setup(__props, { emit: __emit }) {
		const props = __props;
		const emit = __emit;
		const schema = ref("");
		const user = ref("");
		const password = ref("");
		const file = ref(null);
		function onFileChanged(event) {
			const target = event.target;
			if (target.files) file.value = target.files[0];
		}
		async function actionFunction() {
			if (file.value === null) return;
			props.setStatus(true);
			const formData = new FormData();
			formData.append("database", file.value);
			formData.append("schemaUsername", user.value);
			formData.append("schemaUserPassword", password.value);
			const result = await props.importSchema(formData, schema.value);
			schema.value = "";
			user.value = "";
			password.value = "";
			props.setStatus(false, result.success, result.log);
		}
		return (_ctx, _cache) => {
			const _component_svws_ui_spacing = SvwsUiSpacing_default;
			const _component_svws_ui_text_input = SvwsUiTextInput_default;
			const _component_svws_ui_spinner = SvwsUiSpinner_default;
			const _component_svws_ui_button = SvwsUiButton_default;
			const _component_ui_card = UiCard_default;
			return openBlock(), createBlock(_component_ui_card, {
				icon: "i-ri-device-recover-line",
				title: "Backup importieren",
				subtitle: "Ein SQLite-Backup wird in ein neues Schema wiederhergestellt",
				"is-open": _ctx.isOpen,
				"onUpdate:isOpen": _cache[3] || (_cache[3] = (open) => emit("opened", open))
			}, {
				buttonFooterLeft: withCtx(() => [createVNode(_component_svws_ui_button, {
					disabled: schema.value.length === 0 || user.value.length === 0 || password.value.length === 0 || user.value === "root" || _ctx.loading,
					title: "Schema anlegen",
					onClick: actionFunction,
					"is-loading": _ctx.loading,
					class: "mt-4"
				}, {
					default: withCtx(() => [_ctx.loading ? (openBlock(), createBlock(_component_svws_ui_spinner, {
						key: 0,
						spinning: ""
					})) : (openBlock(), createElementBlock("span", _hoisted_4$1)), _cache[7] || (_cache[7] = createTextVNode(" Schema anlegen ", -1))]),
					_: 1
				}, 8, ["disabled", "is-loading"])]),
				default: withCtx(() => [createBaseVNode("div", _hoisted_1$2, [
					createBaseVNode("div", _hoisted_2$2, [_cache[4] || (_cache[4] = createBaseVNode("div", { class: "font-bold text-button" }, "Quell-Datenbank: SQLite-Datei (.sqlite) hochladen", -1)), createBaseVNode("input", {
						type: "file",
						onChange: onFileChanged,
						disabled: _ctx.loading,
						accept: ".sqlite"
					}, null, 40, _hoisted_3$1)]),
					createVNode(_component_svws_ui_spacing),
					_cache[5] || (_cache[5] = createBaseVNode("div", { class: "font-bold text-button" }, "Ziel-Datenbank (wird erstellt):", -1)),
					_cache[6] || (_cache[6] = createTextVNode(" Der Name des Schemas darf nur Buchstaben (ohne Umlaute), Zahlen sowie die Zeichen \"$\" und \"_\" enthalten: ", -1)),
					createVNode(_component_svws_ui_text_input, {
						modelValue: schema.value,
						"onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => schema.value = $event),
						modelModifiers: { trim: true },
						required: "",
						placeholder: "Schemaname",
						valid: unref(validatorSchemaName)
					}, null, 8, ["modelValue", "valid"]),
					createVNode(_component_svws_ui_text_input, {
						modelValue: user.value,
						"onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => user.value = $event),
						modelModifiers: { trim: true },
						required: "",
						placeholder: "Benutzername",
						valid: _ctx.validatorUsername
					}, null, 8, ["modelValue", "valid"]),
					createVNode(_component_svws_ui_text_input, {
						modelValue: password.value,
						"onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => password.value = $event),
						modelModifiers: { trim: true },
						required: "",
						placeholder: "Passwort",
						type: "password"
					}, null, 8, ["modelValue"])
				])]),
				_: 1
			}, 8, ["is-open"]);
		};
	}
});
var SSchemaNeuRestore_default = SSchemaNeuRestore_vue_vue_type_script_setup_true_lang_default;
const _hoisted_1$1 = { class: "input-wrapper mt-2" };
const _hoisted_2$1 = {
	key: 1,
	class: "icon i-ri-play-line"
};
var SSchemaNeuLeer_vue_vue_type_script_setup_true_lang_default = /* @__PURE__ */ defineComponent({
	__name: "SSchemaNeuLeer",
	props: {
		addSchema: { type: Function },
		setStatus: { type: Function },
		loading: { type: Boolean },
		validatorUsername: { type: Function },
		isOpen: { type: Boolean }
	},
	emits: ["opened"],
	setup(__props, { emit: __emit }) {
		const props = __props;
		const emit = __emit;
		const schemaname = ref("");
		const user = ref("");
		const password = ref("");
		async function actionFunction() {
			props.setStatus(true);
			const data = new BenutzerKennwort();
			data.user = user.value;
			data.password = password.value;
			let result = new SimpleOperationResponse();
			result = await props.addSchema(data, schemaname.value);
			schemaname.value = "";
			user.value = "";
			password.value = "";
			props.setStatus(false, result.success, result.log);
		}
		return (_ctx, _cache) => {
			const _component_svws_ui_text_input = SvwsUiTextInput_default;
			const _component_svws_ui_spacing = SvwsUiSpacing_default;
			const _component_svws_ui_spinner = SvwsUiSpinner_default;
			const _component_svws_ui_button = SvwsUiButton_default;
			const _component_ui_card = UiCard_default;
			return openBlock(), createBlock(_component_ui_card, {
				icon: "i-ri-add-line",
				title: "Leeres Schema",
				subtitle: "Es wird ein leeres neues Schema in der neuesten Revision erzeugt. Dieses kann im Anschluss initialisiert werden.",
				"is-open": _ctx.isOpen,
				"onUpdate:isOpen": _cache[3] || (_cache[3] = (open) => emit("opened", open))
			}, {
				buttonFooterLeft: withCtx(() => [createVNode(_component_svws_ui_button, {
					disabled: schemaname.value.length === 0 || user.value.length === 0 || password.value.length === 0 || user.value === "root" || _ctx.loading,
					title: "Schema anlegen",
					onClick: actionFunction,
					"is-loading": _ctx.loading,
					class: "mt-4"
				}, {
					default: withCtx(() => [_ctx.loading ? (openBlock(), createBlock(_component_svws_ui_spinner, {
						key: 0,
						spinning: ""
					})) : (openBlock(), createElementBlock("span", _hoisted_2$1)), _cache[5] || (_cache[5] = createTextVNode(" Schema anlegen ", -1))]),
					_: 1
				}, 8, ["disabled", "is-loading"])]),
				default: withCtx(() => [createBaseVNode("div", _hoisted_1$1, [
					_cache[4] || (_cache[4] = createTextVNode(" Der Name des Schemas darf nur Buchstaben (ohne Umlaute), Zahlen sowie die Zeichen \"$\" und \"_\" enthalten: ", -1)),
					createVNode(_component_svws_ui_text_input, {
						modelValue: schemaname.value,
						"onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => schemaname.value = $event),
						modelModifiers: { trim: true },
						required: "",
						placeholder: "Schemaname",
						valid: unref(validatorSchemaName),
						disabled: _ctx.loading
					}, null, 8, [
						"modelValue",
						"valid",
						"disabled"
					]),
					createVNode(_component_svws_ui_spacing),
					createVNode(_component_svws_ui_text_input, {
						modelValue: user.value,
						"onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => user.value = $event),
						modelModifiers: { trim: true },
						required: "",
						placeholder: "Benutzername",
						disabled: _ctx.loading,
						valid: _ctx.validatorUsername
					}, null, 8, [
						"modelValue",
						"disabled",
						"valid"
					]),
					createVNode(_component_svws_ui_text_input, {
						modelValue: password.value,
						"onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => password.value = $event),
						modelModifiers: { trim: true },
						required: "",
						placeholder: "Passwort",
						disabled: _ctx.loading,
						type: "password"
					}, null, 8, ["modelValue", "disabled"])
				])]),
				_: 1
			}, 8, ["is-open"]);
		};
	}
});
var SSchemaNeuLeer_default = SSchemaNeuLeer_vue_vue_type_script_setup_true_lang_default;
const _hoisted_1 = { class: "page page-flex-col" };
const _hoisted_2 = { class: "page page-flex-row" };
const _hoisted_3 = { class: "min-w-fit flex flex-col gap-y-4 overflow-y-auto px-6" };
const _hoisted_4 = { class: "min-w-fit grow" };
var SSchemaNeu_vue_vue_type_script_setup_true_lang_default = /* @__PURE__ */ defineComponent({
	__name: "SSchemaNeu",
	props: {
		apiStatus: {},
		apiUsername: {},
		addSchema: { type: Function },
		importSchema: { type: Function },
		migrateSchema: { type: Function },
		duplicateSchema: { type: Function },
		migrationQuellinformationen: { type: Function },
		schema: {}
	},
	setup(__props) {
		const props = __props;
		const loading = ref(false);
		const logs = shallowRef(void 0);
		const status = shallowRef(void 0);
		const currentAction = ref("");
		const oldAction = ref({
			name: "",
			open: false
		});
		function setStatus(loadingV, statusV, logsV) {
			logs.value = logsV;
			loading.value = loadingV;
			status.value = statusV;
		}
		function setCurrentAction(newAction, open) {
			if (newAction === oldAction.value.name && !open) return;
			oldAction.value.name = currentAction.value;
			oldAction.value.open = currentAction.value === "" ? false : true;
			if (open === true) currentAction.value = newAction;
			else currentAction.value = "";
		}
		function clear() {
			loading.value = false;
			logs.value = void 0;
			status.value = void 0;
		}
		const validatorUsername = (username) => {
			if (username === null || username === "root" || username === props.apiUsername) return false;
			return true;
		};
		return (_ctx, _cache) => {
			const _component_s_schema_neu_leer = SSchemaNeuLeer_default;
			const _component_s_schema_neu_restore = SSchemaNeuRestore_default;
			const _component_s_schema_neu_migrate = SSchemaNeuMigrate_default;
			const _component_s_schema_neu_duplicate = SSchemaNeuDuplicate_default;
			const _component_svws_ui_button = SvwsUiButton_default;
			const _component_log_box = LogBox_default;
			const _component_svws_ui_tab_bar = SvwsUiTabBar_default;
			return openBlock(), createElementBlock("div", _hoisted_1, [_cache[5] || (_cache[5] = createStaticVNode("<header class=\"svws-ui-header max-w-[140rem]\"><div class=\"svws-ui-header--title gap-x-8 lg:gap-x-16 w-full\"><div class=\"svws-headline-wrapper flex-[2]\"><h2 class=\"svws-headline\"></h2><span class=\"svws-subline\"> Neues Schema anlegen </span></div></div><div class=\"svws-ui-header--actions\"></div></header>", 1)), createVNode(_component_svws_ui_tab_bar, { "tab-manager": () => new (unref(TabManager))([], {
				name: "Dummy",
				text: "Dummy"
			}, async (a) => {}) }, {
				default: withCtx(() => [createBaseVNode("div", _hoisted_2, [createBaseVNode("div", _hoisted_3, [
					createVNode(_component_s_schema_neu_leer, {
						"add-schema": _ctx.addSchema,
						loading: loading.value,
						"set-status": setStatus,
						"validator-username": validatorUsername,
						"is-open": currentAction.value === "neu",
						onOpened: _cache[0] || (_cache[0] = (isOpen) => setCurrentAction("neu", isOpen))
					}, null, 8, [
						"add-schema",
						"loading",
						"is-open"
					]),
					createVNode(_component_s_schema_neu_restore, {
						"import-schema": _ctx.importSchema,
						loading: loading.value,
						"set-status": setStatus,
						"validator-username": validatorUsername,
						"is-open": currentAction.value === "restore",
						onOpened: _cache[1] || (_cache[1] = (isOpen) => setCurrentAction("restore", isOpen))
					}, null, 8, [
						"import-schema",
						"loading",
						"is-open"
					]),
					createVNode(_component_s_schema_neu_migrate, {
						"migrate-schema": _ctx.migrateSchema,
						"migration-quellinformationen": _ctx.migrationQuellinformationen,
						loading: loading.value,
						"set-status": setStatus,
						"validator-username": validatorUsername,
						"is-open": currentAction.value === "migrate",
						onOpened: _cache[2] || (_cache[2] = (isOpen) => setCurrentAction("migrate", isOpen))
					}, null, 8, [
						"migrate-schema",
						"migration-quellinformationen",
						"loading",
						"is-open"
					]),
					_ctx.schema !== void 0 ? (openBlock(), createBlock(_component_s_schema_neu_duplicate, {
						key: 0,
						"duplicate-schema": _ctx.duplicateSchema,
						loading: loading.value,
						"set-status": setStatus,
						"is-open": currentAction.value === "duplicate",
						onOpened: _cache[3] || (_cache[3] = (isOpen) => setCurrentAction("duplicate", isOpen)),
						"validator-username": validatorUsername,
						schema: _ctx.schema
					}, null, 8, [
						"duplicate-schema",
						"loading",
						"is-open",
						"schema"
					])) : createCommentVNode("", true)
				]), createBaseVNode("div", _hoisted_4, [createVNode(_component_log_box, {
					logs: logs.value,
					status: status.value
				}, {
					button: withCtx(() => [status.value !== void 0 ? (openBlock(), createBlock(_component_svws_ui_button, {
						key: 0,
						type: "transparent",
						onClick: clear,
						title: "Log verwerfen"
					}, {
						default: withCtx(() => [..._cache[4] || (_cache[4] = [createTextVNode("Log verwerfen ", -1)])]),
						_: 1
					})) : createCommentVNode("", true)]),
					_: 1
				}, 8, ["logs", "status"])])])]),
				_: 1
			}, 8, ["tab-manager"])]);
		};
	}
});
var SSchemaNeu_default = SSchemaNeu_vue_vue_type_script_setup_true_lang_default;
export { SSchemaNeu_default as default };

//# sourceMappingURL=SSchemaNeu.js.map