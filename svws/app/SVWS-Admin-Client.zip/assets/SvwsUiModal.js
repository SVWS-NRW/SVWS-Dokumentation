import { $ as withCtx, C as createVNode, D as defineComponent, E as getCurrentInstance, F as h, H as inject, J as nextTick, M as onMounted, N as onUnmounted, P as openBlock, Q as provide, S as renderSlot, X as useId, Z as watch, _ as watchEffect, a6 as reactive, a8 as ref, aa as shallowRef, af as unref, ag as normalizeClass, b as SvwsUiButton_default, p as withKeys, q as withModifiers, r as Fragment, s as Teleport, t as cloneVNode, u as computed, v as createBaseVNode, w as createBlock, x as createCommentVNode, y as createElementBlock } from "./index.js";
import { b as SvwsUiTooltip_default } from "./SvwsUiTooltip.js";
var __plugin_vue_export_helper_default = (sfc, props) => {
	const target = sfc.__vccOpts || sfc;
	for (const [key, val] of props) target[key] = val;
	return target;
};
function t$4(e$1) {
	typeof queueMicrotask == "function" ? queueMicrotask(e$1) : Promise.resolve().then(e$1).catch((o$4) => setTimeout(() => {
		throw o$4;
	}));
}
function o$1() {
	let a$2 = [], s$4 = {
		addEventListener(e$1, t$6, r$1, i$6) {
			return e$1.addEventListener(t$6, r$1, i$6), s$4.add(() => e$1.removeEventListener(t$6, r$1, i$6));
		},
		requestAnimationFrame(...e$1) {
			let t$6 = requestAnimationFrame(...e$1);
			s$4.add(() => cancelAnimationFrame(t$6));
		},
		nextFrame(...e$1) {
			s$4.requestAnimationFrame(() => {
				s$4.requestAnimationFrame(...e$1);
			});
		},
		setTimeout(...e$1) {
			let t$6 = setTimeout(...e$1);
			s$4.add(() => clearTimeout(t$6));
		},
		microTask(...e$1) {
			let t$6 = { current: !0 };
			return t$4(() => {
				t$6.current && e$1[0]();
			}), s$4.add(() => {
				t$6.current = !1;
			});
		},
		style(e$1, t$6, r$1) {
			let i$6 = e$1.style.getPropertyValue(t$6);
			return Object.assign(e$1.style, { [t$6]: r$1 }), this.add(() => {
				Object.assign(e$1.style, { [t$6]: i$6 });
			});
		},
		group(e$1) {
			let t$6 = o$1();
			return e$1(t$6), this.add(() => t$6.dispose());
		},
		add(e$1) {
			return a$2.push(e$1), () => {
				let t$6 = a$2.indexOf(e$1);
				if (t$6 >= 0) for (let r$1 of a$2.splice(t$6, 1)) r$1();
			};
		},
		dispose() {
			for (let e$1 of a$2.splice(0)) e$1();
		}
	};
	return s$4;
}
var r;
let n$4 = Symbol("headlessui.useid"), o$3 = 0;
const i = (r = useId) != null ? r : function() {
	return inject(n$4, () => `${++o$3}`)();
};
function o(e$1) {
	var l$3;
	if (e$1 == null || e$1.value == null) return null;
	let n$5 = (l$3 = e$1.value.$el) != null ? l$3 : e$1.value;
	return n$5 instanceof Node ? n$5 : null;
}
function u(r$1, n$5, ...a$2) {
	if (r$1 in n$5) {
		let e$1 = n$5[r$1];
		return typeof e$1 == "function" ? e$1(...a$2) : e$1;
	}
	let t$6 = /* @__PURE__ */ new Error(`Tried to handle "${r$1}" but there is no handler defined. Only defined handlers are: ${Object.keys(n$5).map((e$1) => `"${e$1}"`).join(", ")}.`);
	throw Error.captureStackTrace && Error.captureStackTrace(t$6, u), t$6;
}
var i$5 = Object.defineProperty;
var d$4 = (t$6, e$1, r$1) => e$1 in t$6 ? i$5(t$6, e$1, {
	enumerable: !0,
	configurable: !0,
	writable: !0,
	value: r$1
}) : t$6[e$1] = r$1;
var n$3 = (t$6, e$1, r$1) => (d$4(t$6, typeof e$1 != "symbol" ? e$1 + "" : e$1, r$1), r$1);
var s$3 = class {
	constructor() {
		n$3(this, "current", this.detect());
		n$3(this, "currentId", 0);
	}
	set(e$1) {
		this.current !== e$1 && (this.currentId = 0, this.current = e$1);
	}
	reset() {
		this.set(this.detect());
	}
	nextId() {
		return ++this.currentId;
	}
	get isServer() {
		return this.current === "server";
	}
	get isClient() {
		return this.current === "client";
	}
	detect() {
		return typeof window == "undefined" || typeof document == "undefined" ? "server" : "client";
	}
};
let c = new s$3();
function i$2(r$1) {
	if (c.isServer) return null;
	if (r$1 instanceof Node) return r$1.ownerDocument;
	if (r$1 != null && r$1.hasOwnProperty("value")) {
		let n$5 = o(r$1);
		if (n$5) return n$5.ownerDocument;
	}
	return document;
}
let c$2 = [
	"[contentEditable=true]",
	"[tabindex]",
	"a[href]",
	"area[href]",
	"button:not([disabled])",
	"iframe",
	"input:not([disabled])",
	"select:not([disabled])",
	"textarea:not([disabled])"
].map((e$1) => `${e$1}:not([tabindex='-1'])`).join(",");
var N$3 = ((n$5) => (n$5[n$5.First = 1] = "First", n$5[n$5.Previous = 2] = "Previous", n$5[n$5.Next = 4] = "Next", n$5[n$5.Last = 8] = "Last", n$5[n$5.WrapAround = 16] = "WrapAround", n$5[n$5.NoScroll = 32] = "NoScroll", n$5))(N$3 || {}), T$2 = ((o$4) => (o$4[o$4.Error = 0] = "Error", o$4[o$4.Overflow = 1] = "Overflow", o$4[o$4.Success = 2] = "Success", o$4[o$4.Underflow = 3] = "Underflow", o$4))(T$2 || {}), F$1 = ((t$6) => (t$6[t$6.Previous = -1] = "Previous", t$6[t$6.Next = 1] = "Next", t$6))(F$1 || {});
function E$2(e$1 = document.body) {
	return e$1 == null ? [] : Array.from(e$1.querySelectorAll(c$2)).sort((r$1, t$6) => Math.sign((r$1.tabIndex || Number.MAX_SAFE_INTEGER) - (t$6.tabIndex || Number.MAX_SAFE_INTEGER)));
}
var h$1 = ((t$6) => (t$6[t$6.Strict = 0] = "Strict", t$6[t$6.Loose = 1] = "Loose", t$6))(h$1 || {});
function w$4(e$1, r$1 = 0) {
	var t$6;
	return e$1 === ((t$6 = i$2(e$1)) == null ? void 0 : t$6.body) ? !1 : u(r$1, {
		[0]() {
			return e$1.matches(c$2);
		},
		[1]() {
			let l$3 = e$1;
			for (; l$3 !== null;) {
				if (l$3.matches(c$2)) return !0;
				l$3 = l$3.parentElement;
			}
			return !1;
		}
	});
}
var y$2 = ((t$6) => (t$6[t$6.Keyboard = 0] = "Keyboard", t$6[t$6.Mouse = 1] = "Mouse", t$6))(y$2 || {});
typeof window != "undefined" && typeof document != "undefined" && (document.addEventListener("keydown", (e$1) => {
	e$1.metaKey || e$1.altKey || e$1.ctrlKey || (document.documentElement.dataset.headlessuiFocusVisible = "");
}, !0), document.addEventListener("click", (e$1) => {
	e$1.detail === 1 ? delete document.documentElement.dataset.headlessuiFocusVisible : e$1.detail === 0 && (document.documentElement.dataset.headlessuiFocusVisible = "");
}, !0));
function S$1(e$1) {
	e$1?.focus({ preventScroll: !0 });
}
let H$2 = ["textarea", "input"].join(",");
function I(e$1) {
	var r$1, t$6;
	return (t$6 = (r$1 = e$1 == null ? void 0 : e$1.matches) == null ? void 0 : r$1.call(e$1, H$2)) != null ? t$6 : !1;
}
function O(e$1, r$1 = (t$6) => t$6) {
	return e$1.slice().sort((t$6, l$3) => {
		let o$4 = r$1(t$6), i$6 = r$1(l$3);
		if (o$4 === null || i$6 === null) return 0;
		let n$5 = o$4.compareDocumentPosition(i$6);
		return n$5 & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : n$5 & Node.DOCUMENT_POSITION_PRECEDING ? 1 : 0;
	});
}
function P(e$1, r$1, { sorted: t$6 = !0, relativeTo: l$3 = null, skipElements: o$4 = [] } = {}) {
	var m$3;
	let i$6 = (m$3 = Array.isArray(e$1) ? e$1.length > 0 ? e$1[0].ownerDocument : document : e$1 == null ? void 0 : e$1.ownerDocument) != null ? m$3 : document, n$5 = Array.isArray(e$1) ? t$6 ? O(e$1) : e$1 : E$2(e$1);
	o$4.length > 0 && n$5.length > 1 && (n$5 = n$5.filter((s$4) => !o$4.includes(s$4))), l$3 = l$3 != null ? l$3 : i$6.activeElement;
	let x$1 = (() => {
		if (r$1 & 5) return 1;
		if (r$1 & 10) return -1;
		throw new Error("Missing Focus.First, Focus.Previous, Focus.Next or Focus.Last");
	})(), p = (() => {
		if (r$1 & 1) return 0;
		if (r$1 & 2) return Math.max(0, n$5.indexOf(l$3)) - 1;
		if (r$1 & 4) return Math.max(0, n$5.indexOf(l$3)) + 1;
		if (r$1 & 8) return n$5.length - 1;
		throw new Error("Missing Focus.First, Focus.Previous, Focus.Next or Focus.Last");
	})(), L$2 = r$1 & 32 ? { preventScroll: !0 } : {}, a$2 = 0, d$5 = n$5.length, u$6;
	do {
		if (a$2 >= d$5 || a$2 + d$5 <= 0) return 0;
		let s$4 = p + a$2;
		if (r$1 & 16) s$4 = (s$4 + d$5) % d$5;
		else {
			if (s$4 < 0) return 3;
			if (s$4 >= d$5) return 1;
		}
		u$6 = n$5[s$4], u$6?.focus(L$2), a$2 += x$1;
	} while (u$6 !== i$6.activeElement);
	return r$1 & 6 && I(u$6) && u$6.select(), 2;
}
function t$2() {
	return /iPhone/gi.test(window.navigator.platform) || /Mac/gi.test(window.navigator.platform) && window.navigator.maxTouchPoints > 0;
}
function i$4() {
	return /Android/gi.test(window.navigator.userAgent);
}
function n$2() {
	return t$2() || i$4();
}
function u$5(e$1, t$6, n$5) {
	c.isServer || watchEffect((o$4) => {
		document.addEventListener(e$1, t$6, n$5), o$4(() => document.removeEventListener(e$1, t$6, n$5));
	});
}
function w$3(e$1, n$5, t$6) {
	c.isServer || watchEffect((o$4) => {
		window.addEventListener(e$1, n$5, t$6), o$4(() => window.removeEventListener(e$1, n$5, t$6));
	});
}
function w(f$2, m$3, l$3 = computed(() => !0)) {
	function a$2(e$1, r$1) {
		if (!l$3.value || e$1.defaultPrevented) return;
		let t$6 = r$1(e$1);
		if (t$6 === null || !t$6.getRootNode().contains(t$6)) return;
		let c$3 = function o$4(n$5) {
			return typeof n$5 == "function" ? o$4(n$5()) : Array.isArray(n$5) || n$5 instanceof Set ? n$5 : [n$5];
		}(f$2);
		for (let o$4 of c$3) {
			if (o$4 === null) continue;
			let n$5 = o$4 instanceof HTMLElement ? o$4 : o(o$4);
			if (n$5 != null && n$5.contains(t$6) || e$1.composed && e$1.composedPath().includes(n$5)) return;
		}
		return !w$4(t$6, h$1.Loose) && t$6.tabIndex !== -1 && e$1.preventDefault(), m$3(e$1, t$6);
	}
	let u$6 = ref(null);
	u$5("pointerdown", (e$1) => {
		var r$1, t$6;
		l$3.value && (u$6.value = ((t$6 = (r$1 = e$1.composedPath) == null ? void 0 : r$1.call(e$1)) == null ? void 0 : t$6[0]) || e$1.target);
	}, !0), u$5("mousedown", (e$1) => {
		var r$1, t$6;
		l$3.value && (u$6.value = ((t$6 = (r$1 = e$1.composedPath) == null ? void 0 : r$1.call(e$1)) == null ? void 0 : t$6[0]) || e$1.target);
	}, !0), u$5("click", (e$1) => {
		n$2() || u$6.value && (a$2(e$1, () => u$6.value), u$6.value = null);
	}, !0), u$5("touchend", (e$1) => a$2(e$1, () => e$1.target instanceof HTMLElement ? e$1.target : null), !0), w$3("blur", (e$1) => a$2(e$1, () => window.document.activeElement instanceof HTMLIFrameElement ? window.document.activeElement : null), !0);
}
var N = ((o$4) => (o$4[o$4.None = 0] = "None", o$4[o$4.RenderStrategy = 1] = "RenderStrategy", o$4[o$4.Static = 2] = "Static", o$4))(N || {}), S = ((e$1) => (e$1[e$1.Unmount = 0] = "Unmount", e$1[e$1.Hidden = 1] = "Hidden", e$1))(S || {});
function A({ visible: r$1 = !0, features: t$6 = 0, ourProps: e$1, theirProps: o$4,...i$6 }) {
	var a$2;
	let n$5 = j(o$4, e$1), l$3 = Object.assign(i$6, { props: n$5 });
	if (r$1 || t$6 & 2 && n$5.static) return y$1(l$3);
	if (t$6 & 1) {
		let d$5 = (a$2 = n$5.unmount) == null || a$2 ? 0 : 1;
		return u(d$5, {
			[0]() {
				return null;
			},
			[1]() {
				return y$1({
					...i$6,
					props: {
						...n$5,
						hidden: !0,
						style: { display: "none" }
					}
				});
			}
		});
	}
	return y$1(l$3);
}
function y$1({ props: r$1, attrs: t$6, slots: e$1, slot: o$4, name: i$6 }) {
	var m$3, h$2;
	let { as: n$5,...l$3 } = T(r$1, ["unmount", "static"]), a$2 = (m$3 = e$1.default) == null ? void 0 : m$3.call(e$1, o$4), d$5 = {};
	if (o$4) {
		let u$6 = !1, c$3 = [];
		for (let [p, f$2] of Object.entries(o$4)) typeof f$2 == "boolean" && (u$6 = !0), f$2 === !0 && c$3.push(p);
		u$6 && (d$5["data-headlessui-state"] = c$3.join(" "));
	}
	if (n$5 === "template") {
		if (a$2 = b(a$2 != null ? a$2 : []), Object.keys(l$3).length > 0 || Object.keys(t$6).length > 0) {
			let [u$6, ...c$3] = a$2 != null ? a$2 : [];
			if (!v(u$6) || c$3.length > 0) throw new Error([
				"Passing props on \"template\"!",
				"",
				`The current component <${i$6} /> is rendering a "template".`,
				"However we need to passthrough the following props:",
				Object.keys(l$3).concat(Object.keys(t$6)).map((s$4) => s$4.trim()).filter((s$4, g$2, R$2) => R$2.indexOf(s$4) === g$2).sort((s$4, g$2) => s$4.localeCompare(g$2)).map((s$4) => `  - ${s$4}`).join(`
`),
				"",
				"You can apply a few solutions:",
				["Add an `as=\"...\"` prop, to ensure that we render an actual element instead of a \"template\".", "Render a single element as the child so that we can forward the props onto that element."].map((s$4) => `  - ${s$4}`).join(`
`)
			].join(`
`));
			let p = j((h$2 = u$6.props) != null ? h$2 : {}, l$3, d$5), f$2 = cloneVNode(u$6, p, !0);
			for (let s$4 in p) s$4.startsWith("on") && (f$2.props || (f$2.props = {}), f$2.props[s$4] = p[s$4]);
			return f$2;
		}
		return Array.isArray(a$2) && a$2.length === 1 ? a$2[0] : a$2;
	}
	return h(n$5, Object.assign({}, l$3, d$5), { default: () => a$2 });
}
function b(r$1) {
	return r$1.flatMap((t$6) => t$6.type === Fragment ? b(t$6.children) : [t$6]);
}
function j(...r$1) {
	var o$4;
	if (r$1.length === 0) return {};
	if (r$1.length === 1) return r$1[0];
	let t$6 = {}, e$1 = {};
	for (let i$6 of r$1) for (let n$5 in i$6) n$5.startsWith("on") && typeof i$6[n$5] == "function" ? ((o$4 = e$1[n$5]) ?? (e$1[n$5] = []), e$1[n$5].push(i$6[n$5])) : t$6[n$5] = i$6[n$5];
	if (t$6.disabled || t$6["aria-disabled"]) return Object.assign(t$6, Object.fromEntries(Object.keys(e$1).map((i$6) => [i$6, void 0])));
	for (let i$6 in e$1) Object.assign(t$6, { [i$6](n$5, ...l$3) {
		let a$2 = e$1[i$6];
		for (let d$5 of a$2) {
			if (n$5 instanceof Event && n$5.defaultPrevented) return;
			d$5(n$5, ...l$3);
		}
	} });
	return t$6;
}
function T(r$1, t$6 = []) {
	let e$1 = Object.assign({}, r$1);
	for (let o$4 of t$6) o$4 in e$1 && delete e$1[o$4];
	return e$1;
}
function v(r$1) {
	return r$1 == null ? !1 : typeof r$1.type == "string" || typeof r$1.type == "object" || typeof r$1.type == "function";
}
var u$4 = ((e$1) => (e$1[e$1.None = 1] = "None", e$1[e$1.Focusable = 2] = "Focusable", e$1[e$1.Hidden = 4] = "Hidden", e$1))(u$4 || {});
let f$1 = defineComponent({
	name: "Hidden",
	props: {
		as: {
			type: [Object, String],
			default: "div"
		},
		features: {
			type: Number,
			default: 1
		}
	},
	setup(t$6, { slots: n$5, attrs: i$6 }) {
		return () => {
			var r$1;
			let { features: e$1,...d$5 } = t$6, o$4 = {
				"aria-hidden": (e$1 & 2) === 2 ? !0 : (r$1 = d$5["aria-hidden"]) != null ? r$1 : void 0,
				hidden: (e$1 & 4) === 4 ? !0 : void 0,
				style: {
					position: "fixed",
					top: 1,
					left: 1,
					width: 1,
					height: 0,
					padding: 0,
					margin: -1,
					overflow: "hidden",
					clip: "rect(0, 0, 0, 0)",
					whiteSpace: "nowrap",
					borderWidth: "0",
					...(e$1 & 4) === 4 && (e$1 & 2) !== 2 && { display: "none" }
				}
			};
			return A({
				ourProps: o$4,
				theirProps: d$5,
				slot: {},
				attrs: i$6,
				slots: n$5,
				name: "Hidden"
			});
		};
	}
});
let n$1 = Symbol("Context");
var i$1 = ((e$1) => (e$1[e$1.Open = 1] = "Open", e$1[e$1.Closed = 2] = "Closed", e$1[e$1.Closing = 4] = "Closing", e$1[e$1.Opening = 8] = "Opening", e$1))(i$1 || {});
function s() {
	return l() !== null;
}
function l() {
	return inject(n$1, null);
}
function t(o$4) {
	provide(n$1, o$4);
}
var o$2 = ((r$1) => (r$1.Space = " ", r$1.Enter = "Enter", r$1.Escape = "Escape", r$1.Backspace = "Backspace", r$1.Delete = "Delete", r$1.ArrowLeft = "ArrowLeft", r$1.ArrowUp = "ArrowUp", r$1.ArrowRight = "ArrowRight", r$1.ArrowDown = "ArrowDown", r$1.Home = "Home", r$1.End = "End", r$1.PageUp = "PageUp", r$1.PageDown = "PageDown", r$1.Tab = "Tab", r$1))(o$2 || {});
function t$5(n$5) {
	function e$1() {
		document.readyState !== "loading" && (n$5(), document.removeEventListener("DOMContentLoaded", e$1));
	}
	typeof window != "undefined" && typeof document != "undefined" && (document.addEventListener("DOMContentLoaded", e$1), e$1());
}
let t$3 = [];
t$5(() => {
	function e$1(n$5) {
		n$5.target instanceof HTMLElement && n$5.target !== document.body && t$3[0] !== n$5.target && (t$3.unshift(n$5.target), t$3 = t$3.filter((r$1) => r$1 != null && r$1.isConnected), t$3.splice(10));
	}
	window.addEventListener("click", e$1, { capture: !0 }), window.addEventListener("mousedown", e$1, { capture: !0 }), window.addEventListener("focus", e$1, { capture: !0 }), document.body.addEventListener("click", e$1, { capture: !0 }), document.body.addEventListener("mousedown", e$1, { capture: !0 }), document.body.addEventListener("focus", e$1, { capture: !0 });
});
function E(n$5, e$1, o$4, r$1) {
	c.isServer || watchEffect((t$6) => {
		n$5 = n$5 != null ? n$5 : window, n$5.addEventListener(e$1, o$4, r$1), t$6(() => n$5.removeEventListener(e$1, o$4, r$1));
	});
}
var d$3 = ((r$1) => (r$1[r$1.Forwards = 0] = "Forwards", r$1[r$1.Backwards = 1] = "Backwards", r$1))(d$3 || {});
function n() {
	let o$4 = ref(0);
	return w$3("keydown", (e$1) => {
		e$1.key === "Tab" && (o$4.value = e$1.shiftKey ? 1 : 0);
	}), o$4;
}
function B(t$6) {
	if (!t$6) return /* @__PURE__ */ new Set();
	if (typeof t$6 == "function") return new Set(t$6());
	let n$5 = /* @__PURE__ */ new Set();
	for (let r$1 of t$6.value) {
		let l$3 = o(r$1);
		l$3 instanceof HTMLElement && n$5.add(l$3);
	}
	return n$5;
}
var A$2 = ((e$1) => (e$1[e$1.None = 1] = "None", e$1[e$1.InitialFocus = 2] = "InitialFocus", e$1[e$1.TabLock = 4] = "TabLock", e$1[e$1.FocusLock = 8] = "FocusLock", e$1[e$1.RestoreFocus = 16] = "RestoreFocus", e$1[e$1.All = 30] = "All", e$1))(A$2 || {});
let ue = Object.assign(defineComponent({
	name: "FocusTrap",
	props: {
		as: {
			type: [Object, String],
			default: "div"
		},
		initialFocus: {
			type: Object,
			default: null
		},
		features: {
			type: Number,
			default: 30
		},
		containers: {
			type: [Object, Function],
			default: ref(/* @__PURE__ */ new Set())
		}
	},
	inheritAttrs: !1,
	setup(t$6, { attrs: n$5, slots: r$1, expose: l$3 }) {
		let o$4 = ref(null);
		l$3({
			el: o$4,
			$el: o$4
		});
		let i$6 = computed(() => i$2(o$4)), e$1 = ref(!1);
		onMounted(() => e$1.value = !0), onUnmounted(() => e$1.value = !1), $$1({ ownerDocument: i$6 }, computed(() => e$1.value && Boolean(t$6.features & 16)));
		let m$3 = z$1({
			ownerDocument: i$6,
			container: o$4,
			initialFocus: computed(() => t$6.initialFocus)
		}, computed(() => e$1.value && Boolean(t$6.features & 2)));
		J({
			ownerDocument: i$6,
			container: o$4,
			containers: t$6.containers,
			previousActiveElement: m$3
		}, computed(() => e$1.value && Boolean(t$6.features & 8)));
		let f$2 = n();
		function a$2(u$6) {
			let T$3 = o(o$4);
			if (!T$3) return;
			((w$5) => w$5())(() => {
				u(f$2.value, {
					[d$3.Forwards]: () => {
						P(T$3, N$3.First, { skipElements: [u$6.relatedTarget] });
					},
					[d$3.Backwards]: () => {
						P(T$3, N$3.Last, { skipElements: [u$6.relatedTarget] });
					}
				});
			});
		}
		let s$4 = ref(!1);
		function F$2(u$6) {
			u$6.key === "Tab" && (s$4.value = !0, requestAnimationFrame(() => {
				s$4.value = !1;
			}));
		}
		function H$3(u$6) {
			if (!e$1.value) return;
			let T$3 = B(t$6.containers);
			o(o$4) instanceof HTMLElement && T$3.add(o(o$4));
			let d$5 = u$6.relatedTarget;
			d$5 instanceof HTMLElement && d$5.dataset.headlessuiFocusGuard !== "true" && (N$4(T$3, d$5) || (s$4.value ? P(o(o$4), u(f$2.value, {
				[d$3.Forwards]: () => N$3.Next,
				[d$3.Backwards]: () => N$3.Previous
			}) | N$3.WrapAround, { relativeTo: u$6.target }) : u$6.target instanceof HTMLElement && S$1(u$6.target)));
		}
		return () => {
			let u$6 = {}, T$3 = {
				ref: o$4,
				onKeydown: F$2,
				onFocusout: H$3
			}, { features: d$5, initialFocus: w$5, containers: Q$1,...O$1 } = t$6;
			return h(Fragment, [
				Boolean(d$5 & 4) && h(f$1, {
					as: "button",
					type: "button",
					"data-headlessui-focus-guard": !0,
					onFocus: a$2,
					features: u$4.Focusable
				}),
				A({
					ourProps: T$3,
					theirProps: {
						...n$5,
						...O$1
					},
					slot: u$6,
					attrs: n$5,
					slots: r$1,
					name: "FocusTrap"
				}),
				Boolean(d$5 & 4) && h(f$1, {
					as: "button",
					type: "button",
					"data-headlessui-focus-guard": !0,
					onFocus: a$2,
					features: u$4.Focusable
				})
			]);
		};
	}
}), { features: A$2 });
function W$1(t$6) {
	let n$5 = ref(t$3.slice());
	return watch([t$6], ([r$1], [l$3]) => {
		l$3 === !0 && r$1 === !1 ? t$4(() => {
			n$5.value.splice(0);
		}) : l$3 === !1 && r$1 === !0 && (n$5.value = t$3.slice());
	}, { flush: "post" }), () => {
		var r$1;
		return (r$1 = n$5.value.find((l$3) => l$3 != null && l$3.isConnected)) != null ? r$1 : null;
	};
}
function $$1({ ownerDocument: t$6 }, n$5) {
	let r$1 = W$1(n$5);
	onMounted(() => {
		watchEffect(() => {
			var l$3, o$4;
			n$5.value || ((l$3 = t$6.value) == null ? void 0 : l$3.activeElement) === ((o$4 = t$6.value) == null ? void 0 : o$4.body) && S$1(r$1());
		}, { flush: "post" });
	}), onUnmounted(() => {
		n$5.value && S$1(r$1());
	});
}
function z$1({ ownerDocument: t$6, container: n$5, initialFocus: r$1 }, l$3) {
	let o$4 = ref(null), i$6 = ref(!1);
	return onMounted(() => i$6.value = !0), onUnmounted(() => i$6.value = !1), onMounted(() => {
		watch([
			n$5,
			r$1,
			l$3
		], (e$1, m$3) => {
			if (e$1.every((a$2, s$4) => (m$3 == null ? void 0 : m$3[s$4]) === a$2) || !l$3.value) return;
			let f$2 = o(n$5);
			f$2 && t$4(() => {
				var F$2, H$3;
				if (!i$6.value) return;
				let a$2 = o(r$1), s$4 = (F$2 = t$6.value) == null ? void 0 : F$2.activeElement;
				if (a$2) {
					if (a$2 === s$4) {
						o$4.value = s$4;
						return;
					}
				} else if (f$2.contains(s$4)) {
					o$4.value = s$4;
					return;
				}
				a$2 ? S$1(a$2) : P(f$2, N$3.First | N$3.NoScroll) === T$2.Error && console.warn("There are no focusable elements inside the <FocusTrap />"), o$4.value = (H$3 = t$6.value) == null ? void 0 : H$3.activeElement;
			});
		}, {
			immediate: !0,
			flush: "post"
		});
	}), o$4;
}
function J({ ownerDocument: t$6, container: n$5, containers: r$1, previousActiveElement: l$3 }, o$4) {
	var i$6;
	E((i$6 = t$6.value) == null ? void 0 : i$6.defaultView, "focus", (e$1) => {
		if (!o$4.value) return;
		let m$3 = B(r$1);
		o(n$5) instanceof HTMLElement && m$3.add(o(n$5));
		let f$2 = l$3.value;
		if (!f$2) return;
		let a$2 = e$1.target;
		a$2 && a$2 instanceof HTMLElement ? N$4(m$3, a$2) ? (l$3.value = a$2, S$1(a$2)) : (e$1.preventDefault(), e$1.stopPropagation(), S$1(f$2)) : S$1(l$3.value);
	}, !0);
}
function N$4(t$6, n$5) {
	for (let r$1 of t$6) if (r$1.contains(n$5)) return !0;
	return !1;
}
function m$1(t$6) {
	let e$1 = shallowRef(t$6.getSnapshot());
	return onUnmounted(t$6.subscribe(() => {
		e$1.value = t$6.getSnapshot();
	})), e$1;
}
function a$1(o$4, r$1) {
	let t$6 = o$4(), n$5 = /* @__PURE__ */ new Set();
	return {
		getSnapshot() {
			return t$6;
		},
		subscribe(e$1) {
			return n$5.add(e$1), () => n$5.delete(e$1);
		},
		dispatch(e$1, ...s$4) {
			let i$6 = r$1[e$1].call(t$6, ...s$4);
			i$6 && (t$6 = i$6, n$5.forEach((c$3) => c$3()));
		}
	};
}
function c$1() {
	let o$4;
	return {
		before({ doc: e$1 }) {
			var l$3;
			let n$5 = e$1.documentElement;
			o$4 = ((l$3 = e$1.defaultView) != null ? l$3 : window).innerWidth - n$5.clientWidth;
		},
		after({ doc: e$1, d: n$5 }) {
			let t$6 = e$1.documentElement, l$3 = t$6.clientWidth - t$6.offsetWidth, r$1 = o$4 - l$3;
			n$5.style(t$6, "paddingRight", `${r$1}px`);
		}
	};
}
function w$2() {
	return t$2() ? { before({ doc: r$1, d: n$5, meta: c$3 }) {
		function a$2(o$4) {
			return c$3.containers.flatMap((l$3) => l$3()).some((l$3) => l$3.contains(o$4));
		}
		n$5.microTask(() => {
			var s$4;
			if (window.getComputedStyle(r$1.documentElement).scrollBehavior !== "auto") {
				let t$6 = o$1();
				t$6.style(r$1.documentElement, "scrollBehavior", "auto"), n$5.add(() => n$5.microTask(() => t$6.dispose()));
			}
			let o$4 = (s$4 = window.scrollY) != null ? s$4 : window.pageYOffset, l$3 = null;
			n$5.addEventListener(r$1, "click", (t$6) => {
				if (t$6.target instanceof HTMLElement) try {
					let e$1 = t$6.target.closest("a");
					if (!e$1) return;
					let { hash: f$2 } = new URL(e$1.href), i$6 = r$1.querySelector(f$2);
					i$6 && !a$2(i$6) && (l$3 = i$6);
				} catch {}
			}, !0), n$5.addEventListener(r$1, "touchstart", (t$6) => {
				if (t$6.target instanceof HTMLElement) if (a$2(t$6.target)) {
					let e$1 = t$6.target;
					for (; e$1.parentElement && a$2(e$1.parentElement);) e$1 = e$1.parentElement;
					n$5.style(e$1, "overscrollBehavior", "contain");
				} else n$5.style(t$6.target, "touchAction", "none");
			}), n$5.addEventListener(r$1, "touchmove", (t$6) => {
				if (t$6.target instanceof HTMLElement) {
					if (t$6.target.tagName === "INPUT") return;
					if (a$2(t$6.target)) {
						let e$1 = t$6.target;
						for (; e$1.parentElement && e$1.dataset.headlessuiPortal !== "" && !(e$1.scrollHeight > e$1.clientHeight || e$1.scrollWidth > e$1.clientWidth);) e$1 = e$1.parentElement;
						e$1.dataset.headlessuiPortal === "" && t$6.preventDefault();
					} else t$6.preventDefault();
				}
			}, { passive: !1 }), n$5.add(() => {
				var e$1;
				let t$6 = (e$1 = window.scrollY) != null ? e$1 : window.pageYOffset;
				o$4 !== t$6 && window.scrollTo(0, o$4), l$3 && l$3.isConnected && (l$3.scrollIntoView({ block: "nearest" }), l$3 = null);
			});
		});
	} } : {};
}
function l$2() {
	return { before({ doc: e$1, d: o$4 }) {
		o$4.style(e$1.documentElement, "overflow", "hidden");
	} };
}
function m$2(e$1) {
	let n$5 = {};
	for (let t$6 of e$1) Object.assign(n$5, t$6(n$5));
	return n$5;
}
let a = a$1(() => /* @__PURE__ */ new Map(), {
	PUSH(e$1, n$5) {
		var o$4;
		let t$6 = (o$4 = this.get(e$1)) != null ? o$4 : {
			doc: e$1,
			count: 0,
			d: o$1(),
			meta: /* @__PURE__ */ new Set()
		};
		return t$6.count++, t$6.meta.add(n$5), this.set(e$1, t$6), this;
	},
	POP(e$1, n$5) {
		let t$6 = this.get(e$1);
		return t$6 && (t$6.count--, t$6.meta.delete(n$5)), this;
	},
	SCROLL_PREVENT({ doc: e$1, d: n$5, meta: t$6 }) {
		let o$4 = {
			doc: e$1,
			d: n$5,
			meta: m$2(t$6)
		}, c$3 = [
			w$2(),
			c$1(),
			l$2()
		];
		c$3.forEach(({ before: r$1 }) => r$1 == null ? void 0 : r$1(o$4)), c$3.forEach(({ after: r$1 }) => r$1 == null ? void 0 : r$1(o$4));
	},
	SCROLL_ALLOW({ d: e$1 }) {
		e$1.dispose();
	},
	TEARDOWN({ doc: e$1 }) {
		this.delete(e$1);
	}
});
a.subscribe(() => {
	let e$1 = a.getSnapshot(), n$5 = /* @__PURE__ */ new Map();
	for (let [t$6] of e$1) n$5.set(t$6, t$6.documentElement.style.overflow);
	for (let t$6 of e$1.values()) {
		let o$4 = n$5.get(t$6.doc) === "hidden", c$3 = t$6.count !== 0;
		(c$3 && !o$4 || !c$3 && o$4) && a.dispatch(t$6.count > 0 ? "SCROLL_PREVENT" : "SCROLL_ALLOW", t$6), t$6.count === 0 && a.dispatch("TEARDOWN", t$6);
	}
});
function d$1(t$6, a$2, n$5) {
	let i$6 = m$1(a), l$3 = computed(() => {
		let e$1 = t$6.value ? i$6.value.get(t$6.value) : void 0;
		return e$1 ? e$1.count > 0 : !1;
	});
	return watch([t$6, a$2], ([e$1, m$3], [r$1], o$4) => {
		if (!e$1 || !m$3) return;
		a.dispatch("PUSH", e$1, n$5);
		let f$2 = !1;
		o$4(() => {
			f$2 || (a.dispatch("POP", r$1 != null ? r$1 : e$1, n$5), f$2 = !0);
		});
	}, { immediate: !0 }), l$3;
}
let i$3 = /* @__PURE__ */ new Map(), t$1 = /* @__PURE__ */ new Map();
function E$1(d$5, f$2 = ref(!0)) {
	watchEffect((o$4) => {
		var a$2;
		if (!f$2.value) return;
		let e$1 = o(d$5);
		if (!e$1) return;
		o$4(function() {
			var u$6;
			if (!e$1) return;
			let r$1 = (u$6 = t$1.get(e$1)) != null ? u$6 : 1;
			if (r$1 === 1 ? t$1.delete(e$1) : t$1.set(e$1, r$1 - 1), r$1 !== 1) return;
			let n$5 = i$3.get(e$1);
			n$5 && (n$5["aria-hidden"] === null ? e$1.removeAttribute("aria-hidden") : e$1.setAttribute("aria-hidden", n$5["aria-hidden"]), e$1.inert = n$5.inert, i$3.delete(e$1));
		});
		let l$3 = (a$2 = t$1.get(e$1)) != null ? a$2 : 0;
		t$1.set(e$1, l$3 + 1), l$3 === 0 && (i$3.set(e$1, {
			"aria-hidden": e$1.getAttribute("aria-hidden"),
			inert: e$1.inert
		}), e$1.setAttribute("aria-hidden", "true"), e$1.inert = !0);
	});
}
function N$2({ defaultContainers: o$4 = [], portals: i$6, mainTreeNodeRef: H$3 } = {}) {
	let t$6 = ref(null), r$1 = i$2(t$6);
	function u$6() {
		var l$3, f$2, a$2;
		let n$5 = [];
		for (let e$1 of o$4) e$1 !== null && (e$1 instanceof HTMLElement ? n$5.push(e$1) : "value" in e$1 && e$1.value instanceof HTMLElement && n$5.push(e$1.value));
		if (i$6 != null && i$6.value) for (let e$1 of i$6.value) n$5.push(e$1);
		for (let e$1 of (l$3 = r$1 == null ? void 0 : r$1.querySelectorAll("html > *, body > *")) != null ? l$3 : []) e$1 !== document.body && e$1 !== document.head && e$1 instanceof HTMLElement && e$1.id !== "headlessui-portal-root" && (e$1.contains(o(t$6)) || e$1.contains((a$2 = (f$2 = o(t$6)) == null ? void 0 : f$2.getRootNode()) == null ? void 0 : a$2.host) || n$5.some((M$1) => e$1.contains(M$1)) || n$5.push(e$1));
		return n$5;
	}
	return {
		resolveContainers: u$6,
		contains(n$5) {
			return u$6().some((l$3) => l$3.contains(n$5));
		},
		mainTreeNodeRef: t$6,
		MainTreeNode() {
			return H$3 != null ? null : h(f$1, {
				features: u$4.Hidden,
				ref: t$6
			});
		}
	};
}
let e = Symbol("ForcePortalRootContext");
function s$2() {
	return inject(e, !1);
}
let u$1 = defineComponent({
	name: "ForcePortalRoot",
	props: {
		as: {
			type: [Object, String],
			default: "template"
		},
		force: {
			type: Boolean,
			default: !1
		}
	},
	setup(o$4, { slots: t$6, attrs: r$1 }) {
		return provide(e, o$4.force), () => {
			let { force: f$2,...n$5 } = o$4;
			return A({
				theirProps: n$5,
				ourProps: {},
				slot: {},
				slots: t$6,
				attrs: r$1,
				name: "ForcePortalRoot"
			});
		};
	}
});
let u$3 = Symbol("StackContext");
var s$1 = ((e$1) => (e$1[e$1.Add = 0] = "Add", e$1[e$1.Remove = 1] = "Remove", e$1))(s$1 || {});
function y() {
	return inject(u$3, () => {});
}
function R$1({ type: o$4, enabled: r$1, element: e$1, onUpdate: i$6 }) {
	let a$2 = y();
	function t$6(...n$5) {
		i$6?.(...n$5), a$2(...n$5);
	}
	onMounted(() => {
		watch(r$1, (n$5, d$5) => {
			n$5 ? t$6(0, o$4, e$1) : d$5 === !0 && t$6(1, o$4, e$1);
		}, {
			immediate: !0,
			flush: "sync"
		});
	}), onUnmounted(() => {
		r$1.value && t$6(1, o$4, e$1);
	}), provide(u$3, t$6);
}
let u$2 = Symbol("DescriptionContext");
function w$1() {
	let t$6 = inject(u$2, null);
	if (t$6 === null) throw new Error("Missing parent");
	return t$6;
}
function k({ slot: t$6 = ref({}), name: o$4 = "Description", props: s$4 = {} } = {}) {
	let e$1 = ref([]);
	function r$1(n$5) {
		return e$1.value.push(n$5), () => {
			let i$6 = e$1.value.indexOf(n$5);
			i$6 !== -1 && e$1.value.splice(i$6, 1);
		};
	}
	return provide(u$2, {
		register: r$1,
		slot: t$6,
		name: o$4,
		props: s$4
	}), computed(() => e$1.value.length > 0 ? e$1.value.join(" ") : void 0);
}
let K = defineComponent({
	name: "Description",
	props: {
		as: {
			type: [Object, String],
			default: "p"
		},
		id: {
			type: String,
			default: null
		}
	},
	setup(t$6, { attrs: o$4, slots: s$4 }) {
		var n$5;
		let e$1 = (n$5 = t$6.id) != null ? n$5 : `headlessui-description-${i()}`, r$1 = w$1();
		return onMounted(() => onUnmounted(r$1.register(e$1))), () => {
			let { name: i$6 = "Description", slot: l$3 = ref({}), props: d$5 = {} } = r$1, { ...c$3 } = t$6, f$2 = {
				...Object.entries(d$5).reduce((a$2, [g$2, m$3]) => Object.assign(a$2, { [g$2]: unref(m$3) }), {}),
				id: e$1
			};
			return A({
				ourProps: f$2,
				theirProps: c$3,
				slot: l$3.value,
				attrs: o$4,
				slots: s$4,
				name: i$6
			});
		};
	}
});
function x(e$1) {
	let t$6 = i$2(e$1);
	if (!t$6) {
		if (e$1 === null) return null;
		throw new Error(`[Headless UI]: Cannot find ownerDocument for contextElement: ${e$1}`);
	}
	let l$3 = t$6.getElementById("headlessui-portal-root");
	if (l$3) return l$3;
	let r$1 = t$6.createElement("div");
	return r$1.setAttribute("id", "headlessui-portal-root"), t$6.body.appendChild(r$1);
}
const f = /* @__PURE__ */ new WeakMap();
function U(e$1) {
	var t$6;
	return (t$6 = f.get(e$1)) != null ? t$6 : 0;
}
function M(e$1, t$6) {
	let l$3 = t$6(U(e$1));
	return l$3 <= 0 ? f.delete(e$1) : f.set(e$1, l$3), l$3;
}
let $ = defineComponent({
	name: "Portal",
	props: { as: {
		type: [Object, String],
		default: "div"
	} },
	setup(e$1, { slots: t$6, attrs: l$3 }) {
		let r$1 = ref(null), i$6 = computed(() => i$2(r$1)), o$4 = s$2(), u$6 = inject(H$1, null), n$5 = ref(o$4 === !0 || u$6 == null ? x(r$1.value) : u$6.resolveTarget());
		n$5.value && M(n$5.value, (a$2) => a$2 + 1);
		let c$3 = ref(!1);
		onMounted(() => {
			c$3.value = !0;
		}), watchEffect(() => {
			o$4 || u$6 != null && (n$5.value = u$6.resolveTarget());
		});
		let v$1 = inject(d$2, null), g$2 = !1, b$1 = getCurrentInstance();
		return watch(r$1, () => {
			if (g$2 || !v$1) return;
			let a$2 = o(r$1);
			a$2 && (onUnmounted(v$1.register(a$2), b$1), g$2 = !0);
		}), onUnmounted(() => {
			var P$1, T$3;
			let a$2 = (P$1 = i$6.value) == null ? void 0 : P$1.getElementById("headlessui-portal-root");
			!a$2 || n$5.value !== a$2 || M(n$5.value, (L$2) => L$2 - 1) || n$5.value.children.length > 0 || (T$3 = n$5.value.parentElement) == null || T$3.removeChild(n$5.value);
		}), () => {
			if (!c$3.value || n$5.value === null) return null;
			let a$2 = {
				ref: r$1,
				"data-headlessui-portal": ""
			};
			return h(Teleport, { to: n$5.value }, A({
				ourProps: a$2,
				theirProps: e$1,
				slot: {},
				attrs: l$3,
				slots: t$6,
				name: "Portal"
			}));
		};
	}
}), d$2 = Symbol("PortalParentContext");
function q() {
	let e$1 = inject(d$2, null), t$6 = ref([]);
	function l$3(o$4) {
		return t$6.value.push(o$4), e$1 && e$1.register(o$4), () => r$1(o$4);
	}
	function r$1(o$4) {
		let u$6 = t$6.value.indexOf(o$4);
		u$6 !== -1 && t$6.value.splice(u$6, 1), e$1 && e$1.unregister(o$4);
	}
	let i$6 = {
		register: l$3,
		unregister: r$1,
		portals: t$6
	};
	return [t$6, defineComponent({
		name: "PortalWrapper",
		setup(o$4, { slots: u$6 }) {
			return provide(d$2, i$6), () => {
				var n$5;
				return (n$5 = u$6.default) == null ? void 0 : n$5.call(u$6);
			};
		}
	})];
}
let H$1 = Symbol("PortalGroupContext"), z = defineComponent({
	name: "PortalGroup",
	props: {
		as: {
			type: [Object, String],
			default: "template"
		},
		target: {
			type: Object,
			default: null
		}
	},
	setup(e$1, { attrs: t$6, slots: l$3 }) {
		let r$1 = reactive({ resolveTarget() {
			return e$1.target;
		} });
		return provide(H$1, r$1), () => {
			let { target: i$6,...o$4 } = e$1;
			return A({
				theirProps: o$4,
				ourProps: {},
				slot: {},
				attrs: t$6,
				slots: l$3,
				name: "PortalGroup"
			});
		};
	}
});
var Te$1 = ((l$3) => (l$3[l$3.Open = 0] = "Open", l$3[l$3.Closed = 1] = "Closed", l$3))(Te$1 || {});
let H = Symbol("DialogContext");
function T$1(t$6) {
	let i$6 = inject(H, null);
	if (i$6 === null) {
		let l$3 = /* @__PURE__ */ new Error(`<${t$6} /> is missing a parent <Dialog /> component.`);
		throw Error.captureStackTrace && Error.captureStackTrace(l$3, T$1), l$3;
	}
	return i$6;
}
let A$1 = "DC8F892D-2EBD-447C-A4C8-A03058436FF4", Ye = defineComponent({
	name: "Dialog",
	inheritAttrs: !1,
	props: {
		as: {
			type: [Object, String],
			default: "div"
		},
		static: {
			type: Boolean,
			default: !1
		},
		unmount: {
			type: Boolean,
			default: !0
		},
		open: {
			type: [Boolean, String],
			default: A$1
		},
		initialFocus: {
			type: Object,
			default: null
		},
		id: {
			type: String,
			default: null
		},
		role: {
			type: String,
			default: "dialog"
		}
	},
	emits: { close: (t$6) => !0 },
	setup(t$6, { emit: i$6, attrs: l$3, slots: p, expose: s$4 }) {
		var q$1, W$2;
		let n$5 = (q$1 = t$6.id) != null ? q$1 : `headlessui-dialog-${i()}`, u$6 = ref(!1);
		onMounted(() => {
			u$6.value = !0;
		});
		let r$1 = !1, g$2 = computed(() => t$6.role === "dialog" || t$6.role === "alertdialog" ? t$6.role : (r$1 || (r$1 = !0, console.warn(`Invalid role [${g$2}] passed to <Dialog />. Only \`dialog\` and and \`alertdialog\` are supported. Using \`dialog\` instead.`)), "dialog")), D = ref(0), S$2 = l(), R$2 = computed(() => t$6.open === A$1 && S$2 !== null ? (S$2.value & i$1.Open) === i$1.Open : t$6.open), m$3 = ref(null), E$3 = computed(() => i$2(m$3));
		if (s$4({
			el: m$3,
			$el: m$3
		}), !(t$6.open !== A$1 || S$2 !== null)) throw new Error("You forgot to provide an `open` prop to the `Dialog`.");
		if (typeof R$2.value != "boolean") throw new Error(`You provided an \`open\` prop to the \`Dialog\`, but the value is not a boolean. Received: ${R$2.value === A$1 ? void 0 : t$6.open}`);
		let c$3 = computed(() => u$6.value && R$2.value ? 0 : 1), k$1 = computed(() => c$3.value === 0), w$5 = computed(() => D.value > 1), N$5 = inject(H, null) !== null, [Q$1, X] = q(), { resolveContainers: B$1, mainTreeNodeRef: K$1, MainTreeNode: Z } = N$2({
			portals: Q$1,
			defaultContainers: [computed(() => {
				var e$1;
				return (e$1 = h$2.panelRef.value) != null ? e$1 : m$3.value;
			})]
		}), ee = computed(() => w$5.value ? "parent" : "leaf"), U$1 = computed(() => S$2 !== null ? (S$2.value & i$1.Closing) === i$1.Closing : !1), te = computed(() => N$5 || U$1.value ? !1 : k$1.value), le = computed(() => {
			var e$1, a$2, d$5;
			return (d$5 = Array.from((a$2 = (e$1 = E$3.value) == null ? void 0 : e$1.querySelectorAll("body > *")) != null ? a$2 : []).find((f$2) => f$2.id === "headlessui-portal-root" ? !1 : f$2.contains(o(K$1)) && f$2 instanceof HTMLElement)) != null ? d$5 : null;
		});
		E$1(le, te);
		let ae = computed(() => w$5.value ? !0 : k$1.value), oe = computed(() => {
			var e$1, a$2, d$5;
			return (d$5 = Array.from((a$2 = (e$1 = E$3.value) == null ? void 0 : e$1.querySelectorAll("[data-headlessui-portal]")) != null ? a$2 : []).find((f$2) => f$2.contains(o(K$1)) && f$2 instanceof HTMLElement)) != null ? d$5 : null;
		});
		E$1(oe, ae), R$1({
			type: "Dialog",
			enabled: computed(() => c$3.value === 0),
			element: m$3,
			onUpdate: (e$1, a$2) => {
				if (a$2 === "Dialog") return u(e$1, {
					[s$1.Add]: () => D.value += 1,
					[s$1.Remove]: () => D.value -= 1
				});
			}
		});
		let re = k({
			name: "DialogDescription",
			slot: computed(() => ({ open: R$2.value }))
		}), M$1 = ref(null), h$2 = {
			titleId: M$1,
			panelRef: ref(null),
			dialogState: c$3,
			setTitleId(e$1) {
				M$1.value !== e$1 && (M$1.value = e$1);
			},
			close() {
				i$6("close", !1);
			}
		};
		provide(H, h$2);
		let ne = computed(() => !(!k$1.value || w$5.value));
		w(B$1, (e$1, a$2) => {
			e$1.preventDefault(), h$2.close(), nextTick(() => a$2 == null ? void 0 : a$2.focus());
		}, ne);
		let ie = computed(() => !(w$5.value || c$3.value !== 0));
		E((W$2 = E$3.value) == null ? void 0 : W$2.defaultView, "keydown", (e$1) => {
			ie.value && (e$1.defaultPrevented || e$1.key === o$2.Escape && (e$1.preventDefault(), e$1.stopPropagation(), h$2.close()));
		});
		let ue$1 = computed(() => !(U$1.value || c$3.value !== 0 || N$5));
		return d$1(E$3, ue$1, (e$1) => {
			var a$2;
			return { containers: [...(a$2 = e$1.containers) != null ? a$2 : [], B$1] };
		}), watchEffect((e$1) => {
			if (c$3.value !== 0) return;
			let a$2 = o(m$3);
			if (!a$2) return;
			let d$5 = new ResizeObserver((f$2) => {
				for (let L$2 of f$2) {
					let x$1 = L$2.target.getBoundingClientRect();
					x$1.x === 0 && x$1.y === 0 && x$1.width === 0 && x$1.height === 0 && h$2.close();
				}
			});
			d$5.observe(a$2), e$1(() => d$5.disconnect());
		}), () => {
			let { open: e$1, initialFocus: a$2,...d$5 } = t$6, f$2 = {
				...l$3,
				ref: m$3,
				id: n$5,
				role: g$2.value,
				"aria-modal": c$3.value === 0 ? !0 : void 0,
				"aria-labelledby": M$1.value,
				"aria-describedby": re.value
			}, L$2 = { open: c$3.value === 0 };
			return h(u$1, { force: !0 }, () => [h($, () => h(z, { target: m$3.value }, () => h(u$1, { force: !1 }, () => h(ue, {
				initialFocus: a$2,
				containers: B$1,
				features: k$1.value ? u(ee.value, {
					parent: ue.features.RestoreFocus,
					leaf: ue.features.All & ~ue.features.FocusLock
				}) : ue.features.None
			}, () => h(X, {}, () => A({
				ourProps: f$2,
				theirProps: {
					...d$5,
					...l$3
				},
				slot: L$2,
				attrs: l$3,
				slots: p,
				visible: c$3.value === 0,
				features: N.RenderStrategy | N.Static,
				name: "Dialog"
			})))))), h(Z)]);
		};
	}
});
defineComponent({
	name: "DialogOverlay",
	props: {
		as: {
			type: [Object, String],
			default: "div"
		},
		id: {
			type: String,
			default: null
		}
	},
	setup(t$6, { attrs: i$6, slots: l$3 }) {
		var u$6;
		let p = (u$6 = t$6.id) != null ? u$6 : `headlessui-dialog-overlay-${i()}`, s$4 = T$1("DialogOverlay");
		function n$5(r$1) {
			r$1.target === r$1.currentTarget && (r$1.preventDefault(), r$1.stopPropagation(), s$4.close());
		}
		return () => {
			let { ...r$1 } = t$6;
			return A({
				ourProps: {
					id: p,
					"aria-hidden": !0,
					onClick: n$5
				},
				theirProps: r$1,
				slot: { open: s$4.dialogState.value === 0 },
				attrs: i$6,
				slots: l$3,
				name: "DialogOverlay"
			});
		};
	}
});
defineComponent({
	name: "DialogBackdrop",
	props: {
		as: {
			type: [Object, String],
			default: "div"
		},
		id: {
			type: String,
			default: null
		}
	},
	inheritAttrs: !1,
	setup(t$6, { attrs: i$6, slots: l$3, expose: p }) {
		var r$1;
		let s$4 = (r$1 = t$6.id) != null ? r$1 : `headlessui-dialog-backdrop-${i()}`, n$5 = T$1("DialogBackdrop"), u$6 = ref(null);
		return p({
			el: u$6,
			$el: u$6
		}), onMounted(() => {
			if (n$5.panelRef.value === null) throw new Error("A <DialogBackdrop /> component is being used, but a <DialogPanel /> component is missing.");
		}), () => {
			let { ...g$2 } = t$6, D = {
				id: s$4,
				ref: u$6,
				"aria-hidden": !0
			};
			return h(u$1, { force: !0 }, () => h($, () => A({
				ourProps: D,
				theirProps: {
					...i$6,
					...g$2
				},
				slot: { open: n$5.dialogState.value === 0 },
				attrs: i$6,
				slots: l$3,
				name: "DialogBackdrop"
			})));
		};
	}
});
defineComponent({
	name: "DialogPanel",
	props: {
		as: {
			type: [Object, String],
			default: "div"
		},
		id: {
			type: String,
			default: null
		}
	},
	setup(t$6, { attrs: i$6, slots: l$3, expose: p }) {
		var r$1;
		let s$4 = (r$1 = t$6.id) != null ? r$1 : `headlessui-dialog-panel-${i()}`, n$5 = T$1("DialogPanel");
		p({
			el: n$5.panelRef,
			$el: n$5.panelRef
		});
		function u$6(g$2) {
			g$2.stopPropagation();
		}
		return () => {
			let { ...g$2 } = t$6, D = {
				id: s$4,
				ref: n$5.panelRef,
				onClick: u$6
			};
			return A({
				ourProps: D,
				theirProps: g$2,
				slot: { open: n$5.dialogState.value === 0 },
				attrs: i$6,
				slots: l$3,
				name: "DialogPanel"
			});
		};
	}
});
let Ve = defineComponent({
	name: "DialogTitle",
	props: {
		as: {
			type: [Object, String],
			default: "h2"
		},
		id: {
			type: String,
			default: null
		}
	},
	setup(t$6, { attrs: i$6, slots: l$3 }) {
		var n$5;
		let p = (n$5 = t$6.id) != null ? n$5 : `headlessui-dialog-title-${i()}`, s$4 = T$1("DialogTitle");
		return onMounted(() => {
			s$4.setTitleId(p), onUnmounted(() => s$4.setTitleId(null));
		}), () => {
			let { ...u$6 } = t$6;
			return A({
				ourProps: { id: p },
				theirProps: u$6,
				slot: { open: s$4.dialogState.value === 0 },
				attrs: i$6,
				slots: l$3,
				name: "DialogTitle"
			});
		};
	}
}), Je = K;
function l$1(r$1) {
	let e$1 = { called: !1 };
	return (...t$6) => {
		if (!e$1.called) return e$1.called = !0, r$1(...t$6);
	};
}
function m(e$1, ...t$6) {
	e$1 && t$6.length > 0 && e$1.classList.add(...t$6);
}
function d(e$1, ...t$6) {
	e$1 && t$6.length > 0 && e$1.classList.remove(...t$6);
}
var g = ((i$6) => (i$6.Finished = "finished", i$6.Cancelled = "cancelled", i$6))(g || {});
function F(e$1, t$6) {
	let i$6 = o$1();
	if (!e$1) return i$6.dispose;
	let { transitionDuration: n$5, transitionDelay: a$2 } = getComputedStyle(e$1), [l$3, s$4] = [n$5, a$2].map((o$4) => {
		let [u$6 = 0] = o$4.split(",").filter(Boolean).map((r$1) => r$1.includes("ms") ? parseFloat(r$1) : parseFloat(r$1) * 1e3).sort((r$1, c$3) => c$3 - r$1);
		return u$6;
	});
	return l$3 !== 0 ? i$6.setTimeout(() => t$6("finished"), l$3 + s$4) : t$6("finished"), i$6.add(() => t$6("cancelled")), i$6.dispose;
}
function L(e$1, t$6, i$6, n$5, a$2, l$3) {
	let s$4 = o$1(), o$4 = l$3 !== void 0 ? l$1(l$3) : () => {};
	return d(e$1, ...a$2), m(e$1, ...t$6, ...i$6), s$4.nextFrame(() => {
		d(e$1, ...i$6), m(e$1, ...n$5), s$4.add(F(e$1, (u$6) => (d(e$1, ...n$5, ...t$6), m(e$1, ...a$2), o$4(u$6))));
	}), s$4.add(() => d(e$1, ...t$6, ...i$6, ...n$5, ...a$2)), s$4.add(() => o$4("cancelled")), s$4.dispose;
}
function g$1(e$1 = "") {
	return e$1.split(/\s+/).filter((t$6) => t$6.length > 1);
}
let R = Symbol("TransitionContext");
var pe = ((a$2) => (a$2.Visible = "visible", a$2.Hidden = "hidden", a$2))(pe || {});
function me() {
	return inject(R, null) !== null;
}
function Te() {
	let e$1 = inject(R, null);
	if (e$1 === null) throw new Error("A <TransitionChild /> is used but it is missing a parent <TransitionRoot />.");
	return e$1;
}
function ge() {
	let e$1 = inject(N$1, null);
	if (e$1 === null) throw new Error("A <TransitionChild /> is used but it is missing a parent <TransitionRoot />.");
	return e$1;
}
let N$1 = Symbol("NestingContext");
function L$1(e$1) {
	return "children" in e$1 ? L$1(e$1.children) : e$1.value.filter(({ state: t$6 }) => t$6 === "visible").length > 0;
}
function Q(e$1) {
	let t$6 = ref([]), a$2 = ref(!1);
	onMounted(() => a$2.value = !0), onUnmounted(() => a$2.value = !1);
	function s$4(n$5, r$1 = S.Hidden) {
		let l$3 = t$6.value.findIndex(({ id: f$2 }) => f$2 === n$5);
		l$3 !== -1 && (u(r$1, {
			[S.Unmount]() {
				t$6.value.splice(l$3, 1);
			},
			[S.Hidden]() {
				t$6.value[l$3].state = "hidden";
			}
		}), !L$1(t$6) && a$2.value && e$1?.());
	}
	function h$2(n$5) {
		let r$1 = t$6.value.find(({ id: l$3 }) => l$3 === n$5);
		return r$1 ? r$1.state !== "visible" && (r$1.state = "visible") : t$6.value.push({
			id: n$5,
			state: "visible"
		}), () => s$4(n$5, S.Unmount);
	}
	return {
		children: t$6,
		register: h$2,
		unregister: s$4
	};
}
let W = N.RenderStrategy, he = defineComponent({
	props: {
		as: {
			type: [Object, String],
			default: "div"
		},
		show: {
			type: [Boolean],
			default: null
		},
		unmount: {
			type: [Boolean],
			default: !0
		},
		appear: {
			type: [Boolean],
			default: !1
		},
		enter: {
			type: [String],
			default: ""
		},
		enterFrom: {
			type: [String],
			default: ""
		},
		enterTo: {
			type: [String],
			default: ""
		},
		entered: {
			type: [String],
			default: ""
		},
		leave: {
			type: [String],
			default: ""
		},
		leaveFrom: {
			type: [String],
			default: ""
		},
		leaveTo: {
			type: [String],
			default: ""
		}
	},
	emits: {
		beforeEnter: () => !0,
		afterEnter: () => !0,
		beforeLeave: () => !0,
		afterLeave: () => !0
	},
	setup(e$1, { emit: t$6, attrs: a$2, slots: s$4, expose: h$2 }) {
		let n$5 = ref(0);
		function r$1() {
			n$5.value |= i$1.Opening, t$6("beforeEnter");
		}
		function l$3() {
			n$5.value &= ~i$1.Opening, t$6("afterEnter");
		}
		function f$2() {
			n$5.value |= i$1.Closing, t$6("beforeLeave");
		}
		function S$2() {
			n$5.value &= ~i$1.Closing, t$6("afterLeave");
		}
		if (!me() && s()) return () => h(Se, {
			...e$1,
			onBeforeEnter: r$1,
			onAfterEnter: l$3,
			onBeforeLeave: f$2,
			onAfterLeave: S$2
		}, s$4);
		let d$5 = ref(null), y$3 = computed(() => e$1.unmount ? S.Unmount : S.Hidden);
		h$2({
			el: d$5,
			$el: d$5
		});
		let { show: v$1, appear: A$3 } = Te(), { register: D, unregister: H$3 } = ge(), i$6 = ref(v$1.value ? "visible" : "hidden"), I$1 = { value: !0 }, c$3 = i(), b$1 = { value: !1 }, P$1 = Q(() => {
			!b$1.value && i$6.value !== "hidden" && (i$6.value = "hidden", H$3(c$3), S$2());
		});
		onMounted(() => {
			let o$4 = D(c$3);
			onUnmounted(o$4);
		}), watchEffect(() => {
			if (y$3.value === S.Hidden && c$3) {
				if (v$1.value && i$6.value !== "visible") {
					i$6.value = "visible";
					return;
				}
				u(i$6.value, {
					["hidden"]: () => H$3(c$3),
					["visible"]: () => D(c$3)
				});
			}
		});
		let j$1 = g$1(e$1.enter), M$1 = g$1(e$1.enterFrom), X = g$1(e$1.enterTo), _ = g$1(e$1.entered), Y = g$1(e$1.leave), Z = g$1(e$1.leaveFrom), ee = g$1(e$1.leaveTo);
		onMounted(() => {
			watchEffect(() => {
				if (i$6.value === "visible") {
					let o$4 = o(d$5);
					if (o$4 instanceof Comment && o$4.data === "") throw new Error("Did you forget to passthrough the `ref` to the actual DOM node?");
				}
			});
		});
		function te(o$4) {
			let E$3 = I$1.value && !A$3.value, p = o(d$5);
			!p || !(p instanceof HTMLElement) || E$3 || (b$1.value = !0, v$1.value && r$1(), v$1.value || f$2(), o$4(v$1.value ? L(p, j$1, M$1, X, _, (V) => {
				b$1.value = !1, V === g.Finished && l$3();
			}) : L(p, Y, Z, ee, _, (V) => {
				b$1.value = !1, V === g.Finished && (L$1(P$1) || (i$6.value = "hidden", H$3(c$3), S$2()));
			})));
		}
		return onMounted(() => {
			watch([v$1], (o$4, E$3, p) => {
				te(p), I$1.value = !1;
			}, { immediate: !0 });
		}), provide(N$1, P$1), t(computed(() => u(i$6.value, {
			["visible"]: i$1.Open,
			["hidden"]: i$1.Closed
		}) | n$5.value)), () => {
			let { appear: o$4, show: E$3, enter: p, enterFrom: V, enterTo: Ce, entered: ye, leave: be, leaveFrom: Ee, leaveTo: Ve$1,...U$1 } = e$1, ne = { ref: d$5 }, re = {
				...U$1,
				...A$3.value && v$1.value && c.isServer ? { class: normalizeClass([
					a$2.class,
					U$1.class,
					...j$1,
					...M$1
				]) } : {}
			};
			return A({
				theirProps: re,
				ourProps: ne,
				slot: {},
				slots: s$4,
				attrs: a$2,
				features: W,
				visible: i$6.value === "visible",
				name: "TransitionChild"
			});
		};
	}
}), ce = he, Se = defineComponent({
	inheritAttrs: !1,
	props: {
		as: {
			type: [Object, String],
			default: "div"
		},
		show: {
			type: [Boolean],
			default: null
		},
		unmount: {
			type: [Boolean],
			default: !0
		},
		appear: {
			type: [Boolean],
			default: !1
		},
		enter: {
			type: [String],
			default: ""
		},
		enterFrom: {
			type: [String],
			default: ""
		},
		enterTo: {
			type: [String],
			default: ""
		},
		entered: {
			type: [String],
			default: ""
		},
		leave: {
			type: [String],
			default: ""
		},
		leaveFrom: {
			type: [String],
			default: ""
		},
		leaveTo: {
			type: [String],
			default: ""
		}
	},
	emits: {
		beforeEnter: () => !0,
		afterEnter: () => !0,
		beforeLeave: () => !0,
		afterLeave: () => !0
	},
	setup(e$1, { emit: t$6, attrs: a$2, slots: s$4 }) {
		let h$2 = l(), n$5 = computed(() => e$1.show === null && h$2 !== null ? (h$2.value & i$1.Open) === i$1.Open : e$1.show);
		watchEffect(() => {
			if (![!0, !1].includes(n$5.value)) throw new Error("A <Transition /> is used but it is missing a `:show=\"true | false\"` prop.");
		});
		let r$1 = ref(n$5.value ? "visible" : "hidden"), l$3 = Q(() => {
			r$1.value = "hidden";
		}), f$2 = ref(!0), S$2 = {
			show: n$5,
			appear: computed(() => e$1.appear || !f$2.value)
		};
		return onMounted(() => {
			watchEffect(() => {
				f$2.value = !1, n$5.value ? r$1.value = "visible" : L$1(l$3) || (r$1.value = "hidden");
			});
		}), provide(N$1, l$3), provide(R, S$2), () => {
			let d$5 = T(e$1, [
				"show",
				"appear",
				"unmount",
				"onBeforeEnter",
				"onBeforeLeave",
				"onAfterEnter",
				"onAfterLeave"
			]), y$3 = { unmount: e$1.unmount };
			return A({
				ourProps: {
					...y$3,
					as: "template"
				},
				theirProps: {},
				slot: {},
				slots: {
					...s$4,
					default: () => [h(ce, {
						onBeforeEnter: () => t$6("beforeEnter"),
						onAfterEnter: () => t$6("afterEnter"),
						onBeforeLeave: () => t$6("beforeLeave"),
						onAfterLeave: () => t$6("afterLeave"),
						...a$2,
						...y$3,
						...d$5
					}, s$4.default)]
				},
				attrs: {},
				features: W,
				visible: r$1.value === "visible",
				name: "Transition"
			});
		};
	}
});
const _hoisted_1 = { class: "modal--titlebar" };
const _hoisted_2 = {
	key: 0,
	class: "icon i-ri-alert-fill icon-ui-danger"
};
const _hoisted_3 = { class: "modal--actions" };
const _hoisted_4 = {
	key: 2,
	class: "modal--logs"
};
var SvwsUiModal_vue_vue_type_script_setup_true_lang_default = /* @__PURE__ */ defineComponent({
	__name: "SvwsUiModal",
	props: {
		show: { type: Boolean },
		size: { default: "small" },
		type: { default: "default" },
		autoClose: {
			type: Boolean,
			default: true
		},
		closeInTitle: {
			type: Boolean,
			default: true
		},
		noScroll: {
			type: Boolean,
			default: false
		}
	},
	emits: ["update:show"],
	setup(__props, { emit: __emit }) {
		const props = __props;
		const emit = __emit;
		function autoCloseModal() {
			if (props.autoClose) closeModal();
		}
		function closeModal() {
			emit("update:show", false);
		}
		const idComponent = useId();
		const idTC_overlay = useId();
		const idTC_div = useId();
		return (_ctx, _cache) => {
			const _component_svws_ui_button = SvwsUiButton_default;
			const _component_svws_ui_tooltip = SvwsUiTooltip_default;
			return openBlock(), createBlock(unref(Se), {
				appear: "",
				show: _ctx.show
			}, {
				default: withCtx(() => [createVNode(unref(Ye), {
					id: unref(idComponent),
					class: "modal--wrapper",
					onClose: autoCloseModal,
					onKeyup: withKeys(autoCloseModal, ["esc"])
				}, {
					default: withCtx(() => [createBaseVNode("div", { class: normalizeClass(["modal--pageWrapper", { "modal--pageWrapper--help": _ctx.size === "help" }]) }, [_ctx.size !== "help" ? (openBlock(), createBlock(unref(he), {
						key: 0,
						id: unref(idTC_overlay),
						as: "div",
						enter: "ease-out duration-200",
						"enter-from": "opacity-0",
						"enter-to": "opacity-100",
						leave: "ease-in duration-100",
						"leave-from": "opacity-100",
						"leave-to": "opacity-0"
					}, {
						default: withCtx(() => [createBaseVNode("div", {
							class: "modal--overlay",
							onClick: autoCloseModal
						})]),
						_: 1
					}, 8, ["id"])) : createCommentVNode("", true), createVNode(unref(he), {
						id: unref(idTC_div),
						as: "div",
						enter: "ease-out duration-200",
						"enter-from": "opacity-0 scale-95",
						"enter-to": "opacity-100 scale-100",
						leave: "ease-in duration-100",
						"leave-from": "opacity-100 scale-100",
						"leave-to": "opacity-0 scale-95",
						class: normalizeClass(["modal", {
							"modal--sm": _ctx.size === "small",
							"modal--md": _ctx.size === "medium",
							"modal--lg": _ctx.size === "big",
							"modal--help": _ctx.size === "help",
							"modal--danger": _ctx.type === "danger"
						}])
					}, {
						default: withCtx(() => [createBaseVNode("div", _hoisted_1, [
							createVNode(unref(Ve), { class: "modal--title inline-flex items-center gap-1" }, {
								default: withCtx(() => [_ctx.type === "danger" ? (openBlock(), createElementBlock("span", _hoisted_2)) : createCommentVNode("", true), renderSlot(_ctx.$slots, "modalTitle")]),
								_: 3
							}),
							_ctx.$slots.hilfe ? (openBlock(), createBlock(_component_svws_ui_tooltip, {
								key: 0,
								autosize: ""
							}, {
								content: withCtx(() => [renderSlot(_ctx.$slots, "hilfe")]),
								default: withCtx(() => [createVNode(_component_svws_ui_button, {
									type: "secondary",
									onClick: _cache[0] || (_cache[0] = withModifiers(() => {}, ["stop"]))
								}, {
									default: withCtx(() => [..._cache[1] || (_cache[1] = [createBaseVNode("span", { class: "icon i-ri-question-line" }, null, -1), createBaseVNode("span", null, "Hilfe", -1)])]),
									_: 1
								})]),
								_: 3
							})) : createCommentVNode("", true),
							_ctx.closeInTitle ? (openBlock(), createBlock(_component_svws_ui_button, {
								key: 1,
								type: "icon",
								onClick: closeModal
							}, {
								default: withCtx(() => [..._cache[2] || (_cache[2] = [createBaseVNode("span", { class: "icon i-ri-close-line" }, null, -1)])]),
								_: 1
							})) : createCommentVNode("", true)
						]), createBaseVNode("div", { class: normalizeClass(["modal--content-wrapper", { "modal--content-noscroll": _ctx.noScroll }]) }, [
							_ctx.$slots.modalDescription ? (openBlock(), createBlock(unref(Je), {
								key: 0,
								class: "modal--description"
							}, {
								default: withCtx(() => [renderSlot(_ctx.$slots, "modalDescription")]),
								_: 3
							})) : createCommentVNode("", true),
							_ctx.$slots.modalContent ? (openBlock(), createElementBlock("div", {
								key: 1,
								class: normalizeClass(["modal--content", { "modal--content-noscroll": _ctx.noScroll }])
							}, [renderSlot(_ctx.$slots, "modalContent")], 2)) : createCommentVNode("", true),
							createBaseVNode("div", _hoisted_3, [renderSlot(_ctx.$slots, "modalActions")]),
							_ctx.$slots.modalLogs ? (openBlock(), createElementBlock("div", _hoisted_4, [renderSlot(_ctx.$slots, "modalLogs")])) : createCommentVNode("", true)
						], 2)]),
						_: 3
					}, 8, ["id", "class"])], 2)]),
					_: 3
				}, 8, ["id"])]),
				_: 3
			}, 8, ["show"]);
		};
	}
});
var SvwsUiModal_default = SvwsUiModal_vue_vue_type_script_setup_true_lang_default;
export { SvwsUiModal_default as b, __plugin_vue_export_helper_default as c };

//# sourceMappingURL=SvwsUiModal.js.map