import { $ as withCtx, B as createTextVNode, C as createVNode, D as defineComponent, P as openBlock, S as renderSlot, a8 as ref, b as SvwsUiButton_default, r as Fragment, v as createBaseVNode, y as createElementBlock } from "./index.js";
import { b as SvwsUiModal_default } from "./SvwsUiModal.js";
var DatenschutzModal_vue_vue_type_script_setup_true_lang_default = /* @__PURE__ */ defineComponent({
	__name: "DatenschutzModal",
	setup(__props) {
		const show = ref(false);
		async function closeModal() {
			show.value = false;
		}
		const openModal = () => {
			show.value = true;
		};
		return (_ctx, _cache) => {
			const _component_svws_ui_button = SvwsUiButton_default;
			const _component_svws_ui_modal = SvwsUiModal_default;
			return openBlock(), createElementBlock(Fragment, null, [renderSlot(_ctx.$slots, "default", { openModal }), createVNode(_component_svws_ui_modal, {
				show: show.value,
				"onUpdate:show": _cache[0] || (_cache[0] = ($event) => show.value = $event),
				size: "small"
			}, {
				modalTitle: withCtx(() => [..._cache[1] || (_cache[1] = [createTextVNode("Information zum Datenschutz", -1)])]),
				modalDescription: withCtx(() => [..._cache[2] || (_cache[2] = [createBaseVNode("div", { class: "space-y-2 text-left" }, [
					createBaseVNode("p", null, " Die automatische Verarbeitung von personenbezogenen Daten von Schülerinnen und Schülern und Erziehungsberechtigten muss zur Erfüllung der den Schulen durch Rechtsvorschrift übertragenen Aufgaben erforderlich sein bzw. die Betroffene bzw. der Betroffene hat im Einzelfall schriftlich in die Datenverarbeitung eingewilligt. Dies ist bei der Wahl neuer Kategorien zu berücksichtigen. "),
					createBaseVNode("p", null, "Die Art der gespeicherten Daten (Kategorien) ist dem zuständigen Behördlichen Datenschutzbeauftragten zur Aufnahme in das Verfahrensverzeichnis anzuzeigen."),
					createBaseVNode("p", null, "Personenbezogene Daten sind zu löschen, wenn ihre Kenntnis für die Aufgabenerfüllung nicht mehr erforderlich ist. § 9 Abs. 2 Satz 2 VO-DV I")
				], -1)])]),
				modalActions: withCtx(() => [createVNode(_component_svws_ui_button, { onClick: closeModal }, {
					default: withCtx(() => [..._cache[3] || (_cache[3] = [createTextVNode("Ok", -1)])]),
					_: 1
				})]),
				_: 1
			}, 8, ["show"])], 64);
		};
	}
});
var DatenschutzModal_default = DatenschutzModal_vue_vue_type_script_setup_true_lang_default;
export { DatenschutzModal_default as b };

//# sourceMappingURL=DatenschutzModal.js.map