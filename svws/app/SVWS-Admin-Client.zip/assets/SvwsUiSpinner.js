import { D as defineComponent, P as openBlock, v as createBaseVNode, x as createCommentVNode, y as createElementBlock } from "./index.js";
const _hoisted_1 = {
	key: 0,
	class: "animate-spin ml-1 h-4 w-4",
	xmlns: "http://www.w3.org/2000/svg",
	fill: "none",
	viewBox: "0 0 24 24"
};
var SvwsUiSpinner_vue_vue_type_script_setup_true_lang_default = /* @__PURE__ */ defineComponent({
	__name: "SvwsUiSpinner",
	props: { spinning: { type: Boolean } },
	setup(__props) {
		return (_ctx, _cache) => {
			return _ctx.spinning ? (openBlock(), createElementBlock("svg", _hoisted_1, [..._cache[0] || (_cache[0] = [createBaseVNode("circle", {
				class: "opacity-25",
				cx: "12",
				cy: "12",
				r: "10",
				stroke: "currentColor",
				"stroke-width": "4"
			}, null, -1), createBaseVNode("path", {
				class: "opacity-75",
				fill: "currentColor",
				d: "M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
			}, null, -1)])])) : createCommentVNode("", true);
		};
	}
});
var SvwsUiSpinner_default = SvwsUiSpinner_vue_vue_type_script_setup_true_lang_default;
export { SvwsUiSpinner_default as b };

//# sourceMappingURL=SvwsUiSpinner.js.map